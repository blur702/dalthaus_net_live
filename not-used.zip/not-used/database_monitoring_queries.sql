-- ============================================================================
-- Database Performance Monitoring Queries
-- Created: 2025-09-06
-- Description: Comprehensive monitoring and analysis queries for MySQL performance
-- ============================================================================

-- These queries help monitor database performance, identify bottlenecks,
-- and track the effectiveness of optimizations

-- ============================================================================
-- Query Performance Analysis
-- ============================================================================

-- 1. Top 10 Slowest Queries (Requires performance_schema enabled)
-- Shows queries that take the most time on average
SELECT 
    DIGEST_TEXT as query_pattern,
    COUNT_STAR as exec_count,
    ROUND(AVG_TIMER_WAIT/1000000000000, 4) as avg_time_sec,
    ROUND(MAX_TIMER_WAIT/1000000000000, 4) as max_time_sec,
    ROUND(SUM_TIMER_WAIT/1000000000000, 2) as total_time_sec,
    ROUND(AVG_ROWS_EXAMINED/COUNT_STAR, 0) as avg_rows_examined,
    ROUND(AVG_ROWS_SENT/COUNT_STAR, 0) as avg_rows_returned
FROM performance_schema.events_statements_summary_by_digest
WHERE AVG_TIMER_WAIT > 100000000000  -- Queries taking more than 0.1 second
  AND DIGEST_TEXT NOT LIKE '%performance_schema%'
  AND DIGEST_TEXT NOT LIKE '%information_schema%'
ORDER BY AVG_TIMER_WAIT DESC
LIMIT 10;

-- 2. Most Executed Queries
-- Identify queries that run most frequently (good candidates for optimization)
SELECT 
    DIGEST_TEXT as query_pattern,
    COUNT_STAR as execution_count,
    ROUND(AVG_TIMER_WAIT/1000000000000, 4) as avg_time_sec,
    ROUND(SUM_TIMER_WAIT/1000000000000, 2) as total_time_sec,
    FIRST_SEEN,
    LAST_SEEN
FROM performance_schema.events_statements_summary_by_digest
WHERE DIGEST_TEXT NOT LIKE '%performance_schema%'
  AND DIGEST_TEXT NOT LIKE '%information_schema%'
ORDER BY COUNT_STAR DESC
LIMIT 15;

-- 3. Queries Causing Full Table Scans
-- Identify queries that may need better indexing
SELECT 
    DIGEST_TEXT as query_pattern,
    COUNT_STAR as exec_count,
    SUM_NO_INDEX_USED as no_index_used_count,
    SUM_NO_GOOD_INDEX_USED as no_good_index_count,
    ROUND(AVG_TIMER_WAIT/1000000000000, 4) as avg_time_sec
FROM performance_schema.events_statements_summary_by_digest
WHERE SUM_NO_INDEX_USED > 0 
   OR SUM_NO_GOOD_INDEX_USED > 0
ORDER BY SUM_NO_INDEX_USED DESC, COUNT_STAR DESC
LIMIT 10;

-- ============================================================================
-- Index Usage Analysis
-- ============================================================================

-- 4. Index Usage Statistics
-- Shows how often each index is used
SELECT 
    OBJECT_SCHEMA as db_name,
    OBJECT_NAME as table_name,
    INDEX_NAME,
    COUNT_STAR as usage_count,
    COUNT_READ as read_count,
    COUNT_WRITE as write_count,
    COUNT_FETCH as fetch_count,
    COUNT_INSERT as insert_count,
    COUNT_UPDATE as update_count,
    COUNT_DELETE as delete_count
FROM performance_schema.table_io_waits_summary_by_index_usage
WHERE OBJECT_SCHEMA = DATABASE()
  AND COUNT_STAR > 0
ORDER BY COUNT_STAR DESC;

-- 5. Unused Indexes (Potential candidates for removal)
-- Shows indexes that are never used
SELECT 
    OBJECT_SCHEMA as db_name,
    OBJECT_NAME as table_name,
    INDEX_NAME,
    'NEVER USED' as usage_status
FROM performance_schema.table_io_waits_summary_by_index_usage
WHERE OBJECT_SCHEMA = DATABASE()
  AND COUNT_STAR = 0
  AND INDEX_NAME IS NOT NULL
  AND INDEX_NAME != 'PRIMARY'
ORDER BY table_name, INDEX_NAME;

-- 6. Index Efficiency Analysis
-- Compare index selectivity and usage
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    NON_UNIQUE,
    SEQ_IN_INDEX as column_position,
    COLUMN_NAME,
    CARDINALITY,
    ROUND(CARDINALITY / (SELECT TABLE_ROWS FROM information_schema.TABLES t WHERE t.TABLE_SCHEMA = s.TABLE_SCHEMA AND t.TABLE_NAME = s.TABLE_NAME), 4) as selectivity
FROM information_schema.STATISTICS s
WHERE TABLE_SCHEMA = DATABASE()
  AND CARDINALITY > 0
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;

-- ============================================================================
-- Table Analysis and Optimization
-- ============================================================================

-- 7. Table Size and Row Count Analysis
-- Monitor table growth and storage usage
SELECT 
    TABLE_NAME,
    TABLE_ROWS as estimated_rows,
    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) as total_size_mb,
    ROUND((DATA_LENGTH / 1024 / 1024), 2) as data_size_mb,
    ROUND((INDEX_LENGTH / 1024 / 1024), 2) as index_size_mb,
    ROUND((INDEX_LENGTH / DATA_LENGTH) * 100, 2) as index_ratio_percent,
    ENGINE,
    CREATE_TIME,
    UPDATE_TIME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_TYPE = 'BASE TABLE'
ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC;

-- 8. Table Fragmentation Analysis
-- Identify tables that may benefit from optimization
SELECT 
    TABLE_NAME,
    ROUND(((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024), 2) as total_size_mb,
    ROUND((DATA_FREE / 1024 / 1024), 2) as free_space_mb,
    ROUND((DATA_FREE / (DATA_LENGTH + INDEX_LENGTH)) * 100, 2) as fragmentation_percent
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND DATA_FREE > 0
  AND TABLE_TYPE = 'BASE TABLE'
ORDER BY fragmentation_percent DESC;

-- 9. InnoDB Buffer Pool Hit Rate
-- Monitor memory efficiency (should be > 99%)
SELECT 
    ROUND((1 - (VARIABLE_VALUE / (SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_buffer_pool_read_requests'))) * 100, 2) as buffer_pool_hit_rate_percent
FROM GLOBAL_STATUS 
WHERE VARIABLE_NAME = 'Innodb_buffer_pool_reads';

-- ============================================================================
-- Security Monitoring Queries
-- ============================================================================

-- 10. Failed Login Attempts Analysis
-- Monitor potential security threats
SELECT 
    ip_address,
    COUNT(*) as failed_attempts,
    COUNT(DISTINCT identifier) as targeted_accounts,
    MIN(attempted_at) as first_attempt,
    MAX(attempted_at) as last_attempt,
    TIMESTAMPDIFF(MINUTE, MIN(attempted_at), MAX(attempted_at)) as attack_duration_minutes
FROM login_attempts 
WHERE success = 0
  AND attempted_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY ip_address
HAVING failed_attempts >= 3
ORDER BY failed_attempts DESC, last_attempt DESC;

-- 11. Security Events Summary
-- Daily security event overview
SELECT 
    DATE(created_at) as event_date,
    event_type,
    severity,
    COUNT(*) as event_count,
    COUNT(CASE WHEN resolved = 0 THEN 1 END) as unresolved_count
FROM security_events 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY DATE(created_at), event_type, severity
ORDER BY event_date DESC, 
         FIELD(severity, 'critical', 'high', 'medium', 'low', 'info'),
         event_count DESC;

-- 12. Audit Trail Activity Analysis
-- Monitor administrative actions
SELECT 
    DATE(created_at) as activity_date,
    action,
    object_type,
    COUNT(*) as action_count,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT ip_address) as unique_ips
FROM audit_logs 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(created_at), action, object_type
ORDER BY activity_date DESC, action_count DESC;

-- ============================================================================
-- Application Performance Metrics
-- ============================================================================

-- 13. Content Management Statistics
-- Monitor content creation and publishing trends
SELECT 
    DATE(created_at) as creation_date,
    content_type,
    status,
    COUNT(*) as items_count,
    COUNT(DISTINCT user_id) as unique_authors
FROM content 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(created_at), content_type, status
ORDER BY creation_date DESC, items_count DESC;

-- 14. User Activity Analysis
-- Track user engagement and content creation
SELECT 
    u.username,
    u.last_login_at,
    COUNT(c.content_id) as total_content,
    COUNT(CASE WHEN c.status = 'published' THEN 1 END) as published_content,
    COUNT(CASE WHEN c.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as recent_content,
    MAX(c.updated_at) as last_content_update
FROM users u
LEFT JOIN content c ON u.user_id = c.user_id
WHERE u.is_active = 1
GROUP BY u.user_id, u.username, u.last_login_at
ORDER BY recent_content DESC, published_content DESC;

-- 15. Session Management Analysis
-- Monitor active sessions and cleanup effectiveness
SELECT 
    COUNT(*) as total_sessions,
    COUNT(CASE WHEN user_id IS NOT NULL THEN 1 END) as authenticated_sessions,
    COUNT(CASE WHEN FROM_UNIXTIME(last_activity) >= DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 END) as active_last_hour,
    COUNT(CASE WHEN FROM_UNIXTIME(last_activity) >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as active_last_day,
    MIN(FROM_UNIXTIME(last_activity)) as oldest_session,
    MAX(FROM_UNIXTIME(last_activity)) as newest_session
FROM sessions;

-- ============================================================================
-- Database Health Checks
-- ============================================================================

-- 16. InnoDB Status Overview
-- Key InnoDB metrics for performance monitoring
SELECT 
    'Buffer Pool Size' as metric,
    VARIABLE_VALUE as value
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_buffer_pool_size'
UNION ALL
SELECT 
    'Buffer Pool Pages Total',
    VARIABLE_VALUE
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_buffer_pool_pages_total'
UNION ALL
SELECT 
    'Buffer Pool Pages Free',
    VARIABLE_VALUE
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_buffer_pool_pages_free'
UNION ALL
SELECT 
    'Buffer Pool Pages Dirty',
    VARIABLE_VALUE
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_buffer_pool_pages_dirty';

-- 17. Connection Analysis
-- Monitor connection usage and limits
SELECT 
    'Max Connections' as metric,
    @@max_connections as configured_value,
    (SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Max_used_connections') as max_used,
    (SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Threads_connected') as current_connections
UNION ALL
SELECT 
    'Connection Usage %',
    ROUND(((SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Threads_connected') / @@max_connections) * 100, 2),
    NULL,
    NULL;

-- 18. Lock Analysis
-- Monitor table locks and potential deadlocks
SELECT 
    'Table Locks Immediate' as lock_type,
    VARIABLE_VALUE as count
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Table_locks_immediate'
UNION ALL
SELECT 
    'Table Locks Waited',
    VARIABLE_VALUE
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Table_locks_waited'
UNION ALL
SELECT 
    'InnoDB Row Locks Current',
    VARIABLE_VALUE
FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Innodb_row_lock_current_waits';

-- ============================================================================
-- Automated Monitoring Setup
-- ============================================================================

-- 19. Create a monitoring log table (optional)
-- Uncomment to create a performance monitoring log
/*
CREATE TABLE IF NOT EXISTS performance_monitoring_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    check_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(15,2),
    threshold_warning DECIMAL(15,2),
    threshold_critical DECIMAL(15,2),
    status ENUM('OK', 'WARNING', 'CRITICAL') DEFAULT 'OK',
    notes TEXT,
    INDEX idx_check_time (check_time),
    INDEX idx_metric_name (metric_name),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
*/

-- 20. Sample monitoring data insertion
-- Use this pattern to log performance metrics
/*
INSERT INTO performance_monitoring_log (metric_name, metric_value, threshold_warning, threshold_critical, status, notes)
SELECT 
    'slow_query_count' as metric_name,
    COUNT(*) as metric_value,
    10 as threshold_warning,
    50 as threshold_critical,
    CASE 
        WHEN COUNT(*) >= 50 THEN 'CRITICAL'
        WHEN COUNT(*) >= 10 THEN 'WARNING'
        ELSE 'OK'
    END as status,
    CONCAT('Queries slower than 1 second in last hour: ', COUNT(*)) as notes
FROM performance_schema.events_statements_summary_by_digest
WHERE AVG_TIMER_WAIT > 1000000000000
  AND LAST_SEEN >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
*/

-- ============================================================================
-- Maintenance and Cleanup Monitoring
-- ============================================================================

-- 21. Check Tables Needing Optimization
-- Identify tables that may benefit from OPTIMIZE TABLE
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as size_mb,
    ROUND(DATA_FREE / 1024 / 1024, 2) as free_space_mb,
    UPDATE_TIME,
    CHECK_TIME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND (DATA_FREE > 1024 * 1024 OR CHECK_TIME < DATE_SUB(NOW(), INTERVAL 7 DAY))
  AND TABLE_TYPE = 'BASE TABLE'
ORDER BY DATA_FREE DESC;

-- 22. Binary Log Space Usage
-- Monitor binary log disk usage (if enabled)
/*
SELECT 
    LOG_NAME,
    ROUND(FILE_SIZE / 1024 / 1024, 2) as size_mb
FROM information_schema.BINARY_LOGS
ORDER BY LOG_NAME DESC
LIMIT 10;
*/

-- ============================================================================
-- Performance Alerts (Use in monitoring scripts)
-- ============================================================================

-- 23. Critical Performance Alerts
-- Query to identify critical performance issues
SELECT 
    'CRITICAL ALERT' as alert_level,
    alert_type,
    metric_value,
    threshold,
    message
FROM (
    SELECT 
        'SLOW_QUERIES' as alert_type,
        COUNT(*) as metric_value,
        10 as threshold,
        CONCAT('Found ', COUNT(*), ' queries slower than 1 second') as message
    FROM performance_schema.events_statements_summary_by_digest
    WHERE AVG_TIMER_WAIT > 1000000000000
    HAVING COUNT(*) > 10
    
    UNION ALL
    
    SELECT 
        'HIGH_CONNECTION_USAGE' as alert_type,
        ROUND(((SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Threads_connected') / @@max_connections) * 100, 2) as metric_value,
        80 as threshold,
        CONCAT('Connection usage at ', ROUND(((SELECT VARIABLE_VALUE FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Threads_connected') / @@max_connections) * 100, 2), '%') as message
    HAVING metric_value > 80
    
    UNION ALL
    
    SELECT 
        'TABLE_FRAGMENTATION' as alert_type,
        MAX(ROUND((DATA_FREE / (DATA_LENGTH + INDEX_LENGTH)) * 100, 2)) as metric_value,
        25 as threshold,
        CONCAT('Maximum table fragmentation: ', MAX(ROUND((DATA_FREE / (DATA_LENGTH + INDEX_LENGTH)) * 100, 2)), '%') as message
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
      AND DATA_FREE > 0
    HAVING metric_value > 25
) alerts;

-- ============================================================================
-- Usage Instructions
-- ============================================================================

/*
MONITORING SCHEDULE RECOMMENDATIONS:

Real-time (every minute):
- Query 16: InnoDB Status
- Query 17: Connection Analysis

Every 5 minutes:
- Query 1: Slowest Queries
- Query 10: Failed Login Attempts

Hourly:
- Query 2: Most Executed Queries
- Query 15: Session Management
- Query 23: Critical Alerts

Daily:
- Query 7: Table Size Analysis  
- Query 11: Security Events Summary
- Query 14: User Activity Analysis

Weekly:
- Query 5: Unused Indexes
- Query 8: Table Fragmentation
- Query 21: Tables Needing Optimization

Monthly:
- Query 6: Index Efficiency Analysis
- Full performance review and optimization planning

AUTOMATION:
Create shell scripts or cron jobs to run these queries and send alerts
when thresholds are exceeded. Consider using tools like:
- Nagios/Icinga for monitoring
- Grafana for visualization
- Custom PHP scripts for CMS-specific monitoring
*/

SELECT 'Database monitoring queries loaded successfully!' as status,
       'Run these queries regularly to monitor database health and performance' as instructions;