<?php

echo "\n";
echo "========================================\n";
echo "    CMS COMPREHENSIVE SYSTEM TEST      \n";
echo "========================================\n";
echo "\n";

$tests = [];
$pass = 0;
$total = 0;

function runTest($name, $callable) {
    global $tests, $pass, $total;
    $total++;
    
    echo "Testing: $name... ";
    try {
        $result = $callable();
        if ($result) {
            echo "✅ PASS\n";
            $pass++;
            $tests[$name] = 'PASS';
        } else {
            echo "❌ FAIL\n";
            $tests[$name] = 'FAIL';
        }
    } catch (Exception $e) {
        echo "❌ ERROR: " . $e->getMessage() . "\n";
        $tests[$name] = 'ERROR';
    }
}

// Test 1: Database Connection
runTest("Database Connection", function() {
    $config = require 'config/config.php';
    $pdo = new PDO(
        'mysql:host=' . $config['database']['host'] . ';dbname=' . $config['database']['dbname'],
        $config['database']['username'],
        $config['database']['password']
    );
    return $pdo->query('SELECT 1')->fetchColumn() == 1;
});

// Test 2: Homepage loads
runTest("Homepage Loads", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200 && !empty($response);
});

// Test 3: Admin login page loads
runTest("Admin Login Page", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200 && strpos($response, 'username') !== false;
});

// Test 4: Admin authentication
runTest("Admin Authentication", function() {
    // Get login form
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'test_cookies.txt');
    $response = curl_exec($ch);
    curl_close($ch);
    
    // Extract CSRF token
    preg_match('/name="_token" value="([^"]+)"/', $response, $matches);
    if (!isset($matches[1])) return false;
    
    // Attempt login
    $postData = [
        'username' => 'kevin',
        'password' => '(130Bpm)',
        '_token' => $matches[1]
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'test_cookies.txt');
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $redirect = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    curl_close($ch);
    
    return $httpCode === 302 && strpos($redirect, '/admin/dashboard') !== false;
});

// Test 5: Admin dashboard loads
runTest("Admin Dashboard", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/dashboard');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'test_cookies.txt');
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200 && strpos($response, 'Dashboard') !== false;
});

// Test 6: Content creation page loads
runTest("Content Creation Page", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content/create');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'test_cookies.txt');
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200 && strpos($response, 'name="title"') !== false;
});

// Test 7: Articles frontend page
runTest("Articles Frontend", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/articles');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200;
});

// Test 8: Photobooks frontend page
runTest("Photobooks Frontend", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/photobooks');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200;
});

// Test 9: Pages management
runTest("Pages Management", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/pages');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'test_cookies.txt');
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200;
});

// Test 10: Check if test content exists
runTest("Test Content Exists", function() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/articles');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode === 200 && strpos($response, 'Test Article') !== false;
});

echo "\n";
echo "========================================\n";
echo "           TEST RESULTS                 \n";
echo "========================================\n";
echo "\n";

foreach ($tests as $test => $result) {
    $status = $result === 'PASS' ? '✅' : '❌';
    echo sprintf("%-30s %s %s\n", $test, $status, $result);
}

echo "\n";
echo "========================================\n";
echo sprintf("OVERALL: %d/%d tests passed (%.1f%%)\n", $pass, $total, ($pass/$total)*100);
echo "========================================\n";

// Clean up
@unlink('test_cookies.txt');

if ($pass === $total) {
    echo "\n🎉 ALL TESTS PASSED! The CMS is working perfectly! 🎉\n";
    exit(0);
} else {
    echo "\n⚠️  Some tests failed. Check the issues above.\n";
    exit(1);
}