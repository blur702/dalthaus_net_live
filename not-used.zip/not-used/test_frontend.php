<?php

// Test frontend display
echo "Testing frontend display...\n";

// Test homepage
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Homepage HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Homepage loads successfully\n";
    
    if (strpos($response, 'CMS') !== false || strpos($response, 'Welcome') !== false) {
        echo "✅ Homepage content found\n";
    }
    
} else {
    echo "❌ Homepage failed to load\n";
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

// Test articles page
echo "\nTesting articles page...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/articles');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Articles HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Articles page loads successfully\n";
    
    if (strpos($response, 'Article') !== false || strpos($response, 'No articles') !== false) {
        echo "✅ Articles page content found\n";
    }
    
} else {
    echo "❌ Articles page failed to load\n";
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

// Test photobooks page
echo "\nTesting photobooks page...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/photobooks');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Photobooks HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Photobooks page loads successfully\n";
    
    if (strpos($response, 'Photobook') !== false || strpos($response, 'No photobooks') !== false) {
        echo "✅ Photobooks page content found\n";
    }
    
} else {
    echo "❌ Photobooks page failed to load\n";
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

echo "\nFrontend test complete!\n";