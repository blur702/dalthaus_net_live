-- ============================================================================
-- Admin User Seed Data
-- Created: 2025-09-06
-- Description: Ensures admin user 'admin' exists with password '(130Bpm)'
-- ============================================================================

-- Create or update the admin user
INSERT INTO users (user_id, username, email, password_hash, is_admin, created_at)
VALUES (
    1,
    'admin',
    'admin@example.com',
    '$2y$12$bAczsMOhFrwPtZWe4TMXYu095rKXqCC.vu8esgU.YgW2VFdJEBS12', -- Password: (130Bpm)
    1,
    NOW()
)
ON DUPLICATE KEY UPDATE
    password_hash = '$2y$12$bAczsMOhFrwPtZWe4TMXYu095rKXqCC.vu8esgU.YgW2VFdJEBS12',
    is_admin = 1;

-- Ensure the user is active and admin
UPDATE users 
SET password_hash = '$2y$12$bAczsMOhFrwPtZWe4TMXYu095rKXqCC.vu8esgU.YgW2VFdJEBS12',
    is_admin = 1
WHERE username = 'admin';