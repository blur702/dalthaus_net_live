<?php
/**
 * Comprehensive E2E Test Suite
 * Tests all major functionality of the CMS
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

class E2ETestRunner {
    private $baseUrl = 'http://localhost';
    private $cookieFile;
    private $testResults = [];
    private $totalTests = 0;
    private $passedTests = 0;
    private $failedTests = 0;
    private $csrfToken = '';
    
    public function __construct() {
        $this->cookieFile = tempnam(sys_get_temp_dir(), 'e2e_cookies_');
        echo "\n" . str_repeat('=', 80) . "\n";
        echo "CMS COMPREHENSIVE E2E TEST SUITE\n";
        echo str_repeat('=', 80) . "\n\n";
    }
    
    public function __destruct() {
        if (file_exists($this->cookieFile)) {
            unlink($this->cookieFile);
        }
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        $startTime = microtime(true);
        
        // Test Categories
        $this->testPublicPages();
        $this->testAuthentication();
        $this->testDashboard();
        $this->testContentManagement();
        $this->testPageManagement();
        $this->testUserManagement();
        $this->testSettings();
        $this->testMenuManagement();
        $this->testSecurity();
        $this->testFileUploads();
        
        $endTime = microtime(true);
        $duration = round($endTime - $startTime, 2);
        
        $this->generateReport($duration);
    }
    
    /**
     * Test public pages
     */
    private function testPublicPages() {
        $this->printSection("PUBLIC PAGES");
        
        // Test homepage
        $this->test("Homepage loads", function() {
            $response = $this->get('/');
            return $this->assertContains($response, '<title>') && 
                   $this->assertStatusCode($response, 200);
        });
        
        // Test articles page
        $this->test("Articles page loads", function() {
            $response = $this->get('/articles');
            return $this->assertContains($response, 'Articles') && 
                   $this->assertStatusCode($response, 200);
        });
        
        // Test photobooks page
        $this->test("Photobooks page loads", function() {
            $response = $this->get('/photobooks');
            return $this->assertContains($response, 'Photobook') && 
                   $this->assertStatusCode($response, 200);
        });
    }
    
    /**
     * Test authentication
     */
    private function testAuthentication() {
        $this->printSection("AUTHENTICATION");
        
        // Test login page
        $this->test("Login page loads", function() {
            $response = $this->get('/admin/login');
            $this->csrfToken = $this->extractCsrfToken($response);
            return $this->assertContains($response, 'Admin Login') && 
                   !empty($this->csrfToken);
        });
        
        // Test login with invalid credentials
        $this->test("Login fails with invalid credentials", function() {
            $response = $this->post('/admin/login', [
                '_token' => $this->csrfToken,
                'username' => 'invalid',
                'password' => 'wrong'
            ]);
            return $this->assertStatusCode($response, 302);
        });
        
        // Test login with valid credentials
        $this->test("Login succeeds with valid credentials", function() {
            $loginPage = $this->get('/admin/login');
            $this->csrfToken = $this->extractCsrfToken($loginPage);
            
            $response = $this->post('/admin/login', [
                '_token' => $this->csrfToken,
                'username' => 'kevin',
                'password' => '(130Bpm)'
            ], true);
            
            return $this->assertStatusCode($response, 302) ||
                   $this->assertStatusCode($response, 200);
        });
        
        // Test protected route access
        $this->test("Can access admin dashboard after login", function() {
            $response = $this->get('/admin/dashboard');
            return $this->assertContains($response, 'Dashboard') && 
                   $this->assertStatusCode($response, 200);
        });
    }
    
    /**
     * Test dashboard functionality
     */
    private function testDashboard() {
        $this->printSection("DASHBOARD");
        
        $this->test("Dashboard shows statistics", function() {
            $response = $this->get('/admin/dashboard');
            return $this->assertContains($response, 'Total Content') ||
                   $this->assertContains($response, 'Quick Actions');
        });
        
        $this->test("Dashboard has navigation menu", function() {
            $response = $this->get('/admin/dashboard');
            return $this->assertContains($response, 'Content') && 
                   $this->assertContains($response, 'Pages') &&
                   $this->assertContains($response, 'Settings');
        });
    }
    
    /**
     * Test content management
     */
    private function testContentManagement() {
        $this->printSection("CONTENT MANAGEMENT");
        
        // Test content listing
        $this->test("Content listing page loads", function() {
            $response = $this->get('/admin/content');
            return $this->assertContains($response, 'Content Management') && 
                   $this->assertStatusCode($response, 200);
        });
        
        // Test content creation form
        $this->test("Content create form loads", function() {
            $response = $this->get('/admin/content/create?type=article');
            $this->csrfToken = $this->extractCsrfToken($response);
            return $this->assertContains($response, 'Create') && 
                   !empty($this->csrfToken);
        });
        
        // Test content creation
        $this->test("Can create new article", function() {
            $response = $this->post('/admin/content/store', [
                '_token' => $this->csrfToken,
                'title' => 'Test Article ' . time(),
                'url_alias' => 'test-article-' . time(),
                'content_type' => 'article',
                'body' => 'This is a test article body.',
                'teaser' => 'Test teaser',
                'status' => 'draft'
            ]);
            return $this->assertStatusCode($response, 302);
        });
        
        // Test content filtering
        $this->test("Content filtering works", function() {
            $response = $this->get('/admin/content?type=article');
            return $this->assertStatusCode($response, 200);
        });
    }
    
    /**
     * Test page management
     */
    private function testPageManagement() {
        $this->printSection("PAGE MANAGEMENT");
        
        $this->test("Pages listing loads", function() {
            $response = $this->get('/admin/pages');
            return $this->assertContains($response, 'Page') && 
                   $this->assertStatusCode($response, 200);
        });
        
        $this->test("Page create form loads", function() {
            $response = $this->get('/admin/pages/create');
            $this->csrfToken = $this->extractCsrfToken($response);
            return $this->assertContains($response, 'Create') && 
                   !empty($this->csrfToken);
        });
        
        $this->test("Can create new page", function() {
            $response = $this->post('/admin/pages/store', [
                '_token' => $this->csrfToken,
                'title' => 'Test Page ' . time(),
                'url_alias' => 'test-page-' . time(),
                'body' => 'This is a test page body.',
                'status' => 'draft'
            ]);
            return $this->assertStatusCode($response, 302);
        });
    }
    
    /**
     * Test user management
     */
    private function testUserManagement() {
        $this->printSection("USER MANAGEMENT");
        
        $this->test("Users listing loads", function() {
            $response = $this->get('/admin/users');
            return $this->assertContains($response, 'User') && 
                   $this->assertStatusCode($response, 200);
        });
        
        $this->test("User create form loads", function() {
            $response = $this->get('/admin/users/create');
            $this->csrfToken = $this->extractCsrfToken($response);
            return $this->assertContains($response, 'Create') && 
                   !empty($this->csrfToken);
        });
    }
    
    /**
     * Test settings
     */
    private function testSettings() {
        $this->printSection("SETTINGS");
        
        $this->test("Settings page loads", function() {
            $response = $this->get('/admin/settings');
            $this->csrfToken = $this->extractCsrfToken($response);
            return $this->assertContains($response, 'Settings') && 
                   !empty($this->csrfToken);
        });
        
        $this->test("Can update settings", function() {
            $response = $this->post('/admin/settings', [
                '_token' => $this->csrfToken,
                'site_title' => 'Test Site Title',
                'site_motto' => 'Test Motto',
                'admin_email' => 'test@example.com',
                'timezone' => 'America/New_York',
                'date_format' => 'Y-m-d',
                'items_per_page' => '20'
            ]);
            return $this->assertStatusCode($response, 302);
        });
    }
    
    /**
     * Test menu management
     */
    private function testMenuManagement() {
        $this->printSection("MENU MANAGEMENT");
        
        $this->test("Menus page loads", function() {
            $response = $this->get('/admin/menus');
            return $this->assertStatusCode($response, 200);
        });
    }
    
    /**
     * Test security features
     */
    private function testSecurity() {
        $this->printSection("SECURITY");
        
        $this->test("CSRF protection is active", function() {
            $response = $this->post('/admin/settings', [
                'site_title' => 'Test'
            ]);
            return $this->assertStatusCode($response, 302); // Should redirect due to missing CSRF
        });
        
        $this->test("XSS protection in output", function() {
            $response = $this->get('/admin/content');
            return $this->assertContains($response, 'Content-Type') ||
                   !$this->assertContains($response, '<script>alert');
        });
        
        $this->test("Admin routes require authentication", function() {
            // Clear cookies to test as unauthenticated
            $tempCookie = tempnam(sys_get_temp_dir(), 'test_');
            $ch = curl_init($this->baseUrl . '/admin/dashboard');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $tempCookie);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            unlink($tempCookie);
            return $httpCode === 302; // Should redirect to login
        });
    }
    
    /**
     * Test file uploads
     */
    private function testFileUploads() {
        $this->printSection("FILE UPLOADS");
        
        $this->test("Upload directories exist", function() {
            return is_dir(__DIR__ . '/uploads/content') &&
                   is_dir(__DIR__ . '/uploads/settings');
        });
        
        $this->test("Upload directory is writable", function() {
            $testFile = __DIR__ . '/uploads/test_' . time() . '.txt';
            $result = @file_put_contents($testFile, 'test');
            if ($result !== false) {
                unlink($testFile);
                return true;
            }
            return false;
        });
    }
    
    /**
     * Helper: Make GET request
     */
    private function get($url) {
        $ch = curl_init($this->baseUrl . $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookieFile);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'body' => $response,
            'code' => $httpCode
        ];
    }
    
    /**
     * Helper: Make POST request
     */
    private function post($url, $data, $followRedirect = false) {
        $ch = curl_init($this->baseUrl . $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookieFile);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $followRedirect);
        curl_setopt($ch, CURLOPT_HEADER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'body' => $response,
            'code' => $httpCode
        ];
    }
    
    /**
     * Helper: Extract CSRF token
     */
    private function extractCsrfToken($response) {
        if (preg_match('/name="_token"\s+value="([^"]+)"/', $response['body'], $matches)) {
            return $matches[1];
        }
        return '';
    }
    
    /**
     * Helper: Assert response contains string
     */
    private function assertContains($response, $needle) {
        return strpos($response['body'], $needle) !== false;
    }
    
    /**
     * Helper: Assert status code
     */
    private function assertStatusCode($response, $expectedCode) {
        return $response['code'] === $expectedCode;
    }
    
    /**
     * Run a single test
     */
    private function test($name, $callback) {
        $this->totalTests++;
        echo "  Testing: {$name}... ";
        
        try {
            $result = $callback();
            if ($result) {
                echo "\033[32m✓ PASS\033[0m\n";
                $this->passedTests++;
                $this->testResults[] = ['name' => $name, 'status' => 'PASS'];
            } else {
                echo "\033[31m✗ FAIL\033[0m\n";
                $this->failedTests++;
                $this->testResults[] = ['name' => $name, 'status' => 'FAIL'];
            }
        } catch (Exception $e) {
            echo "\033[31m✗ ERROR: " . $e->getMessage() . "\033[0m\n";
            $this->failedTests++;
            $this->testResults[] = ['name' => $name, 'status' => 'ERROR', 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Print section header
     */
    private function printSection($title) {
        echo "\n\033[1;34m" . str_repeat('─', 60) . "\033[0m\n";
        echo "\033[1;34m {$title}\033[0m\n";
        echo "\033[1;34m" . str_repeat('─', 60) . "\033[0m\n\n";
    }
    
    /**
     * Generate final report
     */
    private function generateReport($duration) {
        echo "\n" . str_repeat('=', 80) . "\n";
        echo "TEST RESULTS SUMMARY\n";
        echo str_repeat('=', 80) . "\n\n";
        
        $passRate = $this->totalTests > 0 ? round(($this->passedTests / $this->totalTests) * 100, 2) : 0;
        
        echo "Total Tests: {$this->totalTests}\n";
        echo "\033[32mPassed: {$this->passedTests}\033[0m\n";
        echo "\033[31mFailed: {$this->failedTests}\033[0m\n";
        echo "Pass Rate: {$passRate}%\n";
        echo "Duration: {$duration} seconds\n";
        
        if ($this->failedTests > 0) {
            echo "\n\033[31mFAILED TESTS:\033[0m\n";
            foreach ($this->testResults as $result) {
                if ($result['status'] !== 'PASS') {
                    echo "  - {$result['name']}";
                    if (isset($result['message'])) {
                        echo " ({$result['message']})";
                    }
                    echo "\n";
                }
            }
        }
        
        echo "\n" . str_repeat('=', 80) . "\n";
        
        if ($this->failedTests === 0) {
            echo "\033[32m✓ ALL TESTS PASSED!\033[0m\n";
        } else {
            echo "\033[31m✗ SOME TESTS FAILED\033[0m\n";
        }
        
        echo str_repeat('=', 80) . "\n\n";
        
        // Save detailed report to file
        $this->saveDetailedReport();
    }
    
    /**
     * Save detailed report to file
     */
    private function saveDetailedReport() {
        $report = "CMS E2E TEST REPORT\n";
        $report .= "Generated: " . date('Y-m-d H:i:s') . "\n";
        $report .= str_repeat('=', 80) . "\n\n";
        
        $report .= "SUMMARY\n";
        $report .= "-------\n";
        $report .= "Total Tests: {$this->totalTests}\n";
        $report .= "Passed: {$this->passedTests}\n";
        $report .= "Failed: {$this->failedTests}\n";
        $report .= "Pass Rate: " . ($this->totalTests > 0 ? round(($this->passedTests / $this->totalTests) * 100, 2) : 0) . "%\n\n";
        
        $report .= "DETAILED RESULTS\n";
        $report .= "----------------\n";
        foreach ($this->testResults as $result) {
            $report .= sprintf("%-60s %s\n", $result['name'], $result['status']);
            if (isset($result['message'])) {
                $report .= "  Error: {$result['message']}\n";
            }
        }
        
        file_put_contents(__DIR__ . '/e2e_test_report_' . date('Y-m-d_H-i-s') . '.txt', $report);
        echo "Detailed report saved to: e2e_test_report_" . date('Y-m-d_H-i-s') . ".txt\n";
    }
}

// Run the tests
$runner = new E2ETestRunner();
$runner->runAllTests();