-- ============================================================================
-- Database Maintenance Procedures and Automation
-- Created: 2025-09-06
-- Description: Stored procedures and scripts for automated database maintenance
-- ============================================================================

-- This file contains stored procedures, functions, and maintenance scripts
-- to automate database housekeeping and optimization tasks

DELIMITER $$

-- ============================================================================
-- Session Management Procedures
-- ============================================================================

-- Procedure to clean expired sessions
CREATE PROCEDURE IF NOT EXISTS `clean_expired_sessions`(
    IN session_lifetime_hours INT DEFAULT 2
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE session_count INT DEFAULT 0;
    DECLARE deleted_count INT DEFAULT 0;
    
    -- Count sessions to be cleaned
    SELECT COUNT(*) INTO session_count
    FROM sessions 
    WHERE last_activity < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL session_lifetime_hours HOUR));
    
    -- Delete expired sessions in batches to avoid long locks
    DELETE FROM sessions 
    WHERE last_activity < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL session_lifetime_hours HOUR))
    LIMIT 1000;
    
    -- Get number of deleted sessions
    SET deleted_count = ROW_COUNT();
    
    -- Log the cleanup activity
    INSERT INTO audit_logs (user_id, action, object_type, details) 
    VALUES (NULL, 'session_cleanup', 'system', 
            JSON_OBJECT('deleted_sessions', deleted_count, 'total_found', session_count));
    
    -- Return results
    SELECT deleted_count as sessions_deleted, session_count as sessions_found;
END$$

-- ============================================================================
-- Security Maintenance Procedures
-- ============================================================================

-- Procedure to clean old login attempts
CREATE PROCEDURE IF NOT EXISTS `clean_old_login_attempts`(
    IN retention_days INT DEFAULT 30
)
BEGIN
    DECLARE deleted_count INT DEFAULT 0;
    
    -- Clean old login attempts in batches
    DELETE FROM login_attempts 
    WHERE attempted_at < DATE_SUB(NOW(), INTERVAL retention_days DAY)
    LIMIT 5000;
    
    SET deleted_count = ROW_COUNT();
    
    -- Log cleanup activity
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'login_attempts_cleanup', 'system', 
            JSON_OBJECT('deleted_records', deleted_count, 'retention_days', retention_days));
    
    SELECT deleted_count as records_deleted;
END$$

-- Procedure to clean old audit logs
CREATE PROCEDURE IF NOT EXISTS `clean_old_audit_logs`(
    IN retention_days INT DEFAULT 365
)
BEGIN
    DECLARE deleted_count INT DEFAULT 0;
    DECLARE total_before INT DEFAULT 0;
    
    -- Count logs before cleanup
    SELECT COUNT(*) INTO total_before FROM audit_logs;
    
    -- Clean old audit logs in batches
    DELETE FROM audit_logs 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL retention_days DAY)
      AND action NOT IN ('critical_security_event', 'data_breach', 'unauthorized_access')
    LIMIT 10000;
    
    SET deleted_count = ROW_COUNT();
    
    -- Note: We preserve critical security events regardless of age
    SELECT deleted_count as records_deleted, total_before as total_before_cleanup;
END$$

-- ============================================================================
-- Content Management Procedures  
-- ============================================================================

-- Procedure to clean up orphaned content records
CREATE PROCEDURE IF NOT EXISTS `cleanup_orphaned_content`()
BEGIN
    DECLARE orphaned_count INT DEFAULT 0;
    
    -- Count orphaned content (content without valid user)
    SELECT COUNT(*) INTO orphaned_count
    FROM content c
    LEFT JOIN users u ON c.user_id = u.user_id
    WHERE u.user_id IS NULL;
    
    IF orphaned_count > 0 THEN
        -- Log orphaned content before cleanup
        INSERT INTO audit_logs (user_id, action, object_type, details)
        VALUES (NULL, 'orphaned_content_found', 'system', 
                JSON_OBJECT('orphaned_count', orphaned_count));
        
        -- Update orphaned content to assign to a default user or mark for review
        -- Note: Adjust user_id = 1 to your default admin user ID
        UPDATE content c
        LEFT JOIN users u ON c.user_id = u.user_id
        SET c.user_id = 1  -- Default admin user
        WHERE u.user_id IS NULL;
        
        SELECT CONCAT('Updated ', orphaned_count, ' orphaned content records') as result;
    ELSE
        SELECT 'No orphaned content found' as result;
    END IF;
END$$

-- Procedure to update content statistics and cache
CREATE PROCEDURE IF NOT EXISTS `update_content_statistics`()
BEGIN
    DECLARE total_content INT DEFAULT 0;
    DECLARE published_content INT DEFAULT 0;
    DECLARE draft_content INT DEFAULT 0;
    DECLARE total_articles INT DEFAULT 0;
    DECLARE total_photobooks INT DEFAULT 0;
    
    -- Calculate content statistics
    SELECT 
        COUNT(*),
        COUNT(CASE WHEN status = 'published' THEN 1 END),
        COUNT(CASE WHEN status = 'draft' THEN 1 END),
        COUNT(CASE WHEN content_type = 'article' THEN 1 END),
        COUNT(CASE WHEN content_type = 'photobook' THEN 1 END)
    INTO total_content, published_content, draft_content, total_articles, total_photobooks
    FROM content;
    
    -- Update or insert statistics into settings table
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_total_content', total_content)
    ON DUPLICATE KEY UPDATE setting_value = total_content;
    
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_published_content', published_content)
    ON DUPLICATE KEY UPDATE setting_value = published_content;
    
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_draft_content', draft_content)
    ON DUPLICATE KEY UPDATE setting_value = draft_content;
    
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_total_articles', total_articles)
    ON DUPLICATE KEY UPDATE setting_value = total_articles;
    
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_total_photobooks', total_photobooks)
    ON DUPLICATE KEY UPDATE setting_value = total_photobooks;
    
    INSERT INTO settings (setting_name, setting_value) 
    VALUES ('stats_last_updated', NOW())
    ON DUPLICATE KEY UPDATE setting_value = NOW();
    
    SELECT 'Content statistics updated successfully' as result,
           total_content, published_content, draft_content, total_articles, total_photobooks;
END$$

-- ============================================================================
-- Performance Optimization Procedures
-- ============================================================================

-- Procedure to analyze and optimize tables
CREATE PROCEDURE IF NOT EXISTS `optimize_tables_maintenance`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE table_name VARCHAR(128);
    DECLARE fragmentation_pct DECIMAL(5,2);
    DECLARE optimized_count INT DEFAULT 0;
    
    -- Cursor to get fragmented tables
    DECLARE fragmented_tables CURSOR FOR
        SELECT TABLE_NAME, 
               ROUND((DATA_FREE / (DATA_LENGTH + INDEX_LENGTH)) * 100, 2) as fragmentation
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND DATA_FREE > 1024 * 1024  -- At least 1MB free space
          AND (DATA_FREE / (DATA_LENGTH + INDEX_LENGTH)) > 0.10  -- More than 10% fragmented
          AND TABLE_TYPE = 'BASE TABLE';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN fragmented_tables;
    
    read_loop: LOOP
        FETCH fragmented_tables INTO table_name, fragmentation_pct;
        
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Log optimization start
        INSERT INTO audit_logs (user_id, action, object_type, object_id, details)
        VALUES (NULL, 'table_optimize_start', 'table', NULL, 
                JSON_OBJECT('table_name', table_name, 'fragmentation_percent', fragmentation_pct));
        
        -- Optimize the table
        SET @sql = CONCAT('OPTIMIZE TABLE `', table_name, '`');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        SET optimized_count = optimized_count + 1;
        
        -- Log optimization completion
        INSERT INTO audit_logs (user_id, action, object_type, object_id, details)
        VALUES (NULL, 'table_optimize_complete', 'table', NULL, 
                JSON_OBJECT('table_name', table_name, 'fragmentation_percent', fragmentation_pct));
    END LOOP;
    
    CLOSE fragmented_tables;
    
    SELECT optimized_count as tables_optimized, 'Table optimization maintenance completed' as result;
END$$

-- ============================================================================
-- Security Monitoring Procedures
-- ============================================================================

-- Procedure to check for suspicious login patterns
CREATE PROCEDURE IF NOT EXISTS `detect_suspicious_logins`(
    IN time_window_hours INT DEFAULT 1,
    IN max_attempts_threshold INT DEFAULT 10
)
BEGIN
    DECLARE suspicious_ips_count INT DEFAULT 0;
    
    -- Create temporary table for results
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_suspicious_ips (
        ip_address VARCHAR(45),
        failed_attempts INT,
        unique_accounts_targeted INT,
        first_attempt TIMESTAMP,
        last_attempt TIMESTAMP
    );
    
    -- Insert suspicious IPs into temp table
    INSERT INTO temp_suspicious_ips
    SELECT 
        ip_address,
        COUNT(*) as failed_attempts,
        COUNT(DISTINCT identifier) as unique_accounts_targeted,
        MIN(attempted_at) as first_attempt,
        MAX(attempted_at) as last_attempt
    FROM login_attempts 
    WHERE success = 0 
      AND attempted_at >= DATE_SUB(NOW(), INTERVAL time_window_hours HOUR)
    GROUP BY ip_address
    HAVING failed_attempts >= max_attempts_threshold;
    
    SELECT COUNT(*) INTO suspicious_ips_count FROM temp_suspicious_ips;
    
    -- Log suspicious activity if found
    IF suspicious_ips_count > 0 THEN
        INSERT INTO security_events (event_type, severity, description, request_data)
        SELECT 
            'suspicious_login_pattern' as event_type,
            'high' as severity,
            CONCAT('Detected ', failed_attempts, ' failed login attempts from IP ', ip_address, 
                   ' targeting ', unique_accounts_targeted, ' different accounts') as description,
            JSON_OBJECT(
                'ip_address', ip_address,
                'failed_attempts', failed_attempts,
                'unique_accounts_targeted', unique_accounts_targeted,
                'time_window_hours', time_window_hours
            ) as request_data
        FROM temp_suspicious_ips;
        
        -- Auto-block IPs with extremely high attempts
        INSERT INTO blocked_ips (ip_address, reason, auto_blocked, blocked_until)
        SELECT 
            ip_address,
            CONCAT('Auto-blocked: ', failed_attempts, ' failed attempts in ', time_window_hours, ' hours'),
            1,
            DATE_ADD(NOW(), INTERVAL 24 HOUR)
        FROM temp_suspicious_ips
        WHERE failed_attempts >= (max_attempts_threshold * 2)  -- Double the threshold for auto-block
        ON DUPLICATE KEY UPDATE 
            blocked_until = DATE_ADD(NOW(), INTERVAL 24 HOUR),
            reason = CONCAT(reason, ' [Extended: ', NOW(), ']');
    END IF;
    
    -- Return results
    SELECT * FROM temp_suspicious_ips;
    
    DROP TEMPORARY TABLE temp_suspicious_ips;
    
    SELECT suspicious_ips_count as suspicious_ips_found;
END$$

-- ============================================================================
-- File Management Procedures
-- ============================================================================

-- Procedure to clean orphaned file uploads
CREATE PROCEDURE IF NOT EXISTS `cleanup_orphaned_files`()
BEGIN
    DECLARE orphaned_files_count INT DEFAULT 0;
    
    -- Count orphaned file records (uploads by deleted users)
    SELECT COUNT(*) INTO orphaned_files_count
    FROM file_uploads f
    LEFT JOIN users u ON f.uploaded_by = u.user_id
    WHERE u.user_id IS NULL;
    
    IF orphaned_files_count > 0 THEN
        -- Log orphaned files cleanup
        INSERT INTO audit_logs (user_id, action, object_type, details)
        VALUES (NULL, 'orphaned_files_cleanup', 'system', 
                JSON_OBJECT('orphaned_files_count', orphaned_files_count));
        
        -- Mark orphaned files for manual review instead of auto-deletion
        -- Create a cleanup table if it doesn't exist
        CREATE TABLE IF NOT EXISTS `cleanup_queue` (
            cleanup_id INT AUTO_INCREMENT PRIMARY KEY,
            cleanup_type VARCHAR(50) NOT NULL,
            object_id INT NOT NULL,
            object_data JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            processed_at TIMESTAMP NULL,
            INDEX idx_cleanup_type (cleanup_type),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        
        -- Queue orphaned files for manual review
        INSERT INTO cleanup_queue (cleanup_type, object_id, object_data)
        SELECT 
            'orphaned_file',
            f.upload_id,
            JSON_OBJECT(
                'filename', f.filename,
                'original_name', f.original_name,
                'size', f.size,
                'uploaded_at', f.uploaded_at,
                'deleted_user_id', f.uploaded_by
            )
        FROM file_uploads f
        LEFT JOIN users u ON f.uploaded_by = u.user_id
        WHERE u.user_id IS NULL;
        
        SELECT CONCAT('Queued ', orphaned_files_count, ' orphaned files for manual review') as result;
    ELSE
        SELECT 'No orphaned files found' as result;
    END IF;
END$$

-- ============================================================================
-- Health Check Procedures
-- ============================================================================

-- Comprehensive database health check
CREATE PROCEDURE IF NOT EXISTS `database_health_check`()
BEGIN
    DECLARE db_size_mb DECIMAL(10,2);
    DECLARE largest_table VARCHAR(128);
    DECLARE largest_table_size_mb DECIMAL(10,2);
    DECLARE active_connections INT;
    DECLARE max_connections INT;
    DECLARE connection_usage_pct DECIMAL(5,2);
    DECLARE slow_queries_count INT;
    
    -- Get database size
    SELECT ROUND(SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) INTO db_size_mb
    FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA = DATABASE();
    
    -- Get largest table
    SELECT TABLE_NAME, ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2)
    INTO largest_table, largest_table_size_mb
    FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA = DATABASE()
    ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC 
    LIMIT 1;
    
    -- Get connection statistics
    SELECT VARIABLE_VALUE INTO active_connections 
    FROM GLOBAL_STATUS WHERE VARIABLE_NAME = 'Threads_connected';
    
    SET max_connections = @@max_connections;
    SET connection_usage_pct = ROUND((active_connections / max_connections) * 100, 2);
    
    -- Count slow queries in the last hour
    SELECT COUNT(*) INTO slow_queries_count
    FROM performance_schema.events_statements_summary_by_digest
    WHERE AVG_TIMER_WAIT > 1000000000000  -- Queries taking more than 1 second
      AND LAST_SEEN >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Log health check results
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'database_health_check', 'system', 
            JSON_OBJECT(
                'database_size_mb', db_size_mb,
                'largest_table', largest_table,
                'largest_table_size_mb', largest_table_size_mb,
                'active_connections', active_connections,
                'max_connections', max_connections,
                'connection_usage_pct', connection_usage_pct,
                'slow_queries_last_hour', slow_queries_count
            ));
    
    -- Return health check results
    SELECT 
        'DATABASE HEALTH CHECK' as check_type,
        db_size_mb as database_size_mb,
        largest_table as largest_table,
        largest_table_size_mb as largest_table_size_mb,
        active_connections as current_connections,
        max_connections as max_connections,
        connection_usage_pct as connection_usage_percent,
        slow_queries_count as slow_queries_last_hour,
        CASE 
            WHEN connection_usage_pct > 80 THEN 'WARNING: High connection usage'
            WHEN slow_queries_count > 10 THEN 'WARNING: High number of slow queries'
            WHEN db_size_mb > 1000 THEN 'INFO: Database size exceeds 1GB'
            ELSE 'OK'
        END as health_status;
END$$

-- ============================================================================
-- Automated Maintenance Scheduler
-- ============================================================================

-- Master maintenance procedure that runs all maintenance tasks
CREATE PROCEDURE IF NOT EXISTS `run_daily_maintenance`()
BEGIN
    DECLARE maintenance_start TIMESTAMP DEFAULT NOW();
    DECLARE maintenance_errors TEXT DEFAULT '';
    DECLARE continue_handler_error INT DEFAULT 0;
    
    -- Error handler for maintenance tasks
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1
            @sql_state = RETURNED_SQLSTATE,
            @error_message = MESSAGE_TEXT;
        SET maintenance_errors = CONCAT(maintenance_errors, 
                                      'Error: ', @error_message, '; ');
        SET continue_handler_error = 1;
    END;
    
    -- Log maintenance start
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'daily_maintenance_start', 'system', 
            JSON_OBJECT('start_time', maintenance_start));
    
    -- Run maintenance tasks
    
    -- 1. Clean expired sessions (older than 2 hours)
    CALL clean_expired_sessions(2);
    
    -- 2. Clean old login attempts (older than 30 days)
    CALL clean_old_login_attempts(30);
    
    -- 3. Clean old audit logs (older than 365 days, except critical events)
    CALL clean_old_audit_logs(365);
    
    -- 4. Update content statistics cache
    CALL update_content_statistics();
    
    -- 5. Check for suspicious login patterns
    CALL detect_suspicious_logins(24, 5);
    
    -- 6. Clean up orphaned content
    CALL cleanup_orphaned_content();
    
    -- 7. Clean up orphaned files
    CALL cleanup_orphaned_files();
    
    -- 8. Run database health check
    CALL database_health_check();
    
    -- Log maintenance completion
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'daily_maintenance_complete', 'system', 
            JSON_OBJECT(
                'start_time', maintenance_start,
                'end_time', NOW(),
                'duration_minutes', TIMESTAMPDIFF(MINUTE, maintenance_start, NOW()),
                'errors', CASE WHEN maintenance_errors = '' THEN NULL ELSE maintenance_errors END,
                'success', CASE WHEN continue_handler_error = 0 THEN 'true' ELSE 'false' END
            ));
    
    -- Return maintenance summary
    SELECT 
        'DAILY MAINTENANCE COMPLETED' as status,
        maintenance_start as started_at,
        NOW() as completed_at,
        TIMESTAMPDIFF(MINUTE, maintenance_start, NOW()) as duration_minutes,
        CASE 
            WHEN maintenance_errors = '' THEN 'SUCCESS'
            ELSE 'COMPLETED_WITH_ERRORS'
        END as result,
        CASE 
            WHEN maintenance_errors = '' THEN NULL
            ELSE maintenance_errors
        END as errors;
END$$

-- Weekly maintenance procedure
CREATE PROCEDURE IF NOT EXISTS `run_weekly_maintenance`()
BEGIN
    DECLARE maintenance_start TIMESTAMP DEFAULT NOW();
    
    -- Log weekly maintenance start
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'weekly_maintenance_start', 'system', 
            JSON_OBJECT('start_time', maintenance_start));
    
    -- Run weekly tasks
    
    -- 1. Optimize fragmented tables
    CALL optimize_tables_maintenance();
    
    -- 2. Analyze all tables to update statistics
    ANALYZE TABLE content, users, pages, login_attempts, audit_logs, 
                  sessions, menu_items, settings, menus, blocked_ips,
                  security_events, file_uploads, password_resets;
    
    -- Log weekly maintenance completion
    INSERT INTO audit_logs (user_id, action, object_type, details)
    VALUES (NULL, 'weekly_maintenance_complete', 'system', 
            JSON_OBJECT(
                'start_time', maintenance_start,
                'end_time', NOW(),
                'duration_minutes', TIMESTAMPDIFF(MINUTE, maintenance_start, NOW())
            ));
    
    SELECT 'WEEKLY MAINTENANCE COMPLETED' as status,
           TIMESTAMPDIFF(MINUTE, maintenance_start, NOW()) as duration_minutes;
END$$

DELIMITER ;

-- ============================================================================
-- Cron Job Setup Examples
-- ============================================================================

-- Add these to your system crontab (crontab -e) for automated maintenance:

-- Daily maintenance at 2 AM
-- 0 2 * * * mysql -u username -p'password' database_name -e "CALL run_daily_maintenance();"

-- Weekly maintenance on Sundays at 3 AM  
-- 0 3 * * 0 mysql -u username -p'password' database_name -e "CALL run_weekly_maintenance();"

-- Health check every 6 hours
-- 0 */6 * * * mysql -u username -p'password' database_name -e "CALL database_health_check();"

-- Clean sessions every hour
-- 0 * * * * mysql -u username -p'password' database_name -e "CALL clean_expired_sessions(2);"

-- ============================================================================
-- Manual Maintenance Commands
-- ============================================================================

-- To run maintenance manually, use these commands:

-- CALL run_daily_maintenance();
-- CALL run_weekly_maintenance();
-- CALL database_health_check();
-- CALL clean_expired_sessions(2);
-- CALL optimize_tables_maintenance();

-- ============================================================================
-- Monitoring and Alerts Setup
-- ============================================================================

-- Create alerts table for automated notifications
CREATE TABLE IF NOT EXISTS `maintenance_alerts` (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    alert_type VARCHAR(50) NOT NULL,
    severity ENUM('info', 'warning', 'error', 'critical') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    alert_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_at TIMESTAMP NULL,
    acknowledged_by INT NULL,
    INDEX idx_alert_type (alert_type),
    INDEX idx_severity (severity),
    INDEX idx_created_at (created_at),
    INDEX idx_acknowledged (acknowledged)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Example: Insert alert for high database size
-- INSERT INTO maintenance_alerts (alert_type, severity, title, message, alert_data)
-- VALUES ('database_size', 'warning', 'Database Size Alert', 
--         'Database size has exceeded 1GB threshold',
--         JSON_OBJECT('current_size_mb', 1024, 'threshold_mb', 1000));

-- ============================================================================
-- Performance Tuning Recommendations
-- ============================================================================

-- These settings can be added to your MySQL configuration (my.cnf):
/*
[mysqld]
# InnoDB Buffer Pool (set to 70-80% of available RAM)
innodb_buffer_pool_size = 1G

# Query Cache (if using MySQL 5.7 or earlier)
query_cache_type = 1
query_cache_size = 256M

# Connection settings
max_connections = 200
wait_timeout = 600

# Logging
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 1

# InnoDB settings
innodb_flush_log_at_trx_commit = 1
innodb_file_per_table = 1
innodb_buffer_pool_instances = 4
*/

-- ============================================================================
-- Completion Message
-- ============================================================================

SELECT 'Database maintenance procedures created successfully!' as status,
       'Set up cron jobs to automate daily and weekly maintenance' as next_step,
       'Monitor maintenance_alerts table for issues' as monitoring;