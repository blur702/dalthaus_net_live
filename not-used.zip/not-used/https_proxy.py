#!/usr/bin/env python3
import ssl
import http.server
import socketserver
import urllib.request
import sys

class ProxyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Proxy to local PHP server on port 80
        try:
            url = f"http://localhost:80{self.path}"
            with urllib.request.urlopen(url) as response:
                self.send_response(200)
                self.send_header('Content-Type', response.headers.get('Content-Type', 'text/html'))
                self.end_headers()
                self.wfile.write(response.read())
        except Exception as e:
            self.send_error(502, f"Bad Gateway: {str(e)}")
    
    def do_POST(self):
        self.do_GET()

PORT = 443
Handler = ProxyHTTPRequestHandler

httpd = socketserver.TCPServer(("", PORT), Handler)

# Create SSL context
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain('/Users/kevin/PhpstormProjects/dalthaus_net_live/ssl/localhost.crt',
                        '/Users/kevin/PhpstormProjects/dalthaus_net_live/ssl/localhost.key')

# Wrap with SSL
httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

print(f"HTTPS Server running on https://localhost:{PORT}/")
httpd.serve_forever()