<?php
/**
 * Admin Setup Script
 * 
 * Ensures the admin user 'kevin' exists with the correct password
 * Run this script to reset the admin password if needed
 * 
 * Usage: php setup_admin.php
 */

require_once __DIR__ . '/config/config.php';

$config = require __DIR__ . '/config/config.php';

try {
    // Connect to database
    $dsn = "mysql:host={$config['database']['host']};dbname={$config['database']['dbname']};charset=utf8mb4";
    $pdo = new PDO(
        $dsn,
        $config['database']['username'],
        $config['database']['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    
    echo "Connected to database successfully.\n";
    
    // The permanent admin credentials
    $username = 'kevin';
    $password = '(130Bpm)';
    $email = 'kevin.althaus@gmail.com';
    
    // Generate password hash
    $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    
    // Check if user exists
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Update existing user
        $stmt = $pdo->prepare("\n            UPDATE users \n            SET password_hash = ?, \n                email = ?\n            WHERE username = ?\n        ");
        $stmt->execute([$passwordHash, $email, $username]);
        echo "Admin user 'kevin' password updated successfully.\n";
    } else {
        // Create new user
        $stmt = $pdo->prepare("\n            INSERT INTO users (username, email, password_hash, created_at) \n            VALUES (?, ?, ?, NOW())\n        ");
        $stmt->execute([$username, $email, $passwordHash]);
        echo "Admin user 'kevin' created successfully.\n";
    }
    
    echo "\n";
    echo "========================================\n";
    echo "Admin Login Credentials:\n";
    echo "========================================\n";
    echo "URL:      http://localhost/admin/login\n";
    echo "Username: kevin\n";
    echo "Password: (130Bpm)\n";
    echo "========================================\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}