<?php

declare(strict_types=1);

namespace Tests\Fixtures;

use Faker\Factory as FakerFactory;
use Faker\Generator;

/**
 * User Fixture
 * 
 * Provides test data and factory methods for User model testing.
 * Includes various user scenarios and edge cases.
 */
class UserFixture
{
    private Generator $faker;

    public function __construct()
    {
        $this->faker = FakerFactory::create();
    }

    /**
     * Get default admin user data
     * 
     * @return array
     */
    public function getAdminUser(): array
    {
        return [
            'username' => 'admin',
            'email' => 'admin@cms.local',
            'password_hash' => password_hash('AdminPassword123!', PASSWORD_DEFAULT),
            'created_at' => '2024-01-01 00:00:00',
            'updated_at' => '2024-01-01 00:00:00'
        ];
    }

    /**
     * Get default editor user data
     * 
     * @return array
     */
    public function getEditorUser(): array
    {
        return [
            'username' => 'editor',
            'email' => 'editor@cms.local',
            'password_hash' => password_hash('EditorPassword123!', PASSWORD_DEFAULT),
            'created_at' => '2024-01-02 00:00:00',
            'updated_at' => '2024-01-02 00:00:00'
        ];
    }

    /**
     * Get regular user data
     * 
     * @return array
     */
    public function getRegularUser(): array
    {
        return [
            'username' => 'user',
            'email' => 'user@cms.local',
            'password_hash' => password_hash('UserPassword123!', PASSWORD_DEFAULT),
            'created_at' => '2024-01-03 00:00:00',
            'updated_at' => '2024-01-03 00:00:00'
        ];
    }

    /**
     * Generate random user data
     * 
     * @param array $overrides Field overrides
     * @return array
     */
    public function generateUser(array $overrides = []): array
    {
        return array_merge([
            'username' => $this->faker->userName(),
            'email' => $this->faker->unique()->email(),
            'password_hash' => password_hash($this->faker->password(8), PASSWORD_DEFAULT),
            'created_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'updated_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s')
        ], $overrides);
    }

    /**
     * Generate multiple users
     * 
     * @param int $count Number of users to generate
     * @param array $overrides Common field overrides
     * @return array
     */
    public function generateUsers(int $count, array $overrides = []): array
    {
        $users = [];
        for ($i = 0; $i < $count; $i++) {
            $users[] = $this->generateUser($overrides);
        }
        return $users;
    }

    /**
     * Get user data for validation testing
     * 
     * @return array
     */
    public function getValidationTestCases(): array
    {
        return [
            'valid_user' => [
                'data' => [
                    'username' => 'validuser',
                    'email' => 'valid@example.com',
                    'password' => 'ValidPassword123'
                ],
                'should_pass' => true
            ],
            'empty_username' => [
                'data' => [
                    'username' => '',
                    'email' => 'test@example.com',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['username']
            ],
            'short_username' => [
                'data' => [
                    'username' => 'ab',
                    'email' => 'test@example.com',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['username']
            ],
            'long_username' => [
                'data' => [
                    'username' => str_repeat('a', 51),
                    'email' => 'test@example.com',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['username']
            ],
            'invalid_username_chars' => [
                'data' => [
                    'username' => 'user@name!',
                    'email' => 'test@example.com',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['username']
            ],
            'empty_email' => [
                'data' => [
                    'username' => 'testuser',
                    'email' => '',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['email']
            ],
            'invalid_email' => [
                'data' => [
                    'username' => 'testuser',
                    'email' => 'invalid-email',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['email']
            ],
            'long_email' => [
                'data' => [
                    'username' => 'testuser',
                    'email' => str_repeat('a', 90) . '@example.com',
                    'password' => 'Password123'
                ],
                'should_pass' => false,
                'expected_errors' => ['email']
            ],
            'empty_password' => [
                'data' => [
                    'username' => 'testuser',
                    'email' => 'test@example.com',
                    'password' => ''
                ],
                'should_pass' => false,
                'expected_errors' => ['password']
            ],
            'short_password' => [
                'data' => [
                    'username' => 'testuser',
                    'email' => 'test@example.com',
                    'password' => '1234567'
                ],
                'should_pass' => false,
                'expected_errors' => ['password']
            ]
        ];
    }

    /**
     * Get user data for security testing
     * 
     * @return array
     */
    public function getSecurityTestCases(): array
    {
        return [
            'sql_injection_username' => [
                'username' => "admin'; DROP TABLE users; --",
                'email' => 'hacker@example.com',
                'password' => 'Password123'
            ],
            'xss_username' => [
                'username' => '<script>alert("xss")</script>',
                'email' => 'xss@example.com',
                'password' => 'Password123'
            ],
            'xss_email' => [
                'username' => 'xssuser',
                'email' => '<script>alert("xss")</script>@example.com',
                'password' => 'Password123'
            ],
            'unicode_username' => [
                'username' => '用户名',
                'email' => 'unicode@example.com',
                'password' => 'Password123'
            ],
            'null_byte_username' => [
                'username' => "user\0name",
                'email' => 'nullbyte@example.com',
                'password' => 'Password123'
            ]
        ];
    }

    /**
     * Get edge case user data
     * 
     * @return array
     */
    public function getEdgeCases(): array
    {
        return [
            'minimum_valid_user' => [
                'username' => 'abc',
                'email' => 'a@b.c',
                'password' => '12345678'
            ],
            'maximum_username' => [
                'username' => str_repeat('a', 50),
                'email' => 'max@example.com',
                'password' => 'Password123'
            ],
            'maximum_email' => [
                'username' => 'maxemail',
                'email' => str_repeat('a', 89) . '@b.c',
                'password' => 'Password123'
            ],
            'special_chars_allowed' => [
                'username' => 'user_name-123',
                'email' => 'user.name+tag@example.co.uk',
                'password' => 'Password123!@#$%^&*()'
            ],
            'case_sensitive' => [
                'username' => 'CamelCaseUser',
                'email' => 'CamelCase@Example.COM',
                'password' => 'Password123'
            ]
        ];
    }

    /**
     * Get password test cases
     * 
     * @return array
     */
    public function getPasswordTestCases(): array
    {
        return [
            'weak_passwords' => [
                '123456',
                'password',
                'qwerty',
                '12345678',
                'abc123',
                'password123',
                '1234',
                'pass',
                ''
            ],
            'medium_passwords' => [
                'Password1',
                'MyPassword',
                'user123456',
                'TestPassword',
                'SecurePass1'
            ],
            'strong_passwords' => [
                'MyS3cur3P@ssw0rd!',
                'C0mpl3x!P@ssw0rd123',
                'Str0ng_P@ssw0rd_2024',
                'MyV3ryS3cur3!P@ss',
                'Ungu3ss@bl3_P@ssw0rd!'
            ]
        ];
    }

    /**
     * Get user data for authentication testing
     * 
     * @return array
     */
    public function getAuthTestUsers(): array
    {
        return [
            'locked_user' => [
                'username' => 'lockeduser',
                'email' => 'locked@example.com',
                'password_hash' => password_hash('CorrectPassword123', PASSWORD_DEFAULT),
                'locked_until' => date('Y-m-d H:i:s', strtotime('+1 hour'))
            ],
            'inactive_user' => [
                'username' => 'inactiveuser',
                'email' => 'inactive@example.com',
                'password_hash' => password_hash('Password123', PASSWORD_DEFAULT),
                'status' => 'inactive'
            ],
            'expired_user' => [
                'username' => 'expireduser',
                'email' => 'expired@example.com',
                'password_hash' => password_hash('Password123', PASSWORD_DEFAULT),
                'expires_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
            ]
        ];
    }

    /**
     * Get bulk user data for performance testing
     * 
     * @param int $count Number of users
     * @return array
     */
    public function getBulkUsers(int $count): array
    {
        $users = [];
        $baseTimestamp = strtotime('2024-01-01 00:00:00');
        
        for ($i = 1; $i <= $count; $i++) {
            $timestamp = date('Y-m-d H:i:s', $baseTimestamp + ($i * 3600));
            
            $users[] = [
                'username' => "bulkuser{$i}",
                'email' => "bulkuser{$i}@example.com",
                'password_hash' => password_hash("BulkPassword{$i}", PASSWORD_DEFAULT),
                'created_at' => $timestamp,
                'updated_at' => $timestamp
            ];
        }
        
        return $users;
    }

    /**
     * Get user data with relationships
     * 
     * @return array
     */
    public function getUserWithRelationships(): array
    {
        return [
            'user' => [
                'username' => 'authoruser',
                'email' => 'author@example.com',
                'password_hash' => password_hash('AuthorPassword123', PASSWORD_DEFAULT),
                'created_at' => '2024-01-01 00:00:00',
                'updated_at' => '2024-01-01 00:00:00'
            ],
            'content' => [
                [
                    'title' => 'Author Article 1',
                    'content_type' => 'article',
                    'status' => 'published',
                    'created_at' => '2024-01-02 00:00:00'
                ],
                [
                    'title' => 'Author Article 2',
                    'content_type' => 'article',
                    'status' => 'draft',
                    'created_at' => '2024-01-03 00:00:00'
                ],
                [
                    'title' => 'Author Photobook 1',
                    'content_type' => 'photobook',
                    'status' => 'published',
                    'created_at' => '2024-01-04 00:00:00'
                ]
            ]
        ];
    }

    /**
     * Get user update scenarios
     * 
     * @return array
     */
    public function getUpdateScenarios(): array
    {
        return [
            'valid_update' => [
                'original' => [
                    'username' => 'originaluser',
                    'email' => 'original@example.com'
                ],
                'update' => [
                    'username' => 'updateduser',
                    'email' => 'updated@example.com'
                ],
                'should_succeed' => true
            ],
            'duplicate_username_update' => [
                'original' => [
                    'username' => 'user1',
                    'email' => 'user1@example.com'
                ],
                'update' => [
                    'username' => 'admin', // Assuming admin already exists
                    'email' => 'user1@example.com'
                ],
                'should_succeed' => false
            ],
            'duplicate_email_update' => [
                'original' => [
                    'username' => 'user2',
                    'email' => 'user2@example.com'
                ],
                'update' => [
                    'username' => 'user2',
                    'email' => 'admin@cms.local' // Assuming admin email already exists
                ],
                'should_succeed' => false
            ]
        ];
    }
}