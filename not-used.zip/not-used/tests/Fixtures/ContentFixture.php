<?php

declare(strict_types=1);

namespace Tests\Fixtures;

use Faker\Factory as FakerFactory;
use Faker\Generator;

/**
 * Content Fixture
 * 
 * Provides test data and factory methods for Content model testing.
 * Includes various content scenarios, types, and edge cases.
 */
class ContentFixture
{
    private Generator $faker;

    public function __construct()
    {
        $this->faker = FakerFactory::create();
    }

    /**
     * Get default article data
     * 
     * @return array
     */
    public function getDefaultArticle(): array
    {
        return [
            'title' => 'Default Test Article',
            'teaser' => 'This is a test article teaser for testing purposes.',
            'body' => '<p>This is the full article content with <strong>HTML formatting</strong>.</p>',
            'content_type' => 'article',
            'status' => 'published',
            'url_alias' => 'default-test-article',
            'sort_order' => 1,
            'user_id' => 1,
            'published_at' => '2024-01-01 12:00:00',
            'created_at' => '2024-01-01 10:00:00',
            'updated_at' => '2024-01-01 12:00:00'
        ];
    }

    /**
     * Get default photobook data
     * 
     * @return array
     */
    public function getDefaultPhotobook(): array
    {
        return [
            'title' => 'Default Test Photobook',
            'teaser' => 'This is a test photobook with sample images.',
            'body' => '<p>Photobook description with image galleries.</p>',
            'content_type' => 'photobook',
            'status' => 'published',
            'url_alias' => 'default-test-photobook',
            'sort_order' => 2,
            'featured_image' => 'featured_photo.jpg',
            'user_id' => 1,
            'published_at' => '2024-01-02 12:00:00',
            'created_at' => '2024-01-02 10:00:00',
            'updated_at' => '2024-01-02 12:00:00'
        ];
    }

    /**
     * Generate random article data
     * 
     * @param array $overrides Field overrides
     * @return array
     */
    public function generateArticle(array $overrides = []): array
    {
        $title = $this->faker->sentence(4);
        
        return array_merge([
            'title' => $title,
            'teaser' => $this->faker->paragraph(3),
            'body' => $this->generateArticleBody(),
            'content_type' => 'article',
            'status' => $this->faker->randomElement(['draft', 'published']),
            'url_alias' => $this->generateUrlAlias($title),
            'sort_order' => $this->faker->numberBetween(1, 100),
            'teaser_image' => $this->faker->optional(0.6)->randomElement([
                'teaser1.jpg', 'teaser2.jpg', 'teaser3.png'
            ]),
            'user_id' => 1,
            'published_at' => $this->faker->optional(0.7)->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'created_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'updated_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s')
        ], $overrides);
    }

    /**
     * Generate random photobook data
     * 
     * @param array $overrides Field overrides
     * @return array
     */
    public function generatePhotobook(array $overrides = []): array
    {
        $title = 'Photo Collection: ' . $this->faker->words(3, true);
        
        return array_merge([
            'title' => $title,
            'teaser' => $this->faker->paragraph(2),
            'body' => $this->generatePhotobookBody(),
            'content_type' => 'photobook',
            'status' => $this->faker->randomElement(['draft', 'published']),
            'url_alias' => $this->generateUrlAlias($title),
            'sort_order' => $this->faker->numberBetween(1, 100),
            'teaser_image' => $this->faker->randomElement([
                'photo1.jpg', 'photo2.jpg', 'photo3.png'
            ]),
            'featured_image' => $this->faker->randomElement([
                'featured1.jpg', 'featured2.jpg', 'featured3.png'
            ]),
            'user_id' => 1,
            'published_at' => $this->faker->optional(0.7)->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'created_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'updated_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s')
        ], $overrides);
    }

    /**
     * Generate multiple content items
     * 
     * @param int $count Number of items to generate
     * @param string|null $type Content type (null for mixed)
     * @param array $overrides Common field overrides
     * @return array
     */
    public function generateContent(int $count, ?string $type = null, array $overrides = []): array
    {
        $content = [];
        
        for ($i = 0; $i < $count; $i++) {
            $contentType = $type ?? $this->faker->randomElement(['article', 'photobook']);
            
            if ($contentType === 'article') {
                $content[] = $this->generateArticle($overrides);
            } else {
                $content[] = $this->generatePhotobook($overrides);
            }
        }
        
        return $content;
    }

    /**
     * Get content validation test cases
     * 
     * @return array
     */
    public function getValidationTestCases(): array
    {
        return [
            'valid_article' => [
                'data' => [
                    'title' => 'Valid Article Title',
                    'teaser' => 'Valid teaser text',
                    'body' => '<p>Valid article body</p>',
                    'content_type' => 'article',
                    'status' => 'draft',
                    'url_alias' => 'valid-article-title'
                ],
                'should_pass' => true
            ],
            'empty_title' => [
                'data' => [
                    'title' => '',
                    'content_type' => 'article'
                ],
                'should_pass' => false,
                'expected_errors' => ['title']
            ],
            'long_title' => [
                'data' => [
                    'title' => str_repeat('Long Title ', 30),
                    'content_type' => 'article'
                ],
                'should_pass' => false,
                'expected_errors' => ['title']
            ],
            'invalid_content_type' => [
                'data' => [
                    'title' => 'Valid Title',
                    'content_type' => 'invalid_type'
                ],
                'should_pass' => false,
                'expected_errors' => ['content_type']
            ],
            'invalid_status' => [
                'data' => [
                    'title' => 'Valid Title',
                    'content_type' => 'article',
                    'status' => 'invalid_status'
                ],
                'should_pass' => false,
                'expected_errors' => ['status']
            ],
            'duplicate_url_alias' => [
                'data' => [
                    'title' => 'Another Title',
                    'content_type' => 'article',
                    'url_alias' => 'default-test-article' // Assuming this exists
                ],
                'should_pass' => false,
                'expected_errors' => ['url_alias']
            ]
        ];
    }

    /**
     * Get content with various HTML scenarios
     * 
     * @return array
     */
    public function getHtmlTestCases(): array
    {
        return [
            'safe_html' => [
                'body' => '<p>Safe paragraph</p><strong>Bold text</strong><a href="https://example.com">Link</a>',
                'expected_safe' => true
            ],
            'malicious_script' => [
                'body' => '<p>Text</p><script>alert("xss")</script><p>More text</p>',
                'expected_safe' => false,
                'should_be_cleaned' => true
            ],
            'iframe_embed' => [
                'body' => '<p>Text</p><iframe src="malicious.com"></iframe><p>More text</p>',
                'expected_safe' => false,
                'should_be_cleaned' => true
            ],
            'javascript_link' => [
                'body' => '<a href="javascript:alert(1)">Malicious link</a>',
                'expected_safe' => false,
                'should_be_cleaned' => true
            ],
            'event_handlers' => [
                'body' => '<div onclick="alert(1)">Click me</div>',
                'expected_safe' => false,
                'should_be_cleaned' => true
            ],
            'complex_valid_html' => [
                'body' => '
                    <h2>Article Title</h2>
                    <p>Introduction paragraph with <strong>bold</strong> and <em>italic</em> text.</p>
                    <ul>
                        <li>List item 1</li>
                        <li>List item 2</li>
                    </ul>
                    <blockquote>This is a quote</blockquote>
                    <p>Paragraph with <a href="https://example.com" target="_blank">external link</a>.</p>
                    <img src="/uploads/image.jpg" alt="Description" width="300" height="200">
                ',
                'expected_safe' => true
            ]
        ];
    }

    /**
     * Get content with pagebreaks for pagination testing
     * 
     * @return array
     */
    public function getPagedContent(): array
    {
        return [
            'single_page' => [
                'body' => '<p>This is a single page article without any page breaks.</p>',
                'expected_pages' => 1
            ],
            'two_pages' => [
                'body' => '<p>Page 1 content</p><hr class="mce-pagebreak" /><p>Page 2 content</p>',
                'expected_pages' => 2
            ],
            'multiple_pages' => [
                'body' => '
                    <p>Page 1 content</p>
                    <hr class="mce-pagebreak" />
                    <p>Page 2 content</p>
                    <hr class="mce-pagebreak" />
                    <p>Page 3 content</p>
                    <hr class="mce-pagebreak" />
                    <p>Page 4 content</p>
                ',
                'expected_pages' => 4
            ],
            'empty_pages' => [
                'body' => '<hr class="mce-pagebreak" /><hr class="mce-pagebreak" /><p>Content</p>',
                'expected_pages' => 1 // Empty pages should be filtered out
            ]
        ];
    }

    /**
     * Get bulk content for performance testing
     * 
     * @param int $count Number of content items
     * @param string $type Content type
     * @return array
     */
    public function getBulkContent(int $count, string $type = 'article'): array
    {
        $content = [];
        $baseTimestamp = strtotime('2024-01-01 00:00:00');
        
        for ($i = 1; $i <= $count; $i++) {
            $timestamp = date('Y-m-d H:i:s', $baseTimestamp + ($i * 3600));
            
            $content[] = [
                'title' => "Bulk {$type} {$i}",
                'teaser' => "This is bulk {$type} number {$i} for testing purposes.",
                'body' => "<p>Content body for bulk {$type} {$i}.</p>",
                'content_type' => $type,
                'status' => ($i % 3 === 0) ? 'draft' : 'published',
                'url_alias' => "bulk-{$type}-{$i}",
                'sort_order' => $i,
                'user_id' => 1,
                'published_at' => (($i % 3 === 0) ? null : $timestamp),
                'created_at' => $timestamp,
                'updated_at' => $timestamp
            ];
        }
        
        return $content;
    }

    /**
     * Get content with different statuses for workflow testing
     * 
     * @return array
     */
    public function getWorkflowContent(): array
    {
        return [
            'draft_article' => [
                'title' => 'Draft Article',
                'content_type' => 'article',
                'status' => 'draft',
                'url_alias' => 'draft-article',
                'published_at' => null
            ],
            'published_article' => [
                'title' => 'Published Article',
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => 'published-article',
                'published_at' => date('Y-m-d H:i:s')
            ],
            'draft_photobook' => [
                'title' => 'Draft Photobook',
                'content_type' => 'photobook',
                'status' => 'draft',
                'url_alias' => 'draft-photobook',
                'published_at' => null
            ],
            'published_photobook' => [
                'title' => 'Published Photobook',
                'content_type' => 'photobook',
                'status' => 'published',
                'url_alias' => 'published-photobook',
                'published_at' => date('Y-m-d H:i:s')
            ]
        ];
    }

    /**
     * Get content for sorting/ordering tests
     * 
     * @return array
     */
    public function getSortingContent(): array
    {
        $content = [];
        $titles = [
            'Alpha Article',
            'Beta Article', 
            'Charlie Article',
            'Delta Article',
            'Echo Article'
        ];
        
        foreach ($titles as $index => $title) {
            $content[] = [
                'title' => $title,
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => strtolower(str_replace(' ', '-', $title)),
                'sort_order' => $index + 1,
                'user_id' => 1,
                'created_at' => date('Y-m-d H:i:s', strtotime("2024-01-0" . ($index + 1) . " 12:00:00")),
                'updated_at' => date('Y-m-d H:i:s', strtotime("2024-01-0" . ($index + 1) . " 12:00:00"))
            ];
        }
        
        return $content;
    }

    /**
     * Get content with images for upload testing
     * 
     * @return array
     */
    public function getContentWithImages(): array
    {
        return [
            'article_with_teaser_image' => [
                'title' => 'Article with Teaser Image',
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => 'article-with-teaser-image',
                'teaser_image' => 'article_teaser.jpg'
            ],
            'photobook_with_featured_image' => [
                'title' => 'Photobook with Featured Image',
                'content_type' => 'photobook',
                'status' => 'published',
                'url_alias' => 'photobook-with-featured-image',
                'teaser_image' => 'photobook_teaser.jpg',
                'featured_image' => 'photobook_featured.jpg'
            ],
            'content_with_missing_images' => [
                'title' => 'Content with Missing Images',
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => 'content-with-missing-images',
                'teaser_image' => 'nonexistent_image.jpg'
            ]
        ];
    }

    /**
     * Get content for search testing
     * 
     * @return array
     */
    public function getSearchContent(): array
    {
        return [
            [
                'title' => 'JavaScript Programming Guide',
                'teaser' => 'Learn JavaScript programming from basics to advanced concepts.',
                'body' => '<p>This guide covers JavaScript fundamentals, ES6 features, and modern development practices.</p>',
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => 'javascript-programming-guide'
            ],
            [
                'title' => 'PHP Web Development Tutorial',
                'teaser' => 'Complete PHP tutorial for web development beginners.',
                'body' => '<p>Learn PHP programming for web development, including database integration and security.</p>',
                'content_type' => 'article',
                'status' => 'published',
                'url_alias' => 'php-web-development-tutorial'
            ],
            [
                'title' => 'Photography Tips and Tricks',
                'teaser' => 'Professional photography techniques and equipment reviews.',
                'body' => '<p>Master photography with these professional tips, camera settings, and composition techniques.</p>',
                'content_type' => 'photobook',
                'status' => 'published',
                'url_alias' => 'photography-tips-and-tricks'
            ],
            [
                'title' => 'Travel Photography Collection',
                'teaser' => 'Beautiful travel photographs from around the world.',
                'body' => '<p>Explore stunning travel photography featuring landscapes, cities, and cultural moments.</p>',
                'content_type' => 'photobook',
                'status' => 'draft', // This should not appear in public searches
                'url_alias' => 'travel-photography-collection'
            ]
        ];
    }

    /**
     * Generate article body with realistic content
     * 
     * @return string
     */
    private function generateArticleBody(): string
    {
        $paragraphs = [];
        
        // Introduction
        $paragraphs[] = '<p>' . $this->faker->paragraph(4) . '</p>';
        
        // Main content
        for ($i = 0; $i < rand(2, 5); $i++) {
            $paragraphs[] = '<p>' . $this->faker->paragraph(6) . '</p>';
            
            // Sometimes add a list
            if (rand(0, 2) === 0) {
                $items = [];
                for ($j = 0; $j < rand(3, 6); $j++) {
                    $items[] = '<li>' . $this->faker->sentence() . '</li>';
                }
                $paragraphs[] = '<ul>' . implode('', $items) . '</ul>';
            }
            
            // Sometimes add a quote
            if (rand(0, 3) === 0) {
                $paragraphs[] = '<blockquote>' . $this->faker->paragraph(2) . '</blockquote>';
            }
        }
        
        // Conclusion
        $paragraphs[] = '<p>' . $this->faker->paragraph(3) . '</p>';
        
        return implode("\n", $paragraphs);
    }

    /**
     * Generate photobook body with image placeholders
     * 
     * @return string
     */
    private function generatePhotobookBody(): string
    {
        $content = [];
        
        $content[] = '<p>' . $this->faker->paragraph(3) . '</p>';
        
        // Add image placeholders
        for ($i = 0; $i < rand(3, 8); $i++) {
            $imageName = 'photo_' . ($i + 1) . '.jpg';
            $content[] = '<p><img src="/uploads/' . $imageName . '" alt="' . $this->faker->sentence(3) . '" /></p>';
            $content[] = '<p>' . $this->faker->paragraph(2) . '</p>';
        }
        
        return implode("\n", $content);
    }

    /**
     * Generate URL alias from title
     * 
     * @param string $title
     * @return string
     */
    private function generateUrlAlias(string $title): string
    {
        $alias = strtolower(trim($title));
        $alias = preg_replace('/[^a-z0-9]+/', '-', $alias);
        $alias = trim($alias, '-');
        
        // Add random suffix to ensure uniqueness in tests
        $alias .= '-' . substr(md5(uniqid()), 0, 6);
        
        return $alias;
    }
}