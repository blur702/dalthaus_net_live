<?php

declare(strict_types=1);

namespace Tests\Integration;

use Tests\Support\DatabaseTestCase;
use CMS\Utils\Auth;
use CMS\Utils\Security;
use CMS\Models\Content;
use CMS\Models\User;

/**
 * Content Management Workflow Integration Test
 * 
 * Tests the complete content management workflow including content creation,
 * editing, publishing, sorting, and deletion with proper authentication
 * and authorization checks.
 */
class ContentManagementWorkflowTest extends DatabaseTestCase
{
    protected Auth $auth;
    protected User $adminUser;
    protected User $editorUser;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->auth = new Auth($this->db, [
            'session_lifetime' => 3600,
            'password_min_length' => 8
        ]);
        
        // Create test users with different roles
        $this->adminUser = $this->createAdminUser();
        $this->editorUser = $this->createEditorUser();
    }

    /**
     * Test complete article creation workflow
     */
    public function testArticleCreationWorkflow(): void
    {
        // Step 1: Login as editor
        $this->loginUser($this->editorUser);

        // Step 2: Create new article
        $articleData = [
            'title' => 'Test Article Creation',
            'teaser' => 'This is a test article teaser for workflow testing.',
            'body' => '<p>This is the full article content with <strong>HTML formatting</strong>.</p>',
            'content_type' => Content::TYPE_ARTICLE,
            'status' => Content::STATUS_DRAFT,
            'url_alias' => 'test-article-creation',
            '_token' => $this->auth->generateCsrfToken()
        ];

        $createResult = $this->simulateContentCreation($articleData);
        $this->assertTrue($createResult['success']);
        $this->assertArrayHasKey('content_id', $createResult);

        $contentId = $createResult['content_id'];

        // Step 3: Verify content was created in database
        $createdContent = Content::find($contentId);
        $this->assertNotNull($createdContent);
        $this->assertEquals('Test Article Creation', $createdContent->getAttribute('title'));
        $this->assertEquals(Content::STATUS_DRAFT, $createdContent->getAttribute('status'));
        $this->assertEquals($this->editorUser->getAttribute('user_id'), $createdContent->getAttribute('user_id'));

        // Step 4: Edit the content
        $editData = [
            'title' => 'Updated Test Article',
            'teaser' => 'Updated teaser content.',
            'body' => '<p>Updated article body content.</p>',
            'status' => Content::STATUS_PUBLISHED,
            'published_at' => date('Y-m-d H:i:s'),
            '_token' => $this->auth->generateCsrfToken()
        ];

        $editResult = $this->simulateContentEdit($contentId, $editData);
        $this->assertTrue($editResult['success']);

        // Step 5: Verify content was updated
        $updatedContent = Content::find($contentId);
        $this->assertEquals('Updated Test Article', $updatedContent->getAttribute('title'));
        $this->assertEquals(Content::STATUS_PUBLISHED, $updatedContent->getAttribute('status'));
        $this->assertNotNull($updatedContent->getAttribute('published_at'));

        // Step 6: Test content visibility on frontend
        $publicView = $this->simulatePublicContentView('test-article-creation');
        $this->assertTrue($publicView['visible']);
        $this->assertEquals('Updated Test Article', $publicView['content']['title']);
    }

    /**
     * Test photobook creation and management workflow
     */
    public function testPhotobookCreationWorkflow(): void
    {
        $this->loginUser($this->adminUser);

        // Create photobook with image uploads
        $photobookData = [
            'title' => 'Test Photobook',
            'teaser' => 'A collection of test images.',
            'body' => '<p>Photobook description with images.</p>',
            'content_type' => Content::TYPE_PHOTOBOOK,
            'status' => Content::STATUS_DRAFT,
            'url_alias' => 'test-photobook',
            'featured_image' => 'featured.jpg',
            '_token' => $this->auth->generateCsrfToken()
        ];

        // Simulate image upload
        $uploadResult = $this->simulateImageUpload('featured.jpg');
        $this->assertTrue($uploadResult['success']);

        $createResult = $this->simulateContentCreation($photobookData);
        $this->assertTrue($createResult['success']);

        $photobook = Content::find($createResult['content_id']);
        $this->assertTrue($photobook->isPhotobook());
        $this->assertEquals('featured.jpg', $photobook->getAttribute('featured_image'));
        $this->assertEquals('/uploads/featured.jpg', $photobook->getFeaturedImageUrl());
    }

    /**
     * Test content sorting and reordering
     */
    public function testContentSortingWorkflow(): void
    {
        $this->loginUser($this->adminUser);

        // Create multiple content items
        $contentItems = [];
        for ($i = 1; $i <= 5; $i++) {
            $data = [
                'title' => "Article {$i}",
                'content_type' => Content::TYPE_ARTICLE,
                'status' => Content::STATUS_PUBLISHED,
                'sort_order' => $i,
                'user_id' => $this->adminUser->getAttribute('user_id'),
                'published_at' => date('Y-m-d H:i:s')
            ];
            $content = Content::create($data);
            $contentItems[] = $content;
        }

        // Get current order
        $currentOrder = Content::getForReordering(Content::TYPE_ARTICLE);
        $this->assertCount(6, $currentOrder); // 5 new + 1 from seed data

        // Simulate reordering via admin interface
        $newOrder = [
            $contentItems[4]->getAttribute('content_id') => 1, // Article 5 -> position 1
            $contentItems[0]->getAttribute('content_id') => 2, // Article 1 -> position 2
            $contentItems[2]->getAttribute('content_id') => 3, // Article 3 -> position 3
            $contentItems[1]->getAttribute('content_id') => 4, // Article 2 -> position 4
            $contentItems[3]->getAttribute('content_id') => 5, // Article 4 -> position 5
        ];

        $reorderResult = $this->simulateContentReorder($newOrder);
        $this->assertTrue($reorderResult['success']);

        // Verify new order
        $reorderedContent = Content::getForReordering(Content::TYPE_ARTICLE);
        
        // Find our reordered items
        $reorderedItems = array_filter($reorderedContent, function($item) use ($contentItems) {
            return in_array($item['content_id'], array_map(
                fn($c) => $c->getAttribute('content_id'), 
                $contentItems
            ));
        });

        // Sort by sort_order to check the new arrangement
        usort($reorderedItems, fn($a, $b) => $a['sort_order'] <=> $b['sort_order']);
        
        $this->assertEquals('Article 5', $reorderedItems[0]['title']);
        $this->assertEquals('Article 1', $reorderedItems[1]['title']);
    }

    /**
     * Test content deletion workflow with safety checks
     */
    public function testContentDeletionWorkflow(): void
    {
        $this->loginUser($this->adminUser);

        // Create test content
        $contentData = [
            'title' => 'Content to Delete',
            'content_type' => Content::TYPE_ARTICLE,
            'status' => Content::STATUS_PUBLISHED,
            'user_id' => $this->adminUser->getAttribute('user_id')
        ];
        $content = Content::create($contentData);
        $contentId = $content->getAttribute('content_id');

        // Simulate deletion attempt
        $deleteResult = $this->simulateContentDeletion($contentId);
        $this->assertTrue($deleteResult['success']);

        // Verify content is deleted
        $deletedContent = Content::find($contentId);
        $this->assertNull($deletedContent);

        // Verify content is no longer visible on frontend
        $publicView = $this->simulatePublicContentView('content-to-delete');
        $this->assertFalse($publicView['visible']);
    }

    /**
     * Test content workflow with different user permissions
     */
    public function testContentWorkflowWithPermissions(): void
    {
        // Test editor user can create but not delete
        $this->loginUser($this->editorUser);

        $editorContent = Content::create([
            'title' => 'Editor Created Content',
            'content_type' => Content::TYPE_ARTICLE,
            'status' => Content::STATUS_DRAFT,
            'user_id' => $this->editorUser->getAttribute('user_id')
        ]);

        // Editor tries to delete content
        $deleteAttempt = $this->simulateContentDeletion(
            $editorContent->getAttribute('content_id'),
            false // expectedSuccess = false
        );
        $this->assertFalse($deleteAttempt['success']);
        $this->assertEquals('Insufficient permissions', $deleteAttempt['error']);

        // Editor can edit their own content
        $editResult = $this->simulateContentEdit($editorContent->getAttribute('content_id'), [
            'title' => 'Editor Updated Content',
            '_token' => $this->auth->generateCsrfToken()
        ]);
        $this->assertTrue($editResult['success']);

        // Switch to admin user
        $this->loginUser($this->adminUser);

        // Admin can delete editor's content
        $adminDeleteResult = $this->simulateContentDeletion(
            $editorContent->getAttribute('content_id')
        );
        $this->assertTrue($adminDeleteResult['success']);
    }

    /**
     * Test content workflow with validation errors
     */
    public function testContentWorkflowWithValidationErrors(): void
    {
        $this->loginUser($this->editorUser);

        // Test creation with missing required fields
        $invalidData = [
            'title' => '', // Empty title
            'content_type' => Content::TYPE_ARTICLE,
            '_token' => $this->auth->generateCsrfToken()
        ];

        $createResult = $this->simulateContentCreation($invalidData);
        $this->assertFalse($createResult['success']);
        $this->assertArrayHasKey('validation_errors', $createResult);
        $this->assertArrayHasKey('title', $createResult['validation_errors']);

        // Test creation with invalid content type
        $invalidTypeData = [
            'title' => 'Valid Title',
            'content_type' => 'invalid_type',
            '_token' => $this->auth->generateCsrfToken()
        ];

        $createResult = $this->simulateContentCreation($invalidTypeData);
        $this->assertFalse($createResult['success']);
        $this->assertArrayHasKey('validation_errors', $createResult);

        // Test URL alias uniqueness
        $duplicateAliasData = [
            'title' => 'Duplicate Alias Test',
            'content_type' => Content::TYPE_ARTICLE,
            'url_alias' => 'test-article', // Already exists from seed data
            '_token' => $this->auth->generateCsrfToken()
        ];

        $createResult = $this->simulateContentCreation($duplicateAliasData);
        $this->assertFalse($createResult['success']);
        $this->assertArrayHasKey('validation_errors', $createResult);
        $this->assertArrayHasKey('url_alias', $createResult['validation_errors']);
    }

    /**
     * Test bulk content operations
     */
    public function testBulkContentOperations(): void
    {
        $this->loginUser($this->adminUser);

        // Create multiple content items
        $contentIds = [];
        for ($i = 1; $i <= 5; $i++) {
            $content = Content::create([
                'title' => "Bulk Test Article {$i}",
                'content_type' => Content::TYPE_ARTICLE,
                'status' => Content::STATUS_DRAFT,
                'user_id' => $this->adminUser->getAttribute('user_id')
            ]);
            $contentIds[] = $content->getAttribute('content_id');
        }

        // Test bulk status update (draft -> published)
        $bulkUpdateResult = $this->simulateBulkStatusUpdate($contentIds, Content::STATUS_PUBLISHED);
        $this->assertTrue($bulkUpdateResult['success']);
        $this->assertEquals(5, $bulkUpdateResult['updated_count']);

        // Verify updates
        foreach ($contentIds as $id) {
            $content = Content::find($id);
            $this->assertEquals(Content::STATUS_PUBLISHED, $content->getAttribute('status'));
        }

        // Test bulk deletion
        $bulkDeleteResult = $this->simulateBulkContentDeletion(array_slice($contentIds, 0, 3));
        $this->assertTrue($bulkDeleteResult['success']);
        $this->assertEquals(3, $bulkDeleteResult['deleted_count']);

        // Verify deletions
        for ($i = 0; $i < 3; $i++) {
            $content = Content::find($contentIds[$i]);
            $this->assertNull($content);
        }
    }

    /**
     * Helper method to create admin user
     */
    private function createAdminUser(): User
    {
        return User::createUser([
            'username' => 'admin',
            'email' => 'admin@cms.test',
            'password' => 'AdminPassword123'
        ]);
    }

    /**
     * Helper method to create editor user
     */
    private function createEditorUser(): User
    {
        return User::createUser([
            'username' => 'editor',
            'email' => 'editor@cms.test',
            'password' => 'EditorPassword123'
        ]);
    }

    /**
     * Helper method to login user
     */
    private function loginUser(User $user): void
    {
        $_SESSION = [];
        $password = $user->getAttribute('username') === 'admin' ? 'AdminPassword123' : 'EditorPassword123';
        $this->auth->attempt($user->getAttribute('username'), $password);
    }

    /**
     * Simulate content creation
     */
    private function simulateContentCreation(array $data): array
    {
        $result = ['success' => false];

        // Check authentication
        if (!$this->auth->check()) {
            $result['error'] = 'Authentication required';
            return $result;
        }

        // Validate CSRF token
        if (!$this->auth->validateCsrfToken($data['_token'] ?? '')) {
            $result['error'] = 'Invalid CSRF token';
            return $result;
        }

        // Validate required fields
        $validationErrors = $this->validateContentData($data);
        if (!empty($validationErrors)) {
            $result['validation_errors'] = $validationErrors;
            return $result;
        }

        // Clean and prepare data
        $contentData = $this->prepareContentData($data);
        $contentData['user_id'] = $this->auth->id();
        $contentData['created_at'] = date('Y-m-d H:i:s');
        $contentData['updated_at'] = date('Y-m-d H:i:s');

        // Create content
        try {
            $content = Content::create($contentData);
            $result['success'] = true;
            $result['content_id'] = $content->getAttribute('content_id');
            $result['message'] = 'Content created successfully';
        } catch (\Exception $e) {
            $result['error'] = 'Failed to create content: ' . $e->getMessage();
        }

        return $result;
    }

    /**
     * Simulate content editing
     */
    private function simulateContentEdit(int $contentId, array $data): array
    {
        $result = ['success' => false];

        // Check authentication
        if (!$this->auth->check()) {
            $result['error'] = 'Authentication required';
            return $result;
        }

        // Validate CSRF token
        if (!$this->auth->validateCsrfToken($data['_token'] ?? '')) {
            $result['error'] = 'Invalid CSRF token';
            return $result;
        }

        // Find content
        $content = Content::find($contentId);
        if (!$content) {
            $result['error'] = 'Content not found';
            return $result;
        }

        // Check permissions (users can only edit their own content unless admin)
        if (!$this->canEditContent($content)) {
            $result['error'] = 'Insufficient permissions';
            return $result;
        }

        // Validate data
        $validationErrors = $this->validateContentData($data, $contentId);
        if (!empty($validationErrors)) {
            $result['validation_errors'] = $validationErrors;
            return $result;
        }

        // Update content
        $contentData = $this->prepareContentData($data);
        $contentData['updated_at'] = date('Y-m-d H:i:s');

        foreach ($contentData as $key => $value) {
            $content->setAttribute($key, $value);
        }

        try {
            $content->save();
            $result['success'] = true;
            $result['message'] = 'Content updated successfully';
        } catch (\Exception $e) {
            $result['error'] = 'Failed to update content: ' . $e->getMessage();
        }

        return $result;
    }

    /**
     * Simulate content deletion
     */
    private function simulateContentDeletion(int $contentId, bool $expectedSuccess = true): array
    {
        $result = ['success' => false];

        // Check authentication
        if (!$this->auth->check()) {
            $result['error'] = 'Authentication required';
            return $result;
        }

        // Find content
        $content = Content::find($contentId);
        if (!$content) {
            $result['error'] = 'Content not found';
            return $result;
        }

        // Check permissions (only admin can delete)
        if (!$this->canDeleteContent($content)) {
            $result['error'] = 'Insufficient permissions';
            return $result;
        }

        try {
            $content->delete();
            $result['success'] = true;
            $result['message'] = 'Content deleted successfully';
        } catch (\Exception $e) {
            $result['error'] = 'Failed to delete content: ' . $e->getMessage();
        }

        return $result;
    }

    /**
     * Simulate content reordering
     */
    private function simulateContentReorder(array $orderData): array
    {
        $result = ['success' => false];

        // Check admin permissions
        if (!$this->isAdmin()) {
            $result['error'] = 'Admin permissions required';
            return $result;
        }

        try {
            $updateResult = Content::updateSortOrder($orderData);
            $result['success'] = $updateResult;
            $result['message'] = $updateResult ? 'Content reordered successfully' : 'Failed to reorder content';
        } catch (\Exception $e) {
            $result['error'] = 'Failed to reorder content: ' . $e->getMessage();
        }

        return $result;
    }

    /**
     * Simulate bulk status update
     */
    private function simulateBulkStatusUpdate(array $contentIds, string $newStatus): array
    {
        $result = ['success' => false, 'updated_count' => 0];

        if (!$this->isAdmin()) {
            $result['error'] = 'Admin permissions required';
            return $result;
        }

        foreach ($contentIds as $id) {
            $content = Content::find($id);
            if ($content) {
                $content->setAttribute('status', $newStatus);
                if ($newStatus === Content::STATUS_PUBLISHED && !$content->getAttribute('published_at')) {
                    $content->setAttribute('published_at', date('Y-m-d H:i:s'));
                }
                $content->setAttribute('updated_at', date('Y-m-d H:i:s'));
                
                if ($content->save()) {
                    $result['updated_count']++;
                }
            }
        }

        $result['success'] = $result['updated_count'] > 0;
        return $result;
    }

    /**
     * Simulate bulk content deletion
     */
    private function simulateBulkContentDeletion(array $contentIds): array
    {
        $result = ['success' => false, 'deleted_count' => 0];

        if (!$this->isAdmin()) {
            $result['error'] = 'Admin permissions required';
            return $result;
        }

        foreach ($contentIds as $id) {
            $content = Content::find($id);
            if ($content && $content->delete()) {
                $result['deleted_count']++;
            }
        }

        $result['success'] = $result['deleted_count'] > 0;
        return $result;
    }

    /**
     * Simulate public content view
     */
    private function simulatePublicContentView(string $urlAlias): array
    {
        $content = Content::findByAlias($urlAlias);
        
        return [
            'visible' => $content !== null,
            'content' => $content ? $content->toArray() : null
        ];
    }

    /**
     * Simulate image upload
     */
    private function simulateImageUpload(string $filename): array
    {
        $uploadPath = $this->testConfig['app']['upload_path'];
        $filePath = $uploadPath . $filename;
        
        // Create fake image content
        file_put_contents($filePath, 'fake image content');
        
        return [
            'success' => true,
            'filename' => $filename,
            'path' => $filePath
        ];
    }

    /**
     * Validate content data
     */
    private function validateContentData(array $data, ?int $excludeId = null): array
    {
        $errors = [];

        // Title validation
        if (empty($data['title'])) {
            $errors['title'] = 'Title is required';
        } elseif (strlen($data['title']) > 255) {
            $errors['title'] = 'Title is too long';
        }

        // Content type validation
        if (empty($data['content_type']) || !in_array($data['content_type'], [Content::TYPE_ARTICLE, Content::TYPE_PHOTOBOOK])) {
            $errors['content_type'] = 'Invalid content type';
        }

        // Status validation
        if (isset($data['status']) && !in_array($data['status'], [Content::STATUS_DRAFT, Content::STATUS_PUBLISHED])) {
            $errors['status'] = 'Invalid status';
        }

        // URL alias uniqueness check
        if (!empty($data['url_alias'])) {
            $existingContent = Content::findByAlias($data['url_alias']);
            if ($existingContent && (!$excludeId || $existingContent->getAttribute('content_id') !== $excludeId)) {
                $errors['url_alias'] = 'URL alias already exists';
            }
        }

        return $errors;
    }

    /**
     * Prepare content data for database
     */
    private function prepareContentData(array $data): array
    {
        $prepared = [];
        
        $allowedFields = [
            'title', 'teaser', 'body', 'content_type', 'status', 
            'url_alias', 'sort_order', 'teaser_image', 'featured_image', 'published_at'
        ];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                if (in_array($field, ['teaser', 'body'])) {
                    $prepared[$field] = Security::cleanHtml($data[$field]);
                } else {
                    $prepared[$field] = Security::sanitize($data[$field]);
                }
            }
        }

        // Auto-generate URL alias if not provided
        if (empty($prepared['url_alias']) && !empty($prepared['title'])) {
            $prepared['url_alias'] = Security::createUrlAlias($prepared['title']);
        }

        // Set sort order if not provided
        if (empty($prepared['sort_order'])) {
            $prepared['sort_order'] = Content::getNextSortOrder();
        }

        return $prepared;
    }

    /**
     * Check if current user can edit content
     */
    private function canEditContent(Content $content): bool
    {
        $currentUserId = $this->auth->id();
        $contentUserId = $content->getAttribute('user_id');
        
        // Admin can edit all content, users can edit their own
        return $this->isAdmin() || $currentUserId === $contentUserId;
    }

    /**
     * Check if current user can delete content
     */
    private function canDeleteContent(Content $content): bool
    {
        // Only admin can delete content
        return $this->isAdmin();
    }

    /**
     * Check if current user is admin
     */
    private function isAdmin(): bool
    {
        $user = $this->auth->user();
        return $user && $user['username'] === 'admin';
    }
}