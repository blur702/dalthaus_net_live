<?php

declare(strict_types=1);

namespace Tests\Integration;

use Tests\Support\DatabaseTestCase;
use CMS\Utils\Auth;
use CMS\Utils\Security;
use CMS\Utils\FileUpload;

/**
 * File Upload Security Integration Test
 * 
 * Tests file upload security including file type validation,
 * size limits, malicious file detection, and secure file handling.
 */
class FileUploadSecurityTest extends DatabaseTestCase
{
    protected Auth $auth;
    protected string $uploadPath;
    protected array $allowedTypes;
    protected int $maxFileSize;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->auth = new Auth($this->db, ['password_min_length' => 8]);
        $this->uploadPath = $this->testConfig['app']['upload_path'];
        $this->allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $this->maxFileSize = 2048000; // 2MB
        
        // Create admin user for upload tests
        $this->createAndLoginAdminUser();
        
        // Ensure upload directory exists
        if (!is_dir($this->uploadPath)) {
            mkdir($this->uploadPath, 0755, true);
        }
    }

    /**
     * Test successful image upload workflow
     */
    public function testSuccessfulImageUploadWorkflow(): void
    {
        // Create valid image file
        $validImage = $this->createTestImageFile('valid.jpg', 'image/jpeg', 1024);
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $validImage,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertTrue($uploadResult['success']);
        $this->assertArrayHasKey('filename', $uploadResult);
        $this->assertArrayHasKey('url', $uploadResult);
        
        // Verify file was saved securely
        $savedFile = $uploadResult['saved_path'];
        $this->assertFileExists($savedFile);
        
        // Verify filename was sanitized
        $savedFilename = basename($savedFile);
        $this->assertMatchesRegularExpression('/^[a-f0-9]+_[a-f0-9]+\.jpg$/', $savedFilename);
        $this->assertNotEquals('valid.jpg', $savedFilename);
    }

    /**
     * Test malicious file upload prevention
     */
    public function testMaliciousFileUploadPrevention(): void
    {
        // Test PHP script disguised as image
        $maliciousFile = $this->createMaliciousPhpFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $maliciousFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('File type not allowed', $uploadResult['error']);
        
        // Test executable file
        $executableFile = $this->createExecutableFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $executableFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('File type not allowed', $uploadResult['error']);
        
        // Test SVG with embedded script
        $maliciousSvg = $this->createMaliciousSvgFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $maliciousSvg,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('File type not allowed', $uploadResult['error']);
    }

    /**
     * Test file size limit enforcement
     */
    public function testFileSizeLimitEnforcement(): void
    {
        // Create file larger than limit
        $largeFile = $this->createTestImageFile('large.jpg', 'image/jpeg', $this->maxFileSize + 1000);
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $largeFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('File size exceeds maximum', $uploadResult['error']);
        
        // Test file at size limit (should succeed)
        $maxSizeFile = $this->createTestImageFile('maxsize.jpg', 'image/jpeg', $this->maxFileSize - 1000);
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $maxSizeFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertTrue($uploadResult['success']);
    }

    /**
     * Test MIME type spoofing prevention
     */
    public function testMimeTypeSpoofingPrevention(): void
    {
        // Create PHP file with image extension and fake MIME type
        $spoofedFile = $this->createSpoofedFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $spoofedFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Invalid file content', $uploadResult['error']);
    }

    /**
     * Test double extension attack prevention
     */
    public function testDoubleExtensionAttackPrevention(): void
    {
        // Create file with double extension
        $doubleExtFile = $this->createTestFile('malicious.php.jpg', 'image/jpeg', '<?php echo "hacked"; ?>');
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $doubleExtFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        // Should be rejected due to content validation
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Invalid file content', $uploadResult['error']);
    }

    /**
     * Test directory traversal prevention
     */
    public function testDirectoryTraversalPrevention(): void
    {
        // Attempt to upload with malicious filename
        $traversalFile = $this->createTestImageFile('../../malicious.jpg', 'image/jpeg', 1024);
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $traversalFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        if ($uploadResult['success']) {
            // Verify file was saved in correct directory only
            $savedPath = $uploadResult['saved_path'];
            $this->assertStringStartsWith($this->uploadPath, $savedPath);
            $this->assertStringNotContainsString('..', $savedPath);
            
            // Verify filename was sanitized
            $filename = basename($savedPath);
            $this->assertStringNotContainsString('..', $filename);
        }
    }

    /**
     * Test unauthorized upload prevention
     */
    public function testUnauthorizedUploadPrevention(): void
    {
        // Logout user
        $this->auth->logout();
        
        $validImage = $this->createTestImageFile('unauthorized.jpg', 'image/jpeg', 1024);
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $validImage,
            '_token' => 'invalid_token',
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Authentication required', $uploadResult['error']);
    }

    /**
     * Test CSRF protection in file uploads
     */
    public function testCsrfProtectionInUploads(): void
    {
        $validImage = $this->createTestImageFile('csrf_test.jpg', 'image/jpeg', 1024);
        
        // Test with invalid CSRF token
        $uploadResult = $this->simulateFileUpload([
            'file' => $validImage,
            '_token' => 'invalid_csrf_token',
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Invalid CSRF token', $uploadResult['error']);
        
        // Test with missing CSRF token
        $uploadResult = $this->simulateFileUpload([
            'file' => $validImage,
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Invalid CSRF token', $uploadResult['error']);
    }

    /**
     * Test file upload with virus simulation
     */
    public function testVirusLikeFileDetection(): void
    {
        // Create file with suspicious content
        $suspiciousFile = $this->createSuspiciousFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $suspiciousFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        $this->assertStringContainsString('Invalid file content', $uploadResult['error']);
    }

    /**
     * Test concurrent file uploads
     */
    public function testConcurrentFileUploads(): void
    {
        $uploads = [];
        
        // Simulate multiple concurrent uploads
        for ($i = 1; $i <= 5; $i++) {
            $file = $this->createTestImageFile("concurrent_{$i}.jpg", 'image/jpeg', 1024);
            
            $uploadResult = $this->simulateFileUpload([
                'file' => $file,
                '_token' => $this->auth->generateCsrfToken(),
                'upload_type' => 'content_image'
            ]);
            
            $uploads[] = $uploadResult;
        }
        
        // Verify all uploads succeeded
        foreach ($uploads as $upload) {
            $this->assertTrue($upload['success'], 'Concurrent upload failed: ' . ($upload['error'] ?? 'Unknown error'));
        }
        
        // Verify unique filenames
        $filenames = array_map(fn($u) => $u['filename'], $uploads);
        $this->assertEquals(count($filenames), count(array_unique($filenames)), 'Duplicate filenames generated');
    }

    /**
     * Test file replacement security
     */
    public function testFileReplacementSecurity(): void
    {
        // Upload first file
        $firstFile = $this->createTestImageFile('replace_test.jpg', 'image/jpeg', 1024);
        
        $firstUpload = $this->simulateFileUpload([
            'file' => $firstFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertTrue($firstUpload['success']);
        $firstFilename = $firstUpload['filename'];
        
        // Upload second file with same original name
        $secondFile = $this->createTestImageFile('replace_test.jpg', 'image/jpeg', 2048);
        
        $secondUpload = $this->simulateFileUpload([
            'file' => $secondFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertTrue($secondUpload['success']);
        $secondFilename = $secondUpload['filename'];
        
        // Verify files have different names (no overwriting)
        $this->assertNotEquals($firstFilename, $secondFilename);
        
        // Verify both files exist
        $this->assertFileExists($firstUpload['saved_path']);
        $this->assertFileExists($secondUpload['saved_path']);
    }

    /**
     * Test upload quota enforcement
     */
    public function testUploadQuotaEnforcement(): void
    {
        // Simulate reaching upload quota
        $quotaLimit = 5; // 5 files
        $uploadedFiles = [];
        
        for ($i = 1; $i <= $quotaLimit + 1; $i++) {
            $file = $this->createTestImageFile("quota_{$i}.jpg", 'image/jpeg', 1024);
            
            $uploadResult = $this->simulateFileUpload([
                'file' => $file,
                '_token' => $this->auth->generateCsrfToken(),
                'upload_type' => 'content_image'
            ], $quotaLimit);
            
            if ($i <= $quotaLimit) {
                $this->assertTrue($uploadResult['success'], "Upload {$i} should succeed");
                $uploadedFiles[] = $uploadResult;
            } else {
                $this->assertFalse($uploadResult['success'], "Upload {$i} should fail due to quota");
                $this->assertStringContainsString('Upload quota exceeded', $uploadResult['error']);
            }
        }
    }

    /**
     * Helper: Create and login admin user
     */
    private function createAndLoginAdminUser(): void
    {
        $adminUser = User::createUser([
            'username' => 'admin',
            'email' => 'admin@test.com',
            'password' => 'AdminPassword123'
        ]);
        
        $this->auth->attempt('admin', 'AdminPassword123');
    }

    /**
     * Helper: Create test image file
     */
    private function createTestImageFile(string $filename, string $mimeType, int $size): array
    {
        $content = str_repeat('A', $size); // Fake image content
        $tmpFile = tempnam(sys_get_temp_dir(), 'test_upload_');
        file_put_contents($tmpFile, $content);
        
        return [
            'name' => $filename,
            'type' => $mimeType,
            'tmp_name' => $tmpFile,
            'error' => UPLOAD_ERR_OK,
            'size' => $size
        ];
    }

    /**
     * Helper: Create test file with custom content
     */
    private function createTestFile(string $filename, string $mimeType, string $content): array
    {
        $tmpFile = tempnam(sys_get_temp_dir(), 'test_upload_');
        file_put_contents($tmpFile, $content);
        
        return [
            'name' => $filename,
            'type' => $mimeType,
            'tmp_name' => $tmpFile,
            'error' => UPLOAD_ERR_OK,
            'size' => strlen($content)
        ];
    }

    /**
     * Helper: Create malicious PHP file
     */
    private function createMaliciousPhpFile(): array
    {
        $maliciousContent = '<?php system($_GET["cmd"]); ?>';
        return $this->createTestFile('malicious.jpg', 'image/jpeg', $maliciousContent);
    }

    /**
     * Helper: Create executable file
     */
    private function createExecutableFile(): array
    {
        $execContent = "\x7fELF"; // ELF header for Linux executable
        return $this->createTestFile('malicious.exe', 'application/octet-stream', $execContent);
    }

    /**
     * Helper: Create malicious SVG file
     */
    private function createMaliciousSvgFile(): array
    {
        $svgContent = '<?xml version="1.0" encoding="UTF-8"?>
        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
            <script type="text/javascript">
                alert("XSS");
            </script>
            <rect width="100" height="100" fill="red"/>
        </svg>';
        
        return $this->createTestFile('malicious.svg', 'image/svg+xml', $svgContent);
    }

    /**
     * Helper: Create file with spoofed MIME type
     */
    private function createSpoofedFile(): array
    {
        $phpContent = '<?php echo "spoofed"; ?>';
        return $this->createTestFile('spoofed.jpg', 'image/jpeg', $phpContent);
    }

    /**
     * Helper: Create file with suspicious content
     */
    private function createSuspiciousFile(): array
    {
        $suspiciousContent = 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*';
        return $this->createTestFile('suspicious.jpg', 'image/jpeg', $suspiciousContent);
    }

    /**
     * Simulate file upload process
     */
    private function simulateFileUpload(array $uploadData, ?int $quotaLimit = null): array
    {
        $result = ['success' => false];
        
        // Check authentication
        if (!$this->auth->check()) {
            $result['error'] = 'Authentication required';
            return $result;
        }
        
        // Validate CSRF token
        if (!$this->auth->validateCsrfToken($uploadData['_token'] ?? '')) {
            $result['error'] = 'Invalid CSRF token';
            return $result;
        }
        
        // Check upload quota if specified
        if ($quotaLimit !== null) {
            $currentUploads = count(glob($this->uploadPath . '*'));
            if ($currentUploads >= $quotaLimit) {
                $result['error'] = 'Upload quota exceeded';
                return $result;
            }
        }
        
        // Validate file upload
        $file = $uploadData['file'];
        $validation = Security::validateFileUpload($file, $this->allowedTypes, $this->maxFileSize);
        
        if (!$validation['valid']) {
            $result['error'] = implode(', ', $validation['errors']);
            return $result;
        }
        
        // Generate secure filename
        $secureFilename = Security::generateSecureFilename($file['name']);
        $savedPath = $this->uploadPath . $secureFilename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $savedPath)) {
            $result['success'] = true;
            $result['filename'] = $secureFilename;
            $result['saved_path'] = $savedPath;
            $result['url'] = '/uploads/' . $secureFilename;
            $result['size'] = $file['size'];
        } else {
            $result['error'] = 'Failed to save file';
        }
        
        return $result;
    }

    /**
     * Test image processing security
     */
    public function testImageProcessingSecurity(): void
    {
        // Create image with embedded malicious data
        $maliciousImage = $this->createImageWithEmbeddedData();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $maliciousImage,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        if ($uploadResult['success']) {
            // Verify embedded data was stripped (in real implementation)
            $savedContent = file_get_contents($uploadResult['saved_path']);
            $this->assertStringNotContainsString('malicious_payload', $savedContent);
        }
    }

    /**
     * Helper: Create image with embedded malicious data
     */
    private function createImageWithEmbeddedData(): array
    {
        // Create a minimal JPEG with embedded text
        $jpegHeader = "\xFF\xD8\xFF\xE0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00";
        $embeddedData = "malicious_payload: <?php system('rm -rf /'); ?>";
        $jpegEnd = "\xFF\xD9";
        
        $content = $jpegHeader . $embeddedData . $jpegEnd;
        
        return $this->createTestFile('embedded.jpg', 'image/jpeg', $content);
    }

    /**
     * Test file cleanup after failed uploads
     */
    public function testFileCleanupAfterFailedUploads(): void
    {
        // Create invalid file that should be rejected
        $invalidFile = $this->createMaliciousPhpFile();
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $invalidFile,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertFalse($uploadResult['success']);
        
        // Verify temporary file was cleaned up
        $this->assertFileDoesNotExist($invalidFile['tmp_name']);
    }

    /**
     * Test upload with various image formats
     */
    public function testUploadWithVariousImageFormats(): void
    {
        $imageTypes = [
            ['png', 'image/png'],
            ['gif', 'image/gif'],
            ['webp', 'image/webp'],
            ['jpg', 'image/jpeg'],
            ['jpeg', 'image/jpeg']
        ];
        
        foreach ($imageTypes as [$extension, $mimeType]) {
            $imageFile = $this->createTestImageFile("test.{$extension}", $mimeType, 1024);
            
            $uploadResult = $this->simulateFileUpload([
                'file' => $imageFile,
                '_token' => $this->auth->generateCsrfToken(),
                'upload_type' => 'content_image'
            ]);
            
            $this->assertTrue($uploadResult['success'], "Failed to upload {$extension} file");
            $this->assertStringEndsWith(".{$extension}", strtolower($uploadResult['filename']));
        }
    }

    /**
     * Test upload size optimization
     */
    public function testUploadSizeOptimization(): void
    {
        // Create large image file
        $largeImage = $this->createTestImageFile('large.jpg', 'image/jpeg', 1500000); // 1.5MB
        
        $uploadResult = $this->simulateFileUpload([
            'file' => $largeImage,
            '_token' => $this->auth->generateCsrfToken(),
            'upload_type' => 'content_image'
        ]);
        
        $this->assertTrue($uploadResult['success']);
        
        // In real implementation, verify image was optimized/resized
        $savedSize = filesize($uploadResult['saved_path']);
        $this->assertLessThan($largeImage['size'], $savedSize + 100000); // Allow some variance
    }
}