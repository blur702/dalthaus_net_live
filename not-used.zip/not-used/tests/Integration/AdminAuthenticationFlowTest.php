<?php

declare(strict_types=1);

namespace Tests\Integration;

use Tests\Support\DatabaseTestCase;
use CMS\Utils\Auth;
use CMS\Utils\Security;
use CMS\Models\User;

/**
 * Admin Authentication Flow Integration Test
 * 
 * Tests the complete authentication workflow including login,
 * session management, CSRF protection, and admin access control.
 */
class AdminAuthenticationFlowTest extends DatabaseTestCase
{
    protected Auth $auth;
    protected array $authConfig;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->authConfig = [
            'session_lifetime' => 3600,
            'login_max_attempts' => 3,
            'login_lockout_time' => 300,
            'password_min_length' => 8,
            'secure_cookies' => false
        ];
        
        $this->auth = new Auth($this->db, $this->authConfig);
    }

    /**
     * Test complete admin login workflow
     */
    public function testCompleteAdminLoginWorkflow(): void
    {
        // Step 1: Create admin user
        $adminUser = $this->createTestUser([
            'username' => 'admin',
            'email' => 'admin@cms.local',
            'password_hash' => password_hash('AdminPass123!', PASSWORD_DEFAULT)
        ]);

        // Step 2: Simulate login form access
        $this->simulateLoginFormAccess();

        // Step 3: Attempt login with correct credentials
        $loginResult = $this->simulateLoginAttempt('admin', 'AdminPass123!');
        $this->assertTrue($loginResult['success']);
        $this->assertArrayHasKey('redirect_url', $loginResult);

        // Step 4: Verify session is established
        $this->assertTrue($this->auth->check());
        $this->assertEquals($adminUser['user_id'], $this->auth->id());

        // Step 5: Verify CSRF token is generated
        $csrfToken = $this->auth->generateCsrfToken();
        $this->assertNotEmpty($csrfToken);
        $this->assertEquals($_SESSION['_token'], $csrfToken);

        // Step 6: Simulate admin dashboard access
        $dashboardAccess = $this->simulateAdminDashboardAccess();
        $this->assertTrue($dashboardAccess['authorized']);
        $this->assertArrayHasKey('user_data', $dashboardAccess);

        // Step 7: Simulate admin action with CSRF protection
        $adminAction = $this->simulateAdminActionWithCsrf($csrfToken);
        $this->assertTrue($adminAction['success']);

        // Step 8: Test session timeout handling
        $this->simulateSessionTimeout();
        $this->assertFalse($this->auth->check());

        // Step 9: Test logout workflow
        $this->simulateLoginAttempt('admin', 'AdminPass123!'); // Login again
        $logoutResult = $this->simulateLogout();
        $this->assertTrue($logoutResult['success']);
        $this->assertFalse($this->auth->check());
    }

    /**
     * Test failed login attempts and lockout mechanism
     */
    public function testFailedLoginAttemptsAndLockout(): void
    {
        // Create admin user
        $adminUser = $this->createTestUser([
            'username' => 'lockouttest',
            'email' => 'lockout@cms.local',
            'password_hash' => password_hash('CorrectPass123', PASSWORD_DEFAULT)
        ]);

        // Step 1: Simulate multiple failed login attempts
        for ($i = 1; $i <= $this->authConfig['login_max_attempts']; $i++) {
            $result = $this->simulateLoginAttempt('lockouttest', 'WrongPassword');
            $this->assertFalse($result['success']);
            $this->assertEquals($i, $result['attempt_count']);
            
            if ($i < $this->authConfig['login_max_attempts']) {
                $this->assertArrayNotHasKey('lockout_time', $result);
            }
        }

        // Step 2: Verify account is locked
        $lockedResult = $this->simulateLoginAttempt('lockouttest', 'CorrectPass123');
        $this->assertFalse($lockedResult['success']);
        $this->assertTrue($lockedResult['locked_out']);
        $this->assertGreaterThan(0, $lockedResult['remaining_lockout_time']);

        // Step 3: Simulate lockout expiration
        $this->simulateLockoutExpiration('lockouttest');
        
        // Step 4: Verify login works after lockout expires
        $unlockedResult = $this->simulateLoginAttempt('lockouttest', 'CorrectPass123');
        $this->assertTrue($unlockedResult['success']);
        $this->assertFalse($unlockedResult['locked_out'] ?? false);
    }

    /**
     * Test CSRF protection across admin actions
     */
    public function testCsrfProtectionAcrossAdminActions(): void
    {
        // Login as admin
        $adminUser = $this->createTestUser([
            'username' => 'csrftest',
            'email' => 'csrf@cms.local',
            'password_hash' => password_hash('CsrfTest123', PASSWORD_DEFAULT)
        ]);

        $this->simulateLoginAttempt('csrftest', 'CsrfTest123');
        $validToken = $this->auth->generateCsrfToken();

        // Test valid CSRF token
        $validResult = $this->simulateAdminActionWithCsrf($validToken);
        $this->assertTrue($validResult['success']);

        // Test invalid CSRF token
        $invalidResult = $this->simulateAdminActionWithCsrf('invalid_token');
        $this->assertFalse($invalidResult['success']);
        $this->assertEquals('Invalid CSRF token', $invalidResult['error']);

        // Test missing CSRF token
        $missingResult = $this->simulateAdminActionWithCsrf('');
        $this->assertFalse($missingResult['success']);
        $this->assertEquals('Invalid CSRF token', $missingResult['error']);

        // Test CSRF token reuse
        $reuseResult = $this->simulateAdminActionWithCsrf($validToken);
        $this->assertTrue($reuseResult['success']); // Token should be reusable
    }

    /**
     * Test concurrent admin sessions
     */
    public function testConcurrentAdminSessions(): void
    {
        $adminUser = $this->createTestUser([
            'username' => 'concurrent',
            'email' => 'concurrent@cms.local',
            'password_hash' => password_hash('Concurrent123', PASSWORD_DEFAULT)
        ]);

        // Simulate first session
        $session1 = $this->createNewSessionContext();
        $this->setSessionContext($session1);
        $result1 = $this->simulateLoginAttempt('concurrent', 'Concurrent123');
        $this->assertTrue($result1['success']);
        $token1 = $this->auth->generateCsrfToken();

        // Simulate second session
        $session2 = $this->createNewSessionContext();
        $this->setSessionContext($session2);
        $result2 = $this->simulateLoginAttempt('concurrent', 'Concurrent123');
        $this->assertTrue($result2['success']);
        $token2 = $this->auth->generateCsrfToken();

        // Verify sessions are independent
        $this->assertNotEquals($token1, $token2);

        // Test actions in both sessions
        $this->setSessionContext($session1);
        $action1 = $this->simulateAdminActionWithCsrf($token1);
        $this->assertTrue($action1['success']);

        $this->setSessionContext($session2);
        $action2 = $this->simulateAdminActionWithCsrf($token2);
        $this->assertTrue($action2['success']);
    }

    /**
     * Test password change workflow
     */
    public function testPasswordChangeWorkflow(): void
    {
        $adminUser = $this->createTestUser([
            'username' => 'passchange',
            'email' => 'passchange@cms.local',
            'password_hash' => password_hash('OldPassword123', PASSWORD_DEFAULT)
        ]);

        // Step 1: Login with old password
        $loginResult = $this->simulateLoginAttempt('passchange', 'OldPassword123');
        $this->assertTrue($loginResult['success']);

        // Step 2: Change password
        $csrfToken = $this->auth->generateCsrfToken();
        $changeResult = $this->simulatePasswordChange([
            'current_password' => 'OldPassword123',
            'new_password' => 'NewPassword456',
            'confirm_password' => 'NewPassword456',
            '_token' => $csrfToken
        ]);
        $this->assertTrue($changeResult['success']);

        // Step 3: Logout
        $this->simulateLogout();

        // Step 4: Try login with old password (should fail)
        $oldPassResult = $this->simulateLoginAttempt('passchange', 'OldPassword123');
        $this->assertFalse($oldPassResult['success']);

        // Step 5: Login with new password (should succeed)
        $newPassResult = $this->simulateLoginAttempt('passchange', 'NewPassword456');
        $this->assertTrue($newPassResult['success']);
    }

    /**
     * Test session hijacking prevention
     */
    public function testSessionHijackingPrevention(): void
    {
        $adminUser = $this->createTestUser([
            'username' => 'hijacktest',
            'email' => 'hijack@cms.local',
            'password_hash' => password_hash('HijackTest123', PASSWORD_DEFAULT)
        ]);

        // Step 1: Normal login
        $loginResult = $this->simulateLoginAttempt('hijacktest', 'HijackTest123');
        $this->assertTrue($loginResult['success']);
        
        $originalSessionId = session_id();
        $csrfToken = $this->auth->generateCsrfToken();

        // Step 2: Simulate session ID change (potential hijacking)
        $this->simulateSessionIdChange();
        
        // Step 3: Verify auth check still works (session should regenerate)
        $authCheck = $this->auth->check();
        $this->assertTrue($authCheck);

        // Step 4: Verify CSRF token is still valid
        $csrfValid = $this->auth->validateCsrfToken($csrfToken);
        $this->assertTrue($csrfValid);

        // Step 5: Simulate suspicious activity
        $suspiciousResult = $this->simulateAbnormalBehavior();
        $this->assertFalse($suspiciousResult['allowed']);
    }

    /**
     * Simulate login form access
     */
    private function simulateLoginFormAccess(): array
    {
        // Simulate loading the login form
        $csrfToken = Security::generateToken();
        $_SESSION['_token'] = $csrfToken;
        
        return [
            'form_loaded' => true,
            'csrf_token' => $csrfToken
        ];
    }

    /**
     * Simulate login attempt
     */
    private function simulateLoginAttempt(string $username, string $password): array
    {
        $result = [
            'success' => false,
            'attempt_count' => 0,
            'locked_out' => false,
            'remaining_lockout_time' => 0
        ];

        // Check if user is locked out
        $remainingLockout = $this->auth->getRemainingLockoutTime($username);
        if ($remainingLockout > 0) {
            $result['locked_out'] = true;
            $result['remaining_lockout_time'] = $remainingLockout;
            return $result;
        }

        // Attempt authentication
        $authResult = $this->auth->attempt($username, $password);
        
        if ($authResult) {
            $result['success'] = true;
            $result['redirect_url'] = '/admin/dashboard';
            $result['user_data'] = $this->auth->user();
        } else {
            $result['attempt_count'] = $_SESSION['login_attempts'][$username] ?? 0;
            if ($result['attempt_count'] >= $this->authConfig['login_max_attempts']) {
                $result['locked_out'] = true;
                $result['remaining_lockout_time'] = $this->auth->getRemainingLockoutTime($username);
            }
        }

        return $result;
    }

    /**
     * Simulate admin dashboard access
     */
    private function simulateAdminDashboardAccess(): array
    {
        $result = [
            'authorized' => false
        ];

        if ($this->auth->check()) {
            $result['authorized'] = true;
            $result['user_data'] = $this->auth->user();
            $result['csrf_token'] = $this->auth->generateCsrfToken();
        }

        return $result;
    }

    /**
     * Simulate admin action with CSRF protection
     */
    private function simulateAdminActionWithCsrf(string $csrfToken): array
    {
        $result = [
            'success' => false
        ];

        if (!$this->auth->check()) {
            $result['error'] = 'Not authenticated';
            return $result;
        }

        if (!$this->auth->validateCsrfToken($csrfToken)) {
            $result['error'] = 'Invalid CSRF token';
            return $result;
        }

        // Simulate successful admin action
        $result['success'] = true;
        $result['action'] = 'Admin action completed successfully';

        return $result;
    }

    /**
     * Simulate session timeout
     */
    private function simulateSessionTimeout(): void
    {
        $_SESSION['last_activity'] = time() - ($this->authConfig['session_lifetime'] + 100);
    }

    /**
     * Simulate logout
     */
    private function simulateLogout(): array
    {
        $this->auth->logout();
        
        return [
            'success' => true,
            'redirect_url' => '/admin/login'
        ];
    }

    /**
     * Simulate lockout expiration
     */
    private function simulateLockoutExpiration(string $username): void
    {
        if (isset($_SESSION['lockout_time'][$username])) {
            $_SESSION['lockout_time'][$username] = time() - ($this->authConfig['login_lockout_time'] + 10);
        }
    }

    /**
     * Simulate password change
     */
    private function simulatePasswordChange(array $data): array
    {
        $result = [
            'success' => false
        ];

        // Validate CSRF token
        if (!$this->auth->validateCsrfToken($data['_token'])) {
            $result['error'] = 'Invalid CSRF token';
            return $result;
        }

        // Validate password match
        if ($data['new_password'] !== $data['confirm_password']) {
            $result['error'] = 'Passwords do not match';
            return $result;
        }

        // Change password
        $userId = $this->auth->id();
        $changeResult = $this->auth->changePassword(
            $userId,
            $data['current_password'],
            $data['new_password']
        );

        if ($changeResult) {
            $result['success'] = true;
            $result['message'] = 'Password changed successfully';
        } else {
            $result['error'] = 'Failed to change password';
        }

        return $result;
    }

    /**
     * Create new session context
     */
    private function createNewSessionContext(): array
    {
        return [
            'session_data' => [],
            'session_id' => 'test_session_' . uniqid()
        ];
    }

    /**
     * Set session context
     */
    private function setSessionContext(array $context): void
    {
        $_SESSION = $context['session_data'];
    }

    /**
     * Simulate session ID change
     */
    private function simulateSessionIdChange(): void
    {
        // In a real scenario, this would involve session_regenerate_id()
        // For testing, we'll simulate the security check
        if ($this->auth->check()) {
            // Session should still be valid after ID regeneration
            $_SESSION['session_regenerated'] = true;
        }
    }

    /**
     * Simulate abnormal behavior detection
     */
    private function simulateAbnormalBehavior(): array
    {
        // Simulate rapid requests from same IP
        $rapidRequests = 50;
        $timeWindow = 10; // seconds
        
        if (!Security::checkRateLimit('admin_actions', $rapidRequests, $timeWindow)) {
            return [
                'allowed' => false,
                'reason' => 'Rate limit exceeded'
            ];
        }

        return [
            'allowed' => true
        ];
    }

    /**
     * Test authentication with remember me functionality
     */
    public function testRememberMeFunctionality(): void
    {
        $adminUser = $this->createTestUser([
            'username' => 'rememberme',
            'email' => 'remember@cms.local',
            'password_hash' => password_hash('RememberMe123', PASSWORD_DEFAULT)
        ]);

        // Simulate login with remember me
        $loginResult = $this->simulateLoginWithRememberMe('rememberme', 'RememberMe123', true);
        $this->assertTrue($loginResult['success']);
        $this->assertArrayHasKey('remember_token', $loginResult);

        // Simulate session expiration
        $this->auth->logout();
        $this->assertFalse($this->auth->check());

        // Simulate remember me token validation
        $rememberResult = $this->simulateRememberMeLogin($loginResult['remember_token']);
        $this->assertTrue($rememberResult['success']);
        $this->assertTrue($this->auth->check());
    }

    /**
     * Simulate login with remember me
     */
    private function simulateLoginWithRememberMe(string $username, string $password, bool $rememberMe): array
    {
        $result = $this->simulateLoginAttempt($username, $password);
        
        if ($result['success'] && $rememberMe) {
            // Generate remember token
            $token = Security::generateToken(32);
            $hashedToken = hash('sha256', $token);
            
            // In real implementation, this would be stored in database
            $_SESSION['remember_token'] = $hashedToken;
            
            $result['remember_token'] = $token;
        }
        
        return $result;
    }

    /**
     * Simulate remember me login
     */
    private function simulateRememberMeLogin(string $token): array
    {
        $hashedToken = hash('sha256', $token);
        $storedToken = $_SESSION['remember_token'] ?? '';
        
        if (hash_equals($storedToken, $hashedToken)) {
            // In real implementation, find user by token and login
            $testUser = $this->createTestUser([
                'username' => 'rememberme',
                'password_hash' => password_hash('RememberMe123', PASSWORD_DEFAULT)
            ]);
            
            // Simulate automatic login
            $_SESSION['user_id'] = $testUser['user_id'];
            $_SESSION['username'] = 'rememberme';
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = time();
            $_SESSION['last_activity'] = time();
            
            return ['success' => true];
        }
        
        return ['success' => false, 'error' => 'Invalid remember token'];
    }

    /**
     * Test admin privilege escalation prevention
     */
    public function testPrivilegeEscalationPrevention(): void
    {
        // Create regular user
        $regularUser = $this->createTestUser([
            'username' => 'regularuser',
            'email' => 'regular@cms.local',
            'password_hash' => password_hash('RegularPass123', PASSWORD_DEFAULT)
        ]);

        // Login as regular user
        $this->simulateLoginAttempt('regularuser', 'RegularPass123');
        $this->assertTrue($this->auth->check());

        // Attempt to access admin-only functions
        $adminActionResult = $this->simulateRestrictedAdminAction();
        $this->assertFalse($adminActionResult['allowed']);
        $this->assertEquals('Insufficient privileges', $adminActionResult['error']);

        // Attempt to modify user role via form tampering
        $escalationResult = $this->simulatePrivilegeEscalationAttempt();
        $this->assertFalse($escalationResult['success']);
        $this->assertEquals('Unauthorized action', $escalationResult['error']);
    }

    /**
     * Simulate restricted admin action
     */
    private function simulateRestrictedAdminAction(): array
    {
        // In real implementation, check user roles/permissions
        $currentUser = $this->auth->user();
        
        // For testing, assume non-admin user
        $isAdmin = ($currentUser['username'] ?? '') === 'admin';
        
        if (!$isAdmin) {
            return [
                'allowed' => false,
                'error' => 'Insufficient privileges'
            ];
        }
        
        return [
            'allowed' => true,
            'action_performed' => true
        ];
    }

    /**
     * Simulate privilege escalation attempt
     */
    private function simulatePrivilegeEscalationAttempt(): array
    {
        // Simulate form submission with role modification
        $formData = [
            'username' => 'regularuser',
            'role' => 'admin', // Malicious attempt to elevate privileges
            '_token' => $this->auth->generateCsrfToken()
        ];
        
        // Security check should prevent this
        if (isset($formData['role']) && $formData['role'] === 'admin') {
            $currentUser = $this->auth->user();
            $isCurrentAdmin = ($currentUser['username'] ?? '') === 'admin';
            
            if (!$isCurrentAdmin) {
                return [
                    'success' => false,
                    'error' => 'Unauthorized action'
                ];
            }
        }
        
        return [
            'success' => true
        ];
    }
}