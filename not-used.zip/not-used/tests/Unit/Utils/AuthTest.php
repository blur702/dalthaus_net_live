<?php

declare(strict_types=1);

namespace Tests\Unit\Utils;

use Tests\Support\DatabaseTestCase;
use CMS\Utils\Auth;
use CMS\Utils\Database;
use ReflectionClass;

/**
 * Auth Utility Test
 * 
 * Tests for the Authentication class including user authentication,
 * session management, CSRF protection, and security features.
 */
class AuthTest extends DatabaseTestCase
{
    protected Auth $auth;
    protected array $authConfig;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->authConfig = [
            'session_lifetime' => 3600,
            'login_max_attempts' => 3,
            'login_lockout_time' => 300,
            'password_min_length' => 6,
            'secure_cookies' => false
        ];
        
        $this->auth = new Auth($this->db, $this->authConfig);
    }

    /**
     * Test successful user authentication
     */
    public function testSuccessfulAuthentication(): void
    {
        // Create test user
        $testUser = $this->createTestUser([
            'username' => 'authuser',
            'email' => 'auth@example.com',
            'password_hash' => password_hash('testpassword', PASSWORD_DEFAULT)
        ]);

        // Test authentication with username
        $result = $this->auth->attempt('authuser', 'testpassword');
        $this->assertTrue($result);
        
        // Verify session data
        $this->assertEquals($testUser['user_id'], $_SESSION['user_id']);
        $this->assertEquals('authuser', $_SESSION['username']);
        $this->assertEquals('auth@example.com', $_SESSION['email']);
        $this->assertTrue($_SESSION['logged_in']);
        $this->assertArrayHasKey('_token', $_SESSION);
        
        // Clean session for next test
        $this->cleanSession();
        
        // Test authentication with email
        $result = $this->auth->attempt('auth@example.com', 'testpassword');
        $this->assertTrue($result);
        $this->assertEquals($testUser['user_id'], $_SESSION['user_id']);
    }

    /**
     * Test failed authentication with wrong password
     */
    public function testFailedAuthenticationWrongPassword(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'wrongpass',
            'email' => 'wrong@example.com',
            'password_hash' => password_hash('correctpassword', PASSWORD_DEFAULT)
        ]);

        $result = $this->auth->attempt('wrongpass', 'wrongpassword');
        $this->assertFalse($result);
        
        // Verify session was not created
        $this->assertArrayNotHasKey('user_id', $_SESSION);
        $this->assertArrayNotHasKey('logged_in', $_SESSION);
        
        // Verify failed attempt was recorded
        $this->assertArrayHasKey('login_attempts', $_SESSION);
        $this->assertEquals(1, $_SESSION['login_attempts']['wrongpass']);
    }

    /**
     * Test failed authentication with non-existing user
     */
    public function testFailedAuthenticationNonExistingUser(): void
    {
        $result = $this->auth->attempt('nonexisting', 'password');
        $this->assertFalse($result);
        
        // Verify failed attempt was recorded
        $this->assertArrayHasKey('login_attempts', $_SESSION);
        $this->assertEquals(1, $_SESSION['login_attempts']['nonexisting']);
    }

    /**
     * Test login lockout after max attempts
     */
    public function testLoginLockout(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'lockoutuser',
            'password_hash' => password_hash('correctpassword', PASSWORD_DEFAULT)
        ]);

        // Attempt failed logins up to max attempts
        for ($i = 0; $i < $this->authConfig['login_max_attempts']; $i++) {
            $result = $this->auth->attempt('lockoutuser', 'wrongpassword');
            $this->assertFalse($result);
        }
        
        // Now user should be locked out even with correct password
        $result = $this->auth->attempt('lockoutuser', 'correctpassword');
        $this->assertFalse($result);
        
        // Verify lockout time
        $remainingTime = $this->auth->getRemainingLockoutTime('lockoutuser');
        $this->assertGreaterThan(0, $remainingTime);
        $this->assertLessThanOrEqual($this->authConfig['login_lockout_time'], $remainingTime);
    }

    /**
     * Test lockout expiration
     */
    public function testLockoutExpiration(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'expireuser',
            'password_hash' => password_hash('correctpassword', PASSWORD_DEFAULT)
        ]);

        // Simulate lockout by setting failed attempts
        $_SESSION['login_attempts']['expireuser'] = $this->authConfig['login_max_attempts'];
        $_SESSION['lockout_time']['expireuser'] = time() - ($this->authConfig['login_lockout_time'] + 10);
        
        // Should be able to login again after lockout expires
        $result = $this->auth->attempt('expireuser', 'correctpassword');
        $this->assertTrue($result);
        
        // Failed attempts should be cleared
        $this->assertArrayNotHasKey('expireuser', $_SESSION['login_attempts'] ?? []);
    }

    /**
     * Test user logout
     */
    public function testUserLogout(): void
    {
        // First login
        $testUser = $this->createTestUser([
            'username' => 'logoutuser',
            'password_hash' => password_hash('testpassword', PASSWORD_DEFAULT)
        ]);
        
        $this->auth->attempt('logoutuser', 'testpassword');
        $this->assertTrue($_SESSION['logged_in']);
        
        // Then logout
        $this->auth->logout();
        
        // Verify session was cleared
        $this->assertEmpty($_SESSION);
    }

    /**
     * Test authentication check
     */
    public function testAuthenticationCheck(): void
    {
        // Initially not authenticated
        $this->assertFalse($this->auth->check());
        
        // Login user
        $testUser = $this->createTestUser([
            'username' => 'checkuser',
            'password_hash' => password_hash('testpassword', PASSWORD_DEFAULT)
        ]);
        
        $this->auth->attempt('checkuser', 'testpassword');
        
        // Now should be authenticated
        $this->assertTrue($this->auth->check());
        
        // Test session expiration
        $_SESSION['last_activity'] = time() - ($this->authConfig['session_lifetime'] + 10);
        $this->assertFalse($this->auth->check());
        
        // Session should be cleared after expiration
        $this->assertEmpty($_SESSION);
    }

    /**
     * Test getting current user data
     */
    public function testGetCurrentUser(): void
    {
        // No user when not authenticated
        $this->assertNull($this->auth->user());
        $this->assertNull($this->auth->id());
        
        // Login user
        $testUser = $this->createTestUser([
            'username' => 'currentuser',
            'email' => 'current@example.com',
            'password_hash' => password_hash('testpassword', PASSWORD_DEFAULT)
        ]);
        
        $this->auth->attempt('currentuser', 'testpassword');
        
        // Get user data
        $userData = $this->auth->user();
        $this->assertNotNull($userData);
        $this->assertEquals($testUser['user_id'], $userData['user_id']);
        $this->assertEquals('currentuser', $userData['username']);
        $this->assertEquals('current@example.com', $userData['email']);
        $this->assertArrayHasKey('login_time', $userData);
        
        // Get user ID
        $userId = $this->auth->id();
        $this->assertEquals($testUser['user_id'], $userId);
    }

    /**
     * Test CSRF token generation and validation
     */
    public function testCsrfToken(): void
    {
        // Generate token
        $token = $this->auth->generateCsrfToken();
        $this->assertNotEmpty($token);
        $this->assertEquals(64, strlen($token)); // 32 bytes * 2 (hex)
        
        // Validate correct token
        $this->assertTrue($this->auth->validateCsrfToken($token));
        
        // Validate wrong token
        $this->assertFalse($this->auth->validateCsrfToken('wrong_token'));
        
        // Validate empty token
        $this->assertFalse($this->auth->validateCsrfToken(''));
        
        // Generate again should return same token
        $sameToken = $this->auth->generateCsrfToken();
        $this->assertEquals($token, $sameToken);
    }

    /**
     * Test user creation
     */
    public function testCreateUser(): void
    {
        $userId = $this->auth->createUser('newuser', 'newuser@example.com', 'securepassword');
        $this->assertIsInt($userId);
        $this->assertGreaterThan(0, $userId);
        
        // Verify user was created in database
        $user = $this->db->fetchRow(
            'SELECT * FROM users WHERE user_id = ?',
            [$userId]
        );
        
        $this->assertEquals('newuser', $user['username']);
        $this->assertEquals('newuser@example.com', $user['email']);
        $this->assertTrue(password_verify('securepassword', $user['password_hash']));
    }

    /**
     * Test user creation validation
     */
    public function testCreateUserValidation(): void
    {
        // Test empty username
        $result = $this->auth->createUser('', 'test@example.com', 'password');
        $this->assertFalse($result);
        
        // Test empty email
        $result = $this->auth->createUser('testuser', '', 'password');
        $this->assertFalse($result);
        
        // Test empty password
        $result = $this->auth->createUser('testuser', 'test@example.com', '');
        $this->assertFalse($result);
        
        // Test weak password
        $result = $this->auth->createUser('testuser', 'test@example.com', '123');
        $this->assertFalse($result);
        
        // Test duplicate user
        $this->createTestUser(['username' => 'duplicate', 'email' => 'dup@test.com']);
        $result = $this->auth->createUser('duplicate', 'different@test.com', 'password');
        $this->assertFalse($result);
        
        $result = $this->auth->createUser('different', 'dup@test.com', 'password');
        $this->assertFalse($result);
    }

    /**
     * Test password change
     */
    public function testChangePassword(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'passchange',
            'password_hash' => password_hash('oldpassword', PASSWORD_DEFAULT)
        ]);
        
        // Test successful password change
        $result = $this->auth->changePassword($testUser['user_id'], 'oldpassword', 'newpassword123');
        $this->assertTrue($result);
        
        // Verify old password no longer works
        $user = $this->db->fetchRow('SELECT password_hash FROM users WHERE user_id = ?', [$testUser['user_id']]);
        $this->assertFalse(password_verify('oldpassword', $user['password_hash']));
        $this->assertTrue(password_verify('newpassword123', $user['password_hash']));
        
        // Test wrong current password
        $result = $this->auth->changePassword($testUser['user_id'], 'wrongpassword', 'newpassword456');
        $this->assertFalse($result);
        
        // Test weak new password
        $result = $this->auth->changePassword($testUser['user_id'], 'newpassword123', '123');
        $this->assertFalse($result);
        
        // Test non-existing user
        $result = $this->auth->changePassword(99999, 'password', 'newpassword');
        $this->assertFalse($result);
    }

    /**
     * Test profile update
     */
    public function testUpdateProfile(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'profileupdate',
            'email' => 'profile@example.com'
        ]);
        
        // Test successful update
        $result = $this->auth->updateProfile($testUser['user_id'], [
            'username' => 'updatedusername',
            'email' => 'updated@example.com'
        ]);
        $this->assertTrue($result);
        
        // Verify update in database
        $updated = $this->db->fetchRow('SELECT * FROM users WHERE user_id = ?', [$testUser['user_id']]);
        $this->assertEquals('updatedusername', $updated['username']);
        $this->assertEquals('updated@example.com', $updated['email']);
        
        // Test update with duplicate data
        $otherUser = $this->createTestUser(['username' => 'other', 'email' => 'other@test.com']);
        $result = $this->auth->updateProfile($testUser['user_id'], [
            'username' => 'other'
        ]);
        $this->assertFalse($result);
        
        // Test update with empty data
        $result = $this->auth->updateProfile($testUser['user_id'], []);
        $this->assertFalse($result);
        
        // Test update with invalid fields (should be filtered out)
        $result = $this->auth->updateProfile($testUser['user_id'], [
            'username' => 'validusername',
            'password_hash' => 'malicious_hash',
            'invalid_field' => 'value'
        ]);
        $this->assertTrue($result);
        
        $user = $this->db->fetchRow('SELECT * FROM users WHERE user_id = ?', [$testUser['user_id']]);
        $this->assertEquals('validusername', $user['username']);
        $this->assertNotEquals('malicious_hash', $user['password_hash']);
    }

    /**
     * Test session update for current user profile changes
     */
    public function testSessionUpdateOnProfileChange(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'sessionupdate',
            'email' => 'session@example.com',
            'password_hash' => password_hash('password', PASSWORD_DEFAULT)
        ]);
        
        // Login user
        $this->auth->attempt('sessionupdate', 'password');
        $this->assertEquals('sessionupdate', $_SESSION['username']);
        $this->assertEquals('session@example.com', $_SESSION['email']);
        
        // Update profile
        $this->auth->updateProfile($testUser['user_id'], [
            'username' => 'newsessionname',
            'email' => 'newsession@example.com'
        ]);
        
        // Verify session was updated
        $this->assertEquals('newsessionname', $_SESSION['username']);
        $this->assertEquals('newsession@example.com', $_SESSION['email']);
    }

    /**
     * Test private method accessibility
     */
    public function testPrivateMethodFunctionality(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'privatetest',
            'password_hash' => password_hash('password', PASSWORD_DEFAULT)
        ]);
        
        // Test findUser method
        $foundUser = $this->callProtectedMethod($this->auth, 'findUser', ['privatetest']);
        $this->assertEquals('privatetest', $foundUser['username']);
        
        // Test isValidPassword method
        $isValid = $this->callProtectedMethod($this->auth, 'isValidPassword', ['validpassword']);
        $this->assertTrue($isValid);
        
        $isInvalid = $this->callProtectedMethod($this->auth, 'isValidPassword', ['weak']);
        $this->assertFalse($isInvalid);
        
        // Test userExists method
        $exists = $this->callProtectedMethod($this->auth, 'userExists', ['privatetest', 'test@test.com']);
        $this->assertTrue($exists);
        
        $notExists = $this->callProtectedMethod($this->auth, 'userExists', ['notexists', 'not@test.com']);
        $this->assertFalse($notExists);
    }

    /**
     * Test session security features
     */
    public function testSessionSecurity(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'secureuser',
            'password_hash' => password_hash('password', PASSWORD_DEFAULT)
        ]);
        
        // Mock session_regenerate_id function call
        $originalSessionId = session_id();
        
        $this->auth->attempt('secureuser', 'password');
        
        // Verify security session data
        $this->assertArrayHasKey('login_time', $_SESSION);
        $this->assertArrayHasKey('last_activity', $_SESSION);
        $this->assertArrayHasKey('_token', $_SESSION);
        
        $this->assertIsRecentTimestamp(date('Y-m-d H:i:s', $_SESSION['login_time']));
        $this->assertIsRecentTimestamp(date('Y-m-d H:i:s', $_SESSION['last_activity']));
    }

    /**
     * Test authentication with different configurations
     */
    public function testAuthenticationWithDifferentConfigs(): void
    {
        $strictConfig = [
            'session_lifetime' => 1800,
            'login_max_attempts' => 2,
            'login_lockout_time' => 600,
            'password_min_length' => 10,
            'secure_cookies' => true
        ];
        
        $strictAuth = new Auth($this->db, $strictConfig);
        
        $testUser = $this->createTestUser([
            'username' => 'strictuser',
            'password_hash' => password_hash('verylongpassword', PASSWORD_DEFAULT)
        ]);
        
        // Should work with long password
        $result = $strictAuth->attempt('strictuser', 'verylongpassword');
        $this->assertTrue($result);
        
        // Should lock out faster
        $this->cleanSession();
        
        for ($i = 0; $i < 2; $i++) {
            $strictAuth->attempt('strictuser', 'wrongpassword');
        }
        
        $result = $strictAuth->attempt('strictuser', 'verylongpassword');
        $this->assertFalse($result);
        
        $remainingTime = $strictAuth->getRemainingLockoutTime('strictuser');
        $this->assertGreaterThan(0, $remainingTime);
    }
}