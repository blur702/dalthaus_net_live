<?php

declare(strict_types=1);

namespace Tests\Unit\Utils;

use Tests\Support\TestCase;
use CMS\Utils\Database;
use PDO;
use PDOException;
use Exception;

/**
 * Database Utility Test
 * 
 * Tests for the Database wrapper class including connection management,
 * query execution, transaction handling, and security features.
 */
class DatabaseTest extends TestCase
{
    protected Database $db;
    protected array $testConfig;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Use SQLite in-memory database for testing
        $this->testConfig = [
            'host' => ':memory:',
            'dbname' => ':memory:',
            'username' => '',
            'password' => '',
            'charset' => 'utf8',
            'options' => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        ];
        
        $this->db = Database::getInstance($this->testConfig);
        $this->setUpTestTable();
    }

    protected function tearDown(): void
    {
        // Clean up - reset singleton
        $reflection = new \ReflectionClass(Database::class);
        $instanceProperty = $reflection->getProperty('instance');
        $instanceProperty->setAccessible(true);
        $instanceProperty->setValue(null, null);
        
        parent::tearDown();
    }

    /**
     * Set up test table for database operations
     */
    private function setUpTestTable(): void
    {
        $this->db->query("
            CREATE TABLE test_table (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
    }

    /**
     * Test singleton pattern implementation
     */
    public function testSingletonPattern(): void
    {
        $db1 = Database::getInstance($this->testConfig);
        $db2 = Database::getInstance();
        
        $this->assertSame($db1, $db2, 'Database should implement singleton pattern');
    }

    /**
     * Test database connection
     */
    public function testDatabaseConnection(): void
    {
        $connection = $this->db->getConnection();
        $this->assertInstanceOf(PDO::class, $connection);
    }

    /**
     * Test configuration requirement for first instance
     */
    public function testConfigurationRequiredForFirstInstance(): void
    {
        // Reset singleton
        $reflection = new \ReflectionClass(Database::class);
        $instanceProperty = $reflection->getProperty('instance');
        $instanceProperty->setAccessible(true);
        $instanceProperty->setValue(null, null);
        
        $this->expectException(Exception::class);
        $this->expectExceptionMessage('Database configuration is required on first call');
        
        Database::getInstance();
    }

    /**
     * Test invalid database connection throws exception
     */
    public function testInvalidConnectionThrowsException(): void
    {
        // Reset singleton
        $reflection = new \ReflectionClass(Database::class);
        $instanceProperty = $reflection->getProperty('instance');
        $instanceProperty->setAccessible(true);
        $instanceProperty->setValue(null, null);
        
        $invalidConfig = [
            'host' => 'invalid_host',
            'dbname' => 'invalid_db',
            'username' => 'invalid_user',
            'password' => 'invalid_pass',
            'charset' => 'utf8',
            'options' => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        ];
        
        $this->expectException(PDOException::class);
        $this->expectExceptionMessage('Database connection failed');
        
        Database::getInstance($invalidConfig);
    }

    /**
     * Test basic query execution
     */
    public function testQueryExecution(): void
    {
        $stmt = $this->db->query("SELECT COUNT(*) as count FROM test_table");
        $this->assertInstanceOf(\PDOStatement::class, $stmt);
        
        $result = $stmt->fetch();
        $this->assertEquals(0, $result['count']);
    }

    /**
     * Test query with parameters
     */
    public function testQueryWithParameters(): void
    {
        // Insert test data
        $this->db->query(
            "INSERT INTO test_table (name, email, age) VALUES (?, ?, ?)",
            ['John Doe', 'john@example.com', 30]
        );
        
        // Query with parameters
        $stmt = $this->db->query(
            "SELECT * FROM test_table WHERE name = ? AND age = ?",
            ['John Doe', 30]
        );
        
        $result = $stmt->fetch();
        $this->assertEquals('John Doe', $result['name']);
        $this->assertEquals('john@example.com', $result['email']);
        $this->assertEquals(30, $result['age']);
    }

    /**
     * Test fetchAll method
     */
    public function testFetchAll(): void
    {
        // Insert test data
        $testData = [
            ['Alice', 'alice@example.com', 25],
            ['Bob', 'bob@example.com', 35],
            ['Charlie', 'charlie@example.com', 28]
        ];
        
        foreach ($testData as $row) {
            $this->db->query(
                "INSERT INTO test_table (name, email, age) VALUES (?, ?, ?)",
                $row
            );
        }
        
        $results = $this->db->fetchAll("SELECT * FROM test_table ORDER BY name");
        
        $this->assertCount(3, $results);
        $this->assertEquals('Alice', $results[0]['name']);
        $this->assertEquals('Bob', $results[1]['name']);
        $this->assertEquals('Charlie', $results[2]['name']);
    }

    /**
     * Test fetchRow method
     */
    public function testFetchRow(): void
    {
        // Insert test data
        $this->db->query(
            "INSERT INTO test_table (name, email, age) VALUES (?, ?, ?)",
            ['John Doe', 'john@example.com', 30]
        );
        
        $row = $this->db->fetchRow("SELECT * FROM test_table WHERE name = ?", ['John Doe']);
        
        $this->assertIsArray($row);
        $this->assertEquals('John Doe', $row['name']);
        $this->assertEquals('john@example.com', $row['email']);
        
        // Test non-existing row
        $nonExisting = $this->db->fetchRow("SELECT * FROM test_table WHERE name = ?", ['Non Existing']);
        $this->assertFalse($nonExisting);
    }

    /**
     * Test fetchColumn method
     */
    public function testFetchColumn(): void
    {
        // Insert test data
        $this->db->query(
            "INSERT INTO test_table (name, email, age) VALUES (?, ?, ?)",
            ['John Doe', 'john@example.com', 30]
        );
        
        $name = $this->db->fetchColumn("SELECT name FROM test_table WHERE age = ?", [30]);
        $this->assertEquals('John Doe', $name);
        
        $count = $this->db->fetchColumn("SELECT COUNT(*) FROM test_table");
        $this->assertEquals(1, $count);
    }

    /**
     * Test insert method
     */
    public function testInsert(): void
    {
        $data = [
            'name' => 'Jane Doe',
            'email' => 'jane@example.com',
            'age' => 28
        ];
        
        $lastInsertId = $this->db->insert('test_table', $data);
        $this->assertNotEmpty($lastInsertId);
        
        // Verify insertion
        $inserted = $this->db->fetchRow("SELECT * FROM test_table WHERE id = ?", [$lastInsertId]);
        $this->assertEquals('Jane Doe', $inserted['name']);
        $this->assertEquals('jane@example.com', $inserted['email']);
        $this->assertEquals(28, $inserted['age']);
    }

    /**
     * Test update method
     */
    public function testUpdate(): void
    {
        // Insert test data first
        $insertId = $this->db->insert('test_table', [
            'name' => 'John Doe',
            'email' => 'john@example.com',
            'age' => 30
        ]);
        
        // Update the record
        $updateData = [
            'name' => 'John Updated',
            'age' => 31
        ];
        
        $affectedRows = $this->db->update(
            'test_table',
            $updateData,
            'id = ?',
            [$insertId]
        );
        
        $this->assertEquals(1, $affectedRows);
        
        // Verify update
        $updated = $this->db->fetchRow("SELECT * FROM test_table WHERE id = ?", [$insertId]);
        $this->assertEquals('John Updated', $updated['name']);
        $this->assertEquals(31, $updated['age']);
        $this->assertEquals('john@example.com', $updated['email']); // Should remain unchanged
    }

    /**
     * Test delete method
     */
    public function testDelete(): void
    {
        // Insert test data first
        $insertId = $this->db->insert('test_table', [
            'name' => 'To Delete',
            'email' => 'delete@example.com',
            'age' => 25
        ]);
        
        // Delete the record
        $deletedRows = $this->db->delete('test_table', 'id = ?', [$insertId]);
        $this->assertEquals(1, $deletedRows);
        
        // Verify deletion
        $deleted = $this->db->fetchRow("SELECT * FROM test_table WHERE id = ?", [$insertId]);
        $this->assertFalse($deleted);
    }

    /**
     * Test count method
     */
    public function testCount(): void
    {
        // Initially should be empty
        $initialCount = $this->db->count('test_table');
        $this->assertEquals(0, $initialCount);
        
        // Insert test data
        $testData = [
            ['Alice', 'alice@example.com', 25],
            ['Bob', 'bob@example.com', 35],
            ['Charlie', 'charlie@example.com', 25]
        ];
        
        foreach ($testData as $row) {
            $this->db->insert('test_table', [
                'name' => $row[0],
                'email' => $row[1],
                'age' => $row[2]
            ]);
        }
        
        // Test total count
        $totalCount = $this->db->count('test_table');
        $this->assertEquals(3, $totalCount);
        
        // Test count with conditions
        $age25Count = $this->db->count('test_table', 'age = ?', [25]);
        $this->assertEquals(2, $age25Count);
    }

    /**
     * Test exists method
     */
    public function testExists(): void
    {
        // Initially should not exist
        $this->assertFalse($this->db->exists('test_table', 'name = ?', ['John']));
        
        // Insert test data
        $this->db->insert('test_table', [
            'name' => 'John',
            'email' => 'john@example.com',
            'age' => 30
        ]);
        
        // Now should exist
        $this->assertTrue($this->db->exists('test_table', 'name = ?', ['John']));
        $this->assertFalse($this->db->exists('test_table', 'name = ?', ['NonExisting']));
    }

    /**
     * Test transaction methods
     */
    public function testTransactionMethods(): void
    {
        // Test successful transaction
        $this->assertTrue($this->db->beginTransaction());
        
        $this->db->insert('test_table', [
            'name' => 'Transaction Test',
            'email' => 'trans@example.com',
            'age' => 30
        ]);
        
        $this->assertTrue($this->db->commit());
        
        // Verify data was committed
        $this->assertTrue($this->db->exists('test_table', 'name = ?', ['Transaction Test']));
        
        // Test rollback
        $this->db->beginTransaction();
        
        $this->db->insert('test_table', [
            'name' => 'Rollback Test',
            'email' => 'rollback@example.com',
            'age' => 25
        ]);
        
        $this->assertTrue($this->db->rollback());
        
        // Verify data was rolled back
        $this->assertFalse($this->db->exists('test_table', 'name = ?', ['Rollback Test']));
    }

    /**
     * Test transaction callback method
     */
    public function testTransactionCallback(): void
    {
        // Test successful transaction with callback
        $result = $this->db->transaction(function ($db) {
            $id1 = $db->insert('test_table', [
                'name' => 'User 1',
                'email' => 'user1@example.com',
                'age' => 25
            ]);
            
            $id2 = $db->insert('test_table', [
                'name' => 'User 2',
                'email' => 'user2@example.com',
                'age' => 30
            ]);
            
            return [$id1, $id2];
        });
        
        $this->assertIsArray($result);
        $this->assertCount(2, $result);
        
        // Verify both records exist
        $this->assertTrue($this->db->exists('test_table', 'name = ?', ['User 1']));
        $this->assertTrue($this->db->exists('test_table', 'name = ?', ['User 2']));
        
        // Test transaction with exception (should rollback)
        try {
            $this->db->transaction(function ($db) {
                $db->insert('test_table', [
                    'name' => 'User 3',
                    'email' => 'user3@example.com',
                    'age' => 35
                ]);
                
                throw new \Exception('Test exception');
            });
        } catch (\Exception $e) {
            $this->assertEquals('Test exception', $e->getMessage());
        }
        
        // Verify rollback occurred
        $this->assertFalse($this->db->exists('test_table', 'name = ?', ['User 3']));
    }

    /**
     * Test lastInsertId method
     */
    public function testLastInsertId(): void
    {
        $insertId1 = $this->db->insert('test_table', [
            'name' => 'First',
            'email' => 'first@example.com',
            'age' => 25
        ]);
        
        $lastId = $this->db->lastInsertId();
        $this->assertEquals($insertId1, $lastId);
        
        $insertId2 = $this->db->insert('test_table', [
            'name' => 'Second',
            'email' => 'second@example.com',
            'age' => 30
        ]);
        
        $newLastId = $this->db->lastInsertId();
        $this->assertEquals($insertId2, $newLastId);
        $this->assertNotEquals($insertId1, $newLastId);
    }

    /**
     * Test quote method
     */
    public function testQuote(): void
    {
        $unsafeString = "'; DROP TABLE test_table; --";
        $quotedString = $this->db->quote($unsafeString);
        
        $this->assertNotEquals($unsafeString, $quotedString);
        $this->assertStringContainsString("''", $quotedString); // Should escape quotes
    }

    /**
     * Test query error handling
     */
    public function testQueryErrorHandling(): void
    {
        $this->expectException(PDOException::class);
        $this->expectExceptionMessage('Query execution failed');
        
        $this->db->query("SELECT * FROM non_existing_table");
    }

    /**
     * Test prevention of cloning and unserialization
     */
    public function testSingletonProtection(): void
    {
        $db = Database::getInstance($this->testConfig);
        
        // Test cloning is prevented
        $reflection = new \ReflectionClass($db);
        $cloneMethod = $reflection->getMethod('__clone');
        $this->assertTrue($cloneMethod->isPrivate());
        
        // Test unserialization throws exception
        $this->expectException(Exception::class);
        $this->expectExceptionMessage('Cannot unserialize Database instance');
        
        $db->__wakeup();
    }

    /**
     * Test prepared statement parameter binding
     */
    public function testParameterBinding(): void
    {
        // Insert data with various parameter types
        $this->db->insert('test_table', [
            'name' => 'Parameter Test',
            'email' => 'param@example.com',
            'age' => 25
        ]);
        
        // Test different parameter binding scenarios
        $results = $this->db->fetchAll(
            "SELECT * FROM test_table WHERE name = ? AND age >= ? AND email LIKE ?",
            ['Parameter Test', 20, '%param%']
        );
        
        $this->assertCount(1, $results);
        $this->assertEquals('Parameter Test', $results[0]['name']);
    }

    /**
     * Test concurrent database operations
     */
    public function testConcurrentOperations(): void
    {
        // Test multiple inserts in sequence
        $ids = [];
        for ($i = 1; $i <= 5; $i++) {
            $ids[] = $this->db->insert('test_table', [
                'name' => "User {$i}",
                'email' => "user{$i}@example.com",
                'age' => 20 + $i
            ]);
        }
        
        // Verify all records exist
        $count = $this->db->count('test_table');
        $this->assertEquals(5, $count);
        
        // Test batch update
        foreach ($ids as $i => $id) {
            $this->db->update(
                'test_table',
                ['age' => 30 + $i],
                'id = ?',
                [$id]
            );
        }
        
        // Verify updates
        $avgAge = $this->db->fetchColumn("SELECT AVG(age) FROM test_table");
        $this->assertGreaterThan(30, $avgAge);
    }
}