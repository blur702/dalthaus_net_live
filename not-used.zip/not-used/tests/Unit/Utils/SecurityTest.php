<?php

declare(strict_types=1);

namespace Tests\Unit\Utils;

use Tests\Support\TestCase;
use CMS\Utils\Security;

/**
 * Security Utility Test
 * 
 * Tests for the Security class including input sanitization,
 * XSS protection, CSRF validation, file upload security,
 * and other security-related utilities.
 */
class SecurityTest extends TestCase
{
    /**
     * Test basic string sanitization
     */
    public function testSanitizeString(): void
    {
        // Test basic HTML encoding
        $input = '<script>alert("xss")</script>';
        $sanitized = Security::sanitize($input);
        $this->assertEquals('&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;', $sanitized);
        
        // Test with quotes
        $input = 'Hello "World" & \'Test\'';
        $sanitized = Security::sanitize($input);
        $this->assertEquals('Hello &quot;World&quot; &amp; &#039;Test&#039;', $sanitized);
        
        // Test trimming
        $input = '  whitespace test  ';
        $sanitized = Security::sanitize($input);
        $this->assertEquals('whitespace test', $sanitized);
        
        // Test without trimming
        $sanitized = Security::sanitize($input, false);
        $this->assertEquals('  whitespace test  ', $sanitized);
    }

    /**
     * Test array sanitization
     */
    public function testSanitizeArray(): void
    {
        $input = [
            'name' => '<script>alert("name")</script>',
            'email' => 'test@example.com',
            'nested' => [
                'value' => '<b>bold</b>',
                'number' => 123
            ],
            'number' => 456
        ];
        
        $sanitized = Security::sanitizeArray($input);
        
        $this->assertEquals('&lt;script&gt;alert(&quot;name&quot;)&lt;/script&gt;', $sanitized['name']);
        $this->assertEquals('test@example.com', $sanitized['email']);
        $this->assertEquals('&lt;b&gt;bold&lt;/b&gt;', $sanitized['nested']['value']);
        $this->assertEquals(123, $sanitized['nested']['number']);
        $this->assertEquals(456, $sanitized['number']);
    }

    /**
     * Test HTML content cleaning
     */
    public function testCleanHtml(): void
    {
        // Test allowed tags
        $allowedHtml = '<p>Test paragraph</p><strong>Bold text</strong><a href="https://example.com">Link</a>';
        $cleaned = Security::cleanHtml($allowedHtml);
        $this->assertStringContainsString('<p>Test paragraph</p>', $cleaned);
        $this->assertStringContainsString('<strong>Bold text</strong>', $cleaned);
        $this->assertStringContainsString('<a href="https://example.com">Link</a>', $cleaned);
        
        // Test dangerous tags removal
        $dangerousHtml = '<script>alert("xss")</script><p>Safe content</p><iframe src="evil.com"></iframe>';
        $cleaned = Security::cleanHtml($dangerousHtml);
        $this->assertStringNotContainsString('<script>', $cleaned);
        $this->assertStringNotContainsString('<iframe>', $cleaned);
        $this->assertStringContainsString('<p>Safe content</p>', $cleaned);
        
        // Test dangerous URLs
        $dangerousLinks = '<a href="javascript:alert(\'xss\')">Link</a><a href="https://safe.com">Safe</a>';
        $cleaned = Security::cleanHtml($dangerousLinks);
        $this->assertStringNotContainsString('javascript:', $cleaned);
        $this->assertStringContainsString('https://safe.com', $cleaned);
        
        // Test attribute cleaning
        $maliciousAttrs = '<div onclick="alert(\'xss\')" class="safe">Content</div>';
        $cleaned = Security::cleanHtml($maliciousAttrs);
        $this->assertStringNotContainsString('onclick', $cleaned);
        $this->assertStringContainsString('class="safe"', $cleaned);
    }

    /**
     * Test secure token generation
     */
    public function testGenerateToken(): void
    {
        $token1 = Security::generateToken();
        $token2 = Security::generateToken();
        
        $this->assertNotEmpty($token1);
        $this->assertNotEmpty($token2);
        $this->assertNotEquals($token1, $token2);
        $this->assertEquals(64, strlen($token1)); // 32 bytes * 2 (hex)
        $this->assertMatchesRegularExpression('/^[a-f0-9]+$/', $token1);
        
        // Test custom length
        $customToken = Security::generateToken(16);
        $this->assertEquals(32, strlen($customToken)); // 16 bytes * 2 (hex)
    }

    /**
     * Test email validation
     */
    public function testEmailValidation(): void
    {
        // Valid emails
        $validEmails = [
            'test@example.com',
            'user.name@example.co.uk',
            'user+tag@example.org',
            'user123@test-domain.com'
        ];
        
        foreach ($validEmails as $email) {
            $this->assertTrue(Security::isValidEmail($email), "Failed to validate: {$email}");
        }
        
        // Invalid emails
        $invalidEmails = [
            'invalid-email',
            '@example.com',
            'test@',
            'test..test@example.com',
            'test@example',
            ''
        ];
        
        foreach ($invalidEmails as $email) {
            $this->assertFalse(Security::isValidEmail($email), "Incorrectly validated: {$email}");
        }
    }

    /**
     * Test URL validation
     */
    public function testUrlValidation(): void
    {
        // Valid URLs
        $validUrls = [
            'https://example.com',
            'http://test.org/path',
            'https://sub.domain.com/path?param=value',
            'ftp://files.example.com'
        ];
        
        foreach ($validUrls as $url) {
            $this->assertTrue(Security::isValidUrl($url), "Failed to validate: {$url}");
        }
        
        // Invalid URLs
        $invalidUrls = [
            'not-a-url',
            'http://',
            'https://.',
            'javascript:alert(1)',
            ''
        ];
        
        foreach ($invalidUrls as $url) {
            $this->assertFalse(Security::isValidUrl($url), "Incorrectly validated: {$url}");
        }
    }

    /**
     * Test URL alias creation
     */
    public function testCreateUrlAlias(): void
    {
        // Test basic conversion
        $this->assertEquals('hello-world', Security::createUrlAlias('Hello World'));
        $this->assertEquals('test-article-123', Security::createUrlAlias('Test Article 123'));
        
        // Test special characters
        $this->assertEquals('special-chars-test', Security::createUrlAlias('Special!@#$%^&*()Chars Test'));
        
        // Test multiple spaces/hyphens
        $this->assertEquals('multiple-spaces', Security::createUrlAlias('Multiple   Spaces'));
        $this->assertEquals('trim-hyphens', Security::createUrlAlias('--Trim Hyphens--'));
        
        // Test length limiting
        $longTitle = str_repeat('Long Title ', 20);
        $alias = Security::createUrlAlias($longTitle, 50);
        $this->assertLessThanOrEqual(50, strlen($alias));
        $this->assertStringEndsNotWith('-', $alias);
        
        // Test empty input
        $this->assertEquals('', Security::createUrlAlias(''));
        $this->assertEquals('', Security::createUrlAlias('!@#$%^&*()'));
    }

    /**
     * Test file upload validation
     */
    public function testValidateFileUpload(): void
    {
        // Test valid file upload
        $validFile = [
            'name' => 'test.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => $this->createTempFile('fake jpeg content'),
            'error' => UPLOAD_ERR_OK,
            'size' => 1024
        ];
        
        $result = Security::validateFileUpload($validFile, ['jpg', 'png'], 2048);
        $this->assertTrue($result['valid']);
        $this->assertEmpty($result['errors']);
        
        // Test file not uploaded
        $noFile = [
            'name' => '',
            'type' => '',
            'tmp_name' => '',
            'error' => UPLOAD_ERR_NO_FILE,
            'size' => 0
        ];
        
        $result = Security::validateFileUpload($noFile);
        $this->assertFalse($result['valid']);
        $this->assertNotEmpty($result['errors']);
        
        // Test file too large
        $largeFile = [
            'name' => 'large.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => $this->createTempFile('content'),
            'error' => UPLOAD_ERR_OK,
            'size' => 5000
        ];
        
        $result = Security::validateFileUpload($largeFile, ['jpg'], 1000);
        $this->assertFalse($result['valid']);
        $this->assertContains('File size exceeds maximum allowed size', $result['errors']);
        
        // Test invalid file type
        $invalidType = [
            'name' => 'test.exe',
            'type' => 'application/octet-stream',
            'tmp_name' => $this->createTempFile('content'),
            'error' => UPLOAD_ERR_OK,
            'size' => 1024
        ];
        
        $result = Security::validateFileUpload($invalidType, ['jpg', 'png']);
        $this->assertFalse($result['valid']);
        $this->assertContains('File type not allowed', $result['errors']);
        
        // Test upload error
        $errorFile = [
            'name' => 'test.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => '',
            'error' => UPLOAD_ERR_CANT_WRITE,
            'size' => 1024
        ];
        
        $result = Security::validateFileUpload($errorFile);
        $this->assertFalse($result['valid']);
        $this->assertNotEmpty($result['errors']);
    }

    /**
     * Test hash function
     */
    public function testHash(): void
    {
        $data = 'sensitive data';
        
        // Test default algorithm (sha256)
        $hash1 = Security::hash($data);
        $hash2 = Security::hash($data);
        $this->assertEquals($hash1, $hash2);
        $this->assertEquals(64, strlen($hash1)); // SHA256 hex length
        
        // Test different algorithm
        $md5Hash = Security::hash($data, 'md5');
        $this->assertEquals(32, strlen($md5Hash)); // MD5 hex length
        $this->assertNotEquals($hash1, $md5Hash);
        
        // Test different data
        $differentHash = Security::hash('different data');
        $this->assertNotEquals($hash1, $differentHash);
    }

    /**
     * Test constant-time string comparison
     */
    public function testCompareStrings(): void
    {
        $string1 = 'secret_token_123';
        $string2 = 'secret_token_123';
        $string3 = 'different_token';
        
        $this->assertTrue(Security::compareStrings($string1, $string2));
        $this->assertFalse(Security::compareStrings($string1, $string3));
        $this->assertFalse(Security::compareStrings($string1, ''));
    }

    /**
     * Test rate limiting
     */
    public function testRateLimit(): void
    {
        $key = 'test_rate_limit';
        
        // Initially should be allowed
        $this->assertTrue(Security::checkRateLimit($key, 3, 60));
        $this->assertTrue(Security::checkRateLimit($key, 3, 60));
        $this->assertTrue(Security::checkRateLimit($key, 3, 60));
        
        // Fourth attempt should be blocked
        $this->assertFalse(Security::checkRateLimit($key, 3, 60));
        
        // Test with different key
        $this->assertTrue(Security::checkRateLimit('different_key', 3, 60));
    }

    /**
     * Test XSS removal
     */
    public function testRemoveXss(): void
    {
        // Test script tag removal
        $malicious = '<script>alert("xss")</script>Normal content';
        $cleaned = Security::removeXss($malicious);
        $this->assertStringNotContainsString('<script>', $cleaned);
        $this->assertStringContainsString('Normal content', $cleaned);
        
        // Test iframe removal
        $iframe = '<iframe src="evil.com"></iframe>Safe content';
        $cleaned = Security::removeXss($iframe);
        $this->assertStringNotContainsString('<iframe>', $cleaned);
        $this->assertStringContainsString('Safe content', $cleaned);
        
        // Test javascript: URL removal
        $jsUrl = '<a href="javascript:alert(1)">Link</a>';
        $cleaned = Security::removeXss($jsUrl);
        $this->assertStringNotContainsString('javascript:', $cleaned);
        
        // Test event handler removal
        $eventHandler = '<div onclick="alert(1)">Content</div>';
        $cleaned = Security::removeXss($eventHandler);
        $this->assertStringNotContainsString('onclick=', $cleaned);
        
        // Test null byte removal
        $nullByte = "test\0content";
        $cleaned = Security::removeXss($nullByte);
        $this->assertStringNotContainsString("\0", $cleaned);
        $this->assertEquals('testcontent', $cleaned);
    }

    /**
     * Test sort parameter validation
     */
    public function testValidateSort(): void
    {
        $allowedFields = ['id', 'name', 'created_at'];
        
        // Test valid parameters
        [$sortBy, $sortDir] = Security::validateSort('name', 'asc', $allowedFields);
        $this->assertEquals('name', $sortBy);
        $this->assertEquals('ASC', $sortDir);
        
        // Test invalid sort field
        [$sortBy, $sortDir] = Security::validateSort('invalid_field', 'desc', $allowedFields);
        $this->assertEquals('id', $sortBy); // Should fallback to first allowed field
        $this->assertEquals('DESC', $sortDir);
        
        // Test invalid sort direction
        [$sortBy, $sortDir] = Security::validateSort('name', 'invalid', $allowedFields);
        $this->assertEquals('name', $sortBy);
        $this->assertEquals('ASC', $sortDir); // Should fallback to ASC
        
        // Test case insensitive direction
        [$sortBy, $sortDir] = Security::validateSort('name', 'desc', $allowedFields);
        $this->assertEquals('DESC', $sortDir);
    }

    /**
     * Test secure filename generation
     */
    public function testGenerateSecureFilename(): void
    {
        // Test basic filename
        $filename1 = Security::generateSecureFilename('test.jpg');
        $filename2 = Security::generateSecureFilename('test.jpg');
        
        $this->assertNotEquals($filename1, $filename2);
        $this->assertStringEndsWith('.jpg', $filename1);
        $this->assertStringEndsWith('.jpg', $filename2);
        
        // Test different extensions
        $pngFilename = Security::generateSecureFilename('image.PNG');
        $this->assertStringEndsWith('.png', $pngFilename);
        
        // Test filename without extension
        $noExt = Security::generateSecureFilename('noextension');
        $this->assertStringEndsWith('.', $noExt);
        
        // Test complex original filename
        $complex = Security::generateSecureFilename('My Complex File Name!@#.jpeg');
        $this->assertStringEndsWith('.jpeg', $complex);
        $this->assertStringNotContainsString('My Complex', $complex);
        
        // Verify uniqueness pattern
        $this->assertMatchesRegularExpression('/^[a-f0-9]+_[a-f0-9]+\.[a-z]+$/', $filename1);
    }

    /**
     * Helper method to create temporary file for testing
     */
    private function createTempFile(string $content): string
    {
        $tmpFile = tempnam(sys_get_temp_dir(), 'test_');
        file_put_contents($tmpFile, $content);
        
        // Mark as uploaded file for is_uploaded_file() to work
        // Note: In real tests, you might need to mock this function
        return $tmpFile;
    }

    /**
     * Test security utility edge cases
     */
    public function testSecurityEdgeCases(): void
    {
        // Test empty inputs
        $this->assertEquals('', Security::sanitize(''));
        $this->assertEquals([], Security::sanitizeArray([]));
        $this->assertEquals('', Security::cleanHtml(''));
        $this->assertEquals('', Security::createUrlAlias(''));
        
        // Test very long inputs
        $longString = str_repeat('a', 10000);
        $sanitized = Security::sanitize($longString);
        $this->assertEquals($longString, $sanitized);
        
        // Test unicode characters
        $unicode = 'Héllo Wørld 测试';
        $sanitized = Security::sanitize($unicode);
        $this->assertEquals($unicode, $sanitized);
        
        // Test null and non-string inputs in arrays
        $mixedArray = [
            'string' => 'test',
            'null' => null,
            'boolean' => true,
            'number' => 123,
            'array' => ['nested' => 'value']
        ];
        
        $sanitized = Security::sanitizeArray($mixedArray);
        $this->assertEquals('test', $sanitized['string']);
        $this->assertNull($sanitized['null']);
        $this->assertTrue($sanitized['boolean']);
        $this->assertEquals(123, $sanitized['number']);
        $this->assertEquals('value', $sanitized['array']['nested']);
    }

    /**
     * Test security function performance with large inputs
     */
    public function testSecurityPerformance(): void
    {
        $largeString = str_repeat('<script>alert("xss")</script>', 1000);
        
        $startTime = microtime(true);
        $sanitized = Security::sanitize($largeString);
        $sanitizeTime = microtime(true) - $startTime;
        
        $startTime = microtime(true);
        $cleaned = Security::cleanHtml($largeString);
        $cleanTime = microtime(true) - $startTime;
        
        $startTime = microtime(true);
        $xssRemoved = Security::removeXss($largeString);
        $xssTime = microtime(true) - $startTime;
        
        // Performance should be reasonable (less than 1 second for large input)
        $this->assertLessThan(1.0, $sanitizeTime);
        $this->assertLessThan(1.0, $cleanTime);
        $this->assertLessThan(1.0, $xssTime);
        
        // Verify functions still work correctly
        $this->assertStringNotContainsString('<script>', $sanitized);
        $this->assertStringNotContainsString('<script>', $cleaned);
        $this->assertStringNotContainsString('<script>', $xssRemoved);
    }
}