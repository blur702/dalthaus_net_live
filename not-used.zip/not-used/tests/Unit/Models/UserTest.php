<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use Tests\Support\DatabaseTestCase;
use CMS\Models\User;
use InvalidArgumentException;
use ReflectionClass;

/**
 * User Model Test
 * 
 * Tests for the User model including authentication, validation,
 * CRUD operations, and security features.
 */
class UserTest extends DatabaseTestCase
{
    protected User $userModel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->userModel = new User();
        
        // Set the database instance for the model
        $reflection = new ReflectionClass($this->userModel);
        $dbProperty = $reflection->getProperty('db');
        $dbProperty->setAccessible(true);
        $dbProperty->setValue($this->userModel, $this->db);
    }

    /**
     * Test finding user by username
     */
    public function testFindByUsername(): void
    {
        // Create test user
        $testUser = $this->createTestUser([
            'username' => 'testfinduser',
            'email' => 'testfind@example.com'
        ]);

        // Test finding existing user
        $foundUser = User::findByUsername('testfinduser');
        $this->assertNotNull($foundUser);
        $this->assertEquals('testfinduser', $foundUser->getAttribute('username'));
        $this->assertEquals('testfind@example.com', $foundUser->getAttribute('email'));

        // Test finding non-existing user
        $notFound = User::findByUsername('nonexistentuser');
        $this->assertNull($notFound);
    }

    /**
     * Test finding user by email
     */
    public function testFindByEmail(): void
    {
        // Create test user
        $testUser = $this->createTestUser([
            'username' => 'testfindemail',
            'email' => 'testfindemail@example.com'
        ]);

        // Test finding existing user by email
        $foundUser = User::findByEmail('testfindemail@example.com');
        $this->assertNotNull($foundUser);
        $this->assertEquals('testfindemail', $foundUser->getAttribute('username'));
        $this->assertEquals('testfindemail@example.com', $foundUser->getAttribute('email'));

        // Test finding non-existing user by email
        $notFound = User::findByEmail('nonexistent@example.com');
        $this->assertNull($notFound);
    }

    /**
     * Test creating user with password hashing
     */
    public function testCreateUser(): void
    {
        $userData = [
            'username' => 'newuser',
            'email' => 'newuser@example.com',
            'password' => 'securepassword123'
        ];

        $user = User::createUser($userData);
        
        // Assert user was created
        $this->assertInstanceOf(User::class, $user);
        $this->assertEquals('newuser', $user->getAttribute('username'));
        $this->assertEquals('newuser@example.com', $user->getAttribute('email'));
        
        // Assert password was hashed and stored correctly
        $this->assertNotEquals('securepassword123', $user->getAttribute('password_hash'));
        $this->assertTrue(password_verify('securepassword123', $user->getAttribute('password_hash')));
        
        // Assert created_at timestamp was set
        $this->assertNotNull($user->getAttribute('created_at'));
        $this->assertIsRecentTimestamp($user->getAttribute('created_at'));
    }

    /**
     * Test creating user without password throws exception
     */
    public function testCreateUserWithoutPasswordThrowsException(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Password is required');
        
        User::createUser([
            'username' => 'usernopass',
            'email' => 'usernopass@example.com'
        ]);
    }

    /**
     * Test password verification
     */
    public function testVerifyPassword(): void
    {
        $user = User::createUser([
            'username' => 'passuser',
            'email' => 'passuser@example.com',
            'password' => 'mypassword123'
        ]);

        // Test correct password
        $this->assertTrue($user->verifyPassword('mypassword123'));
        
        // Test incorrect password
        $this->assertFalse($user->verifyPassword('wrongpassword'));
        
        // Test empty password
        $this->assertFalse($user->verifyPassword(''));
    }

    /**
     * Test updating user password
     */
    public function testUpdatePassword(): void
    {
        $user = User::createUser([
            'username' => 'updatepassuser',
            'email' => 'updatepass@example.com',
            'password' => 'oldpassword'
        ]);

        $oldHash = $user->getAttribute('password_hash');
        
        // Update password
        $result = $user->updatePassword('newpassword123');
        $this->assertTrue($result);
        
        // Verify new password works
        $this->assertTrue($user->verifyPassword('newpassword123'));
        $this->assertFalse($user->verifyPassword('oldpassword'));
        
        // Verify hash changed
        $this->assertNotEquals($oldHash, $user->getAttribute('password_hash'));
    }

    /**
     * Test username availability checking
     */
    public function testIsUsernameAvailable(): void
    {
        // Create test user
        $this->createTestUser([
            'username' => 'takenuser',
            'email' => 'taken@example.com'
        ]);

        // Test taken username
        $this->assertFalse(User::isUsernameAvailable('takenuser'));
        
        // Test available username
        $this->assertTrue(User::isUsernameAvailable('availableuser'));
        
        // Test excluding user ID (for updates)
        $user = User::findByUsername('takenuser');
        $this->assertTrue(User::isUsernameAvailable('takenuser', $user->getAttribute('user_id')));
    }

    /**
     * Test email availability checking
     */
    public function testIsEmailAvailable(): void
    {
        // Create test user
        $this->createTestUser([
            'username' => 'emailuser',
            'email' => 'taken@example.com'
        ]);

        // Test taken email
        $this->assertFalse(User::isEmailAvailable('taken@example.com'));
        
        // Test available email
        $this->assertTrue(User::isEmailAvailable('available@example.com'));
        
        // Test excluding user ID (for updates)
        $user = User::findByEmail('taken@example.com');
        $this->assertTrue(User::isEmailAvailable('taken@example.com', $user->getAttribute('user_id')));
    }

    /**
     * Test getting user content count
     */
    public function testGetContentCount(): void
    {
        // Create user and content
        $testUser = $this->createTestUser([
            'username' => 'contentuser',
            'email' => 'contentuser@example.com'
        ]);
        
        $userId = $testUser['user_id'];
        $user = User::find($userId);
        
        // Initially should have 2 content items from seed data
        $this->assertEquals(2, $user->getContentCount());
        
        // Test filtering by content type
        $this->assertEquals(1, $user->getContentCount('article'));
        $this->assertEquals(1, $user->getContentCount('photobook'));
        
        // Test filtering by status
        $this->assertEquals(2, $user->getContentCount(null, 'published'));
        $this->assertEquals(0, $user->getContentCount(null, 'draft'));
    }

    /**
     * Test getting user recent content
     */
    public function testGetRecentContent(): void
    {
        $testUser = $this->createTestUser([
            'username' => 'recentuser',
            'email' => 'recent@example.com'
        ]);
        
        $userId = $testUser['user_id'];
        $user = User::find($userId);
        
        $recentContent = $user->getRecentContent(5);
        
        // Should return content with required fields
        $this->assertCount(2, $recentContent); // From seed data
        
        foreach ($recentContent as $content) {
            $this->assertArrayHasKeys([
                'content_id', 'title', 'content_type', 'status', 'updated_at'
            ], $content);
        }
    }

    /**
     * Test getting users for admin with filters
     */
    public function testGetForAdmin(): void
    {
        // Create additional test users
        $this->createTestUser([
            'username' => 'admin1',
            'email' => 'admin1@example.com'
        ]);
        
        $this->createTestUser([
            'username' => 'admin2',
            'email' => 'admin2@example.com'
        ]);

        // Test getting all users
        $allUsers = User::getForAdmin();
        $this->assertCount(3, $allUsers); // Including original test user
        
        // Test search filter
        $filteredUsers = User::getForAdmin(['search' => 'admin1']);
        $this->assertCount(1, $filteredUsers);
        $this->assertEquals('admin1', $filteredUsers[0]->getAttribute('username'));
        
        // Test pagination
        $paginatedUsers = User::getForAdmin([], 1, 0);
        $this->assertCount(1, $paginatedUsers);
    }

    /**
     * Test counting users for admin
     */
    public function testCountForAdmin(): void
    {
        // Initial count (includes seed user)
        $initialCount = User::countForAdmin();
        $this->assertEquals(1, $initialCount);
        
        // Add more users
        $this->createTestUser(['username' => 'count1', 'email' => 'count1@test.com']);
        $this->createTestUser(['username' => 'count2', 'email' => 'count2@test.com']);
        
        $newCount = User::countForAdmin();
        $this->assertEquals(3, $newCount);
        
        // Test with search filter
        $searchCount = User::countForAdmin(['search' => 'count1']);
        $this->assertEquals(1, $searchCount);
    }

    /**
     * Test user data validation
     */
    public function testValidateUserData(): void
    {
        // Test valid data
        $validData = [
            'username' => 'validuser',
            'email' => 'valid@example.com',
            'password' => 'validpassword'
        ];
        $errors = User::validateUserData($validData);
        $this->assertEmpty($errors);
        
        // Test invalid username (too short)
        $invalidData = [
            'username' => 'ab',
            'email' => 'valid@example.com',
            'password' => 'validpassword'
        ];
        $errors = User::validateUserData($invalidData);
        $this->assertArrayHasKey('username', $errors);
        
        // Test invalid email
        $invalidData = [
            'username' => 'validuser',
            'email' => 'invalid-email',
            'password' => 'validpassword'
        ];
        $errors = User::validateUserData($invalidData);
        $this->assertArrayHasKey('email', $errors);
        
        // Test invalid password (too short)
        $invalidData = [
            'username' => 'validuser',
            'email' => 'valid@example.com',
            'password' => '123'
        ];
        $errors = User::validateUserData($invalidData);
        $this->assertArrayHasKey('password', $errors);
        
        // Test duplicate username
        $this->createTestUser(['username' => 'duplicate', 'email' => 'dup@test.com']);
        $duplicateData = [
            'username' => 'duplicate',
            'email' => 'different@example.com',
            'password' => 'validpassword'
        ];
        $errors = User::validateUserData($duplicateData);
        $this->assertArrayHasKey('username', $errors);
    }

    /**
     * Test getting safe user data (without password hash)
     */
    public function testGetSafeData(): void
    {
        $user = User::createUser([
            'username' => 'safeuser',
            'email' => 'safe@example.com',
            'password' => 'password123'
        ]);
        
        $safeData = $user->getSafeData();
        
        // Should include safe fields
        $this->assertArrayHasKey('username', $safeData);
        $this->assertArrayHasKey('email', $safeData);
        $this->assertArrayHasKey('created_at', $safeData);
        
        // Should not include password hash
        $this->assertArrayNotHasKey('password_hash', $safeData);
    }

    /**
     * Test utility methods
     */
    public function testUtilityMethods(): void
    {
        $user = User::createUser([
            'username' => 'utiluser',
            'email' => 'util@example.com',
            'password' => 'password123'
        ]);
        
        // Test getDisplayName
        $this->assertEquals('utiluser', $user->getDisplayName());
        
        // Test getFormattedCreatedDate
        $formattedDate = $user->getFormattedCreatedDate();
        $this->assertNotEmpty($formattedDate);
        $this->assertIsString($formattedDate);
        
        // Test hasContent (should be false for new user)
        $this->assertFalse($user->hasContent());
    }

    /**
     * Test model inheritance from BaseModel
     */
    public function testBaseModelInheritance(): void
    {
        $user = new User();
        
        // Test table name
        $this->assertEquals('users', $this->getProtectedProperty($user, 'table'));
        
        // Test primary key
        $this->assertEquals('user_id', $this->getProtectedProperty($user, 'primaryKey'));
        
        // Test attribute methods
        $user->setAttribute('test_field', 'test_value');
        $this->assertEquals('test_value', $user->getAttribute('test_field'));
    }

    /**
     * Test user creation and deletion workflow
     */
    public function testUserLifecycle(): void
    {
        // Create user
        $user = User::createUser([
            'username' => 'lifecycle',
            'email' => 'lifecycle@example.com',
            'password' => 'password123'
        ]);
        
        $userId = $user->getAttribute('user_id');
        $this->assertNotNull($userId);
        
        // Verify user exists in database
        $this->assertDatabaseHas('users', [
            'user_id' => $userId,
            'username' => 'lifecycle'
        ]);
        
        // Update user
        $user->setAttribute('email', 'updated@example.com');
        $result = $user->save();
        $this->assertTrue($result);
        
        // Verify update
        $updatedUser = User::find($userId);
        $this->assertEquals('updated@example.com', $updatedUser->getAttribute('email'));
        
        // Delete user
        $deleted = $user->delete();
        $this->assertTrue($deleted);
        
        // Verify deletion
        $this->assertDatabaseMissing('users', ['user_id' => $userId]);
    }
}