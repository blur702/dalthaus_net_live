<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use Tests\Support\DatabaseTestCase;
use CMS\Models\Content;
use ReflectionClass;

/**
 * Content Model Test
 * 
 * Tests for the Content model including CRUD operations,
 * content filtering, relationships, and utility methods.
 */
class ContentTest extends DatabaseTestCase
{
    protected Content $contentModel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->contentModel = new Content();
        
        // Set the database instance for the model
        $reflection = new ReflectionClass($this->contentModel);
        $dbProperty = $reflection->getProperty('db');
        $dbProperty->setAccessible(true);
        $dbProperty->setValue($this->contentModel, $this->db);
    }

    /**
     * Test content type constants
     */
    public function testContentTypeConstants(): void
    {
        $this->assertEquals('article', Content::TYPE_ARTICLE);
        $this->assertEquals('photobook', Content::TYPE_PHOTOBOOK);
    }

    /**
     * Test content status constants
     */
    public function testContentStatusConstants(): void
    {
        $this->assertEquals('draft', Content::STATUS_DRAFT);
        $this->assertEquals('published', Content::STATUS_PUBLISHED);
    }

    /**
     * Test getting published articles
     */
    public function testGetPublishedArticles(): void
    {
        // Get published articles
        $articles = Content::getPublishedArticles();
        
        $this->assertNotEmpty($articles);
        
        foreach ($articles as $article) {
            $this->assertEquals(Content::TYPE_ARTICLE, $article->getAttribute('content_type'));
            $this->assertEquals(Content::STATUS_PUBLISHED, $article->getAttribute('status'));
            $this->assertArrayHasKey('username', $article->toArray());
        }
    }

    /**
     * Test getting published articles with pagination
     */
    public function testGetPublishedArticlesWithPagination(): void
    {
        // Create additional articles
        $testUser = $this->createTestUser(['username' => 'articleuser', 'email' => 'article@test.com']);
        
        for ($i = 1; $i <= 5; $i++) {
            $this->db->insert('content', [
                'title' => "Article {$i}",
                'content_type' => Content::TYPE_ARTICLE,
                'status' => Content::STATUS_PUBLISHED,
                'user_id' => $testUser['user_id'],
                'sort_order' => $i,
                'published_at' => date('Y-m-d H:i:s')
            ]);
        }
        
        // Test with limit
        $limitedArticles = Content::getPublishedArticles(3);
        $this->assertCount(3, $limitedArticles);
        
        // Test with limit and offset
        $offsetArticles = Content::getPublishedArticles(2, 1);
        $this->assertCount(2, $offsetArticles);
    }

    /**
     * Test getting published photobooks
     */
    public function testGetPublishedPhotobooks(): void
    {
        $photobooks = Content::getPublishedPhotobooks();
        
        $this->assertNotEmpty($photobooks);
        
        foreach ($photobooks as $photobook) {
            $this->assertEquals(Content::TYPE_PHOTOBOOK, $photobook->getAttribute('content_type'));
            $this->assertEquals(Content::STATUS_PUBLISHED, $photobook->getAttribute('status'));
            $this->assertArrayHasKey('username', $photobook->toArray());
        }
    }

    /**
     * Test finding content by URL alias
     */
    public function testFindByAlias(): void
    {
        // Test finding existing content
        $content = Content::findByAlias('test-article');
        $this->assertNotNull($content);
        $this->assertEquals('test-article', $content->getAttribute('url_alias'));
        $this->assertEquals(Content::STATUS_PUBLISHED, $content->getAttribute('status'));
        
        // Test finding non-existing content
        $notFound = Content::findByAlias('non-existing-alias');
        $this->assertNull($notFound);
    }

    /**
     * Test getting content for admin interface
     */
    public function testGetForAdmin(): void
    {
        // Test getting all content
        $allContent = Content::getForAdmin();
        $this->assertCount(2, $allContent); // From seed data
        
        // Test filtering by content type
        $articles = Content::getForAdmin(['type' => Content::TYPE_ARTICLE]);
        $this->assertCount(1, $articles);
        $this->assertEquals(Content::TYPE_ARTICLE, $articles[0]->getAttribute('content_type'));
        
        // Test filtering by status
        $published = Content::getForAdmin(['status' => Content::STATUS_PUBLISHED]);
        $this->assertCount(2, $published);
        
        // Test search filter
        $searched = Content::getForAdmin(['search' => 'Test Article']);
        $this->assertCount(1, $searched);
        $this->assertStringContainsString('Test Article', $searched[0]->getAttribute('title'));
    }

    /**
     * Test counting content for admin with filters
     */
    public function testCountForAdmin(): void
    {
        // Test total count
        $totalCount = Content::countForAdmin();
        $this->assertEquals(2, $totalCount);
        
        // Test count with type filter
        $articleCount = Content::countForAdmin(['type' => Content::TYPE_ARTICLE]);
        $this->assertEquals(1, $articleCount);
        
        // Test count with status filter
        $publishedCount = Content::countForAdmin(['status' => Content::STATUS_PUBLISHED]);
        $this->assertEquals(2, $publishedCount);
        
        $draftCount = Content::countForAdmin(['status' => Content::STATUS_DRAFT]);
        $this->assertEquals(0, $draftCount);
    }

    /**
     * Test getting content for reordering
     */
    public function testGetForReordering(): void
    {
        // Test getting all content for reordering
        $allContent = Content::getForReordering();
        $this->assertCount(2, $allContent);
        
        foreach ($allContent as $item) {
            $this->assertArrayHasKeys(['content_id', 'title', 'content_type', 'sort_order'], $item);
        }
        
        // Test filtering by content type
        $articles = Content::getForReordering(Content::TYPE_ARTICLE);
        $this->assertCount(1, $articles);
        $this->assertEquals(Content::TYPE_ARTICLE, $articles[0]['content_type']);
    }

    /**
     * Test updating sort order
     */
    public function testUpdateSortOrder(): void
    {
        // Get existing content IDs
        $content = Content::getForReordering();
        $this->assertCount(2, $content);
        
        $orderData = [
            $content[0]['content_id'] => 10,
            $content[1]['content_id'] => 5
        ];
        
        // Update sort order
        $result = Content::updateSortOrder($orderData);
        $this->assertTrue($result);
        
        // Verify updated sort orders
        $updatedContent = Content::getForReordering();
        $sortOrders = array_column($updatedContent, 'sort_order');
        
        $this->assertContains(10, $sortOrders);
        $this->assertContains(5, $sortOrders);
    }

    /**
     * Test getting next sort order
     */
    public function testGetNextSortOrder(): void
    {
        $nextOrder = Content::getNextSortOrder();
        
        // Should be greater than existing sort orders
        $this->assertGreaterThan(2, $nextOrder); // Our test data has sort_order 1 and 2
        $this->assertEquals(3, $nextOrder);
    }

    /**
     * Test splitting content into pages
     */
    public function testGetContentPages(): void
    {
        // Create content with pagebreak
        $contentWithPagebreak = $this->fakeContentData([
            'body' => 'Page 1 content<hr class="mce-pagebreak" />Page 2 content<hr class="mce-pagebreak" />Page 3 content'
        ]);
        
        $content = Content::create($contentWithPagebreak);
        $pages = $content->getContentPages();
        
        $this->assertCount(3, $pages);
        $this->assertEquals('Page 1 content', trim($pages[0]));
        $this->assertEquals('Page 2 content', trim($pages[1]));
        $this->assertEquals('Page 3 content', trim($pages[2]));
        
        // Test content without pagebreaks
        $contentWithoutPagebreak = $this->fakeContentData([
            'body' => 'Single page content'
        ]);
        
        $singlePageContent = Content::create($contentWithoutPagebreak);
        $singlePage = $singlePageContent->getContentPages();
        
        $this->assertCount(1, $singlePage);
        $this->assertEquals('Single page content', trim($singlePage[0]));
    }

    /**
     * Test getting content author
     */
    public function testGetAuthor(): void
    {
        $testUser = $this->createTestUser(['username' => 'author', 'email' => 'author@test.com']);
        
        $contentData = $this->fakeContentData(['user_id' => $testUser['user_id']]);
        $content = Content::create($contentData);
        
        $author = $content->getAuthor();
        
        $this->assertNotNull($author);
        $this->assertArrayHasKeys(['user_id', 'username', 'email'], $author);
        $this->assertEquals('author', $author['username']);
        $this->assertEquals('author@test.com', $author['email']);
        
        // Test content without author
        $orphanContent = Content::create($this->fakeContentData(['user_id' => null]));
        $noAuthor = $orphanContent->getAuthor();
        $this->assertNull($noAuthor);
    }

    /**
     * Test content status checking methods
     */
    public function testStatusCheckingMethods(): void
    {
        // Test published content
        $publishedContent = Content::create($this->fakeContentData([
            'status' => Content::STATUS_PUBLISHED
        ]));
        
        $this->assertTrue($publishedContent->isPublished());
        $this->assertFalse($publishedContent->isDraft());
        
        // Test draft content
        $draftContent = Content::create($this->fakeContentData([
            'status' => Content::STATUS_DRAFT
        ]));
        
        $this->assertFalse($draftContent->isPublished());
        $this->assertTrue($draftContent->isDraft());
    }

    /**
     * Test content type checking methods
     */
    public function testTypeCheckingMethods(): void
    {
        // Test article content
        $article = Content::create($this->fakeContentData([
            'content_type' => Content::TYPE_ARTICLE
        ]));
        
        $this->assertTrue($article->isArticle());
        $this->assertFalse($article->isPhotobook());
        
        // Test photobook content
        $photobook = Content::create($this->fakeContentData([
            'content_type' => Content::TYPE_PHOTOBOOK
        ]));
        
        $this->assertFalse($photobook->isArticle());
        $this->assertTrue($photobook->isPhotobook());
    }

    /**
     * Test date formatting methods
     */
    public function testDateFormattingMethods(): void
    {
        $now = date('Y-m-d H:i:s');
        $content = Content::create($this->fakeContentData([
            'created_at' => $now,
            'published_at' => $now
        ]));
        
        // Test formatted created date
        $formattedCreated = $content->getFormattedCreatedDate();
        $this->assertNotEmpty($formattedCreated);
        $this->assertIsString($formattedCreated);
        
        // Test formatted published date
        $formattedPublished = $content->getFormattedPublishedDate();
        $this->assertNotEmpty($formattedPublished);
        $this->assertIsString($formattedPublished);
        
        // Test custom format
        $customFormat = $content->getFormattedCreatedDate('Y-m-d');
        $this->assertEquals(date('Y-m-d'), $customFormat);
    }

    /**
     * Test image URL methods
     */
    public function testImageUrlMethods(): void
    {
        $content = Content::create($this->fakeContentData([
            'teaser_image' => 'teaser.jpg',
            'featured_image' => 'featured.jpg'
        ]));
        
        // Test teaser image URL
        $teaserUrl = $content->getTeaserImageUrl();
        $this->assertEquals('/uploads/teaser.jpg', $teaserUrl);
        
        // Test featured image URL
        $featuredUrl = $content->getFeaturedImageUrl();
        $this->assertEquals('/uploads/featured.jpg', $featuredUrl);
        
        // Test empty images
        $emptyContent = Content::create($this->fakeContentData([
            'teaser_image' => null,
            'featured_image' => null
        ]));
        
        $this->assertEquals('', $emptyContent->getTeaserImageUrl());
        $this->assertEquals('', $emptyContent->getFeaturedImageUrl());
    }

    /**
     * Test content URL generation
     */
    public function testGetUrl(): void
    {
        // Test article URL
        $article = Content::create($this->fakeContentData([
            'content_type' => Content::TYPE_ARTICLE,
            'url_alias' => 'my-article'
        ]));
        
        $this->assertEquals('/article/my-article', $article->getUrl());
        
        // Test photobook URL
        $photobook = Content::create($this->fakeContentData([
            'content_type' => Content::TYPE_PHOTOBOOK,
            'url_alias' => 'my-photobook'
        ]));
        
        $this->assertEquals('/photobook/my-photobook', $photobook->getUrl());
        
        // Test content without alias
        $noAlias = Content::create($this->fakeContentData([
            'url_alias' => null
        ]));
        
        $this->assertEquals('#', $noAlias->getUrl());
    }

    /**
     * Test model inheritance from BaseModel
     */
    public function testBaseModelInheritance(): void
    {
        $content = new Content();
        
        // Test table name
        $this->assertEquals('content', $this->getProtectedProperty($content, 'table'));
        
        // Test primary key
        $this->assertEquals('content_id', $this->getProtectedProperty($content, 'primaryKey'));
        
        // Test attribute methods
        $content->setAttribute('test_field', 'test_value');
        $this->assertEquals('test_value', $content->getAttribute('test_field'));
    }

    /**
     * Test content lifecycle (create, update, delete)
     */
    public function testContentLifecycle(): void
    {
        // Create content
        $contentData = $this->fakeContentData([
            'title' => 'Lifecycle Test',
            'status' => Content::STATUS_DRAFT
        ]);
        
        $content = Content::create($contentData);
        $contentId = $content->getAttribute('content_id');
        
        $this->assertNotNull($contentId);
        $this->assertDatabaseHas('content', [
            'content_id' => $contentId,
            'title' => 'Lifecycle Test'
        ]);
        
        // Update content
        $content->setAttribute('title', 'Updated Lifecycle Test');
        $content->setAttribute('status', Content::STATUS_PUBLISHED);
        $result = $content->save();
        
        $this->assertTrue($result);
        
        $updatedContent = Content::find($contentId);
        $this->assertEquals('Updated Lifecycle Test', $updatedContent->getAttribute('title'));
        $this->assertEquals(Content::STATUS_PUBLISHED, $updatedContent->getAttribute('status'));
        
        // Delete content
        $deleted = $content->delete();
        $this->assertTrue($deleted);
        
        $this->assertDatabaseMissing('content', ['content_id' => $contentId]);
    }

    /**
     * Test content filtering and sorting
     */
    public function testContentFilteringAndSorting(): void
    {
        // Create test content with different attributes
        $testUser = $this->createTestUser(['username' => 'filteruser', 'email' => 'filter@test.com']);
        
        $contents = [
            $this->fakeContentData([
                'title' => 'Alpha Article',
                'content_type' => Content::TYPE_ARTICLE,
                'status' => Content::STATUS_PUBLISHED,
                'user_id' => $testUser['user_id'],
                'sort_order' => 3
            ]),
            $this->fakeContentData([
                'title' => 'Beta Photobook',
                'content_type' => Content::TYPE_PHOTOBOOK,
                'status' => Content::STATUS_DRAFT,
                'user_id' => $testUser['user_id'],
                'sort_order' => 1
            ]),
            $this->fakeContentData([
                'title' => 'Gamma Article',
                'content_type' => Content::TYPE_ARTICLE,
                'status' => Content::STATUS_PUBLISHED,
                'user_id' => $testUser['user_id'],
                'sort_order' => 2
            ])
        ];
        
        foreach ($contents as $contentData) {
            Content::create($contentData);
        }
        
        // Test filtering by type and status
        $publishedArticles = Content::getForAdmin([
            'type' => Content::TYPE_ARTICLE,
            'status' => Content::STATUS_PUBLISHED
        ]);
        $this->assertCount(2, $publishedArticles); // Alpha and Gamma
        
        // Test sorting
        $sortedContent = Content::getForAdmin([
            'sort_by' => 'title',
            'sort_dir' => 'ASC'
        ]);
        
        // Should be sorted alphabetically
        $titles = array_map(fn($c) => $c->getAttribute('title'), $sortedContent);
        $this->assertTrue($titles[0] < $titles[1]); // Check if sorted
    }
}