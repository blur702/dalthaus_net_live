<?php

declare(strict_types=1);

/**
 * Test Configuration File
 * 
 * Configuration settings specifically for the testing environment.
 * Overrides production settings with test-specific values.
 */

return [
    /**
     * Database Configuration (SQLite in-memory for tests)
     */
    'database' => [
        'driver' => 'sqlite',
        'database' => ':memory:',
        'prefix' => '',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    ],

    /**
     * Application Configuration for Tests
     */
    'app' => [
        'name' => 'CMS Test Suite',
        'version' => '1.0.0',
        'timezone' => 'UTC',
        'debug' => true,
        'base_url' => 'http://test.local',
        'upload_path' => TEST_ROOT . '/uploads/',
        'max_upload_size' => 1048576, // 1MB for tests
        'allowed_image_types' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
        'items_per_page' => 5 // Smaller page size for tests
    ],

    /**
     * Security Configuration for Tests
     */
    'security' => [
        'session_name' => 'test_cms_session',
        'session_lifetime' => 3600,
        'csrf_token_name' => '_test_token',
        'password_min_length' => 6, // Shorter for tests
        'login_max_attempts' => 3,
        'login_lockout_time' => 60, // 1 minute for tests
        'secure_cookies' => false,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Strict'
    ],

    /**
     * View Configuration for Tests
     */
    'views' => [
        'cache_enabled' => false,
        'cache_path' => TEST_ROOT . '/cache/views/',
        'default_layout' => 'default',
        'admin_layout' => 'admin'
    ],

    /**
     * Cache Configuration for Tests
     */
    'cache' => [
        'enabled' => false,
        'default_ttl' => 60,
        'path' => TEST_ROOT . '/cache/',
        'file_extension' => '.test.cache'
    ],

    /**
     * Error Handling for Tests
     */
    'errors' => [
        'display_errors' => true,
        'log_errors' => false,
        'error_log_path' => TEST_ROOT . '/logs/test_error.log',
        'exception_handler' => false
    ],

    /**
     * Test-specific Configuration
     */
    'testing' => [
        'fixtures_path' => TEST_ROOT . '/Fixtures',
        'temp_path' => TEST_ROOT . '/temp',
        'fake_upload_path' => TEST_ROOT . '/uploads',
        'database_schema' => TEST_ROOT . '/Support/test_schema.sql'
    ]
];