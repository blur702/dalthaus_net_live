<?php

declare(strict_types=1);

namespace Tests\Support;

use CMS\Utils\Database;
use PDO;

/**
 * Database Test Case
 * 
 * Base class for tests that require database operations.
 * Sets up an in-memory SQLite database with the required schema.
 */
abstract class DatabaseTestCase extends TestCase
{
    /**
     * Database instance for tests
     */
    protected Database $db;

    /**
     * Database configuration for tests
     */
    protected array $dbConfig;

    /**
     * Set up database test case
     */
    protected function setUp(): void
    {
        parent::setUp();
        
        // Configure SQLite in-memory database
        $this->dbConfig = [
            'host' => ':memory:',
            'dbname' => ':memory:',
            'username' => '',
            'password' => '',
            'charset' => 'utf8',
            'options' => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        ];
        
        // Create database instance
        $this->db = Database::getInstance($this->dbConfig);
        
        // Set up test database schema
        $this->setUpDatabase();
        
        // Seed initial test data
        $this->seedTestData();
    }

    /**
     * Clean up database after test
     */
    protected function tearDown(): void
    {
        // Drop all tables to clean up
        $this->tearDownDatabase();
        
        parent::tearDown();
    }

    /**
     * Set up database schema for testing
     */
    protected function setUpDatabase(): void
    {
        // Create users table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Create content table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS content (
                content_id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(255) NOT NULL,
                teaser TEXT,
                body TEXT,
                content_type VARCHAR(50) NOT NULL DEFAULT 'article',
                status VARCHAR(20) NOT NULL DEFAULT 'draft',
                url_alias VARCHAR(255) UNIQUE,
                sort_order INTEGER DEFAULT 0,
                teaser_image VARCHAR(255),
                featured_image VARCHAR(255),
                user_id INTEGER,
                published_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ");

        // Create pages table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS pages (
                page_id INTEGER PRIMARY KEY AUTOINCREMENT,
                title VARCHAR(255) NOT NULL,
                slug VARCHAR(255) UNIQUE NOT NULL,
                content TEXT,
                meta_title VARCHAR(255),
                meta_description TEXT,
                is_published BOOLEAN DEFAULT 0,
                sort_order INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Create settings table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS settings (
                setting_id INTEGER PRIMARY KEY AUTOINCREMENT,
                setting_key VARCHAR(255) UNIQUE NOT NULL,
                setting_value TEXT,
                setting_type VARCHAR(50) DEFAULT 'string',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Create menus table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS menus (
                menu_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                location VARCHAR(50) NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Create menu_items table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS menu_items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                menu_id INTEGER NOT NULL,
                title VARCHAR(255) NOT NULL,
                url VARCHAR(255),
                parent_id INTEGER DEFAULT NULL,
                sort_order INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (menu_id) REFERENCES menus(menu_id),
                FOREIGN KEY (parent_id) REFERENCES menu_items(item_id)
            )
        ");

        // Create indexes for better performance
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_content_type_status ON content(content_type, status)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_content_url_alias ON content(url_alias)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_content_user_id ON content(user_id)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_pages_slug ON pages(slug)");
        $this->db->query("CREATE INDEX IF NOT EXISTS idx_settings_key ON settings(setting_key)");
    }

    /**
     * Seed initial test data
     */
    protected function seedTestData(): void
    {
        // Create test user
        $testUser = $this->createTestUser();
        
        // Create test content
        $this->createTestContent($testUser['user_id']);
        
        // Create test settings
        $this->createTestSettings();
    }

    /**
     * Create a test user
     * 
     * @param array $overrides Override specific fields
     * @return array Created user data
     */
    protected function createTestUser(array $overrides = []): array
    {
        $userData = array_merge([
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password_hash' => password_hash('testpassword', PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s')
        ], $overrides);

        $userId = $this->db->insert('users', $userData);
        $userData['user_id'] = (int) $userId;
        
        return $userData;
    }

    /**
     * Create test content
     * 
     * @param int $userId User ID
     * @return array Created content records
     */
    protected function createTestContent(int $userId): array
    {
        $content = [];
        
        // Create test article
        $articleData = [
            'title' => 'Test Article',
            'teaser' => 'This is a test article teaser.',
            'body' => 'This is the full test article body content.',
            'content_type' => 'article',
            'status' => 'published',
            'url_alias' => 'test-article',
            'sort_order' => 1,
            'user_id' => $userId,
            'published_at' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $articleId = $this->db->insert('content', $articleData);
        $articleData['content_id'] = (int) $articleId;
        $content[] = $articleData;
        
        // Create test photobook
        $photobookData = [
            'title' => 'Test Photobook',
            'teaser' => 'This is a test photobook teaser.',
            'body' => 'This is the test photobook content.',
            'content_type' => 'photobook',
            'status' => 'published',
            'url_alias' => 'test-photobook',
            'sort_order' => 2,
            'user_id' => $userId,
            'published_at' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $photobookId = $this->db->insert('content', $photobookData);
        $photobookData['content_id'] = (int) $photobookId;
        $content[] = $photobookData;
        
        return $content;
    }

    /**
     * Create test settings
     */
    protected function createTestSettings(): void
    {
        $settings = [
            ['setting_key' => 'site_name', 'setting_value' => 'Test CMS Site'],
            ['setting_key' => 'site_description', 'setting_value' => 'A test CMS site'],
            ['setting_key' => 'items_per_page', 'setting_value' => '10', 'setting_type' => 'integer'],
            ['setting_key' => 'maintenance_mode', 'setting_value' => '0', 'setting_type' => 'boolean']
        ];

        foreach ($settings as $setting) {
            $this->db->insert('settings', $setting);
        }
    }

    /**
     * Clean up database tables
     */
    protected function tearDownDatabase(): void
    {
        // Drop tables in reverse order due to foreign keys
        $tables = [
            'menu_items',
            'menus',
            'settings',
            'pages',
            'content',
            'users'
        ];

        foreach ($tables as $table) {
            try {
                $this->db->query("DROP TABLE IF EXISTS {$table}");
            } catch (\Exception $e) {
                // Ignore errors during cleanup
            }
        }
    }

    /**
     * Begin database transaction
     */
    protected function beginTransaction(): void
    {
        $this->db->beginTransaction();
    }

    /**
     * Commit database transaction
     */
    protected function commitTransaction(): void
    {
        $this->db->commit();
    }

    /**
     * Rollback database transaction
     */
    protected function rollbackTransaction(): void
    {
        $this->db->rollback();
    }

    /**
     * Assert that a record exists in database
     * 
     * @param string $table Table name
     * @param array $conditions Where conditions
     */
    protected function assertDatabaseHas(string $table, array $conditions): void
    {
        $count = $this->db->count($table, implode(' AND ', array_map(
            fn($key) => "{$key} = ?",
            array_keys($conditions)
        )), array_values($conditions));
        
        $this->assertGreaterThan(0, $count, "Record not found in {$table} table");
    }

    /**
     * Assert that a record does not exist in database
     * 
     * @param string $table Table name
     * @param array $conditions Where conditions
     */
    protected function assertDatabaseMissing(string $table, array $conditions): void
    {
        $count = $this->db->count($table, implode(' AND ', array_map(
            fn($key) => "{$key} = ?",
            array_keys($conditions)
        )), array_values($conditions));
        
        $this->assertEquals(0, $count, "Record unexpectedly found in {$table} table");
    }

    /**
     * Get the last inserted record from a table
     * 
     * @param string $table Table name
     * @param string $primaryKey Primary key column
     * @return array|null
     */
    protected function getLastInserted(string $table, string $primaryKey = 'id'): ?array
    {
        $result = $this->db->fetchRow(
            "SELECT * FROM {$table} ORDER BY {$primaryKey} DESC LIMIT 1"
        );
        
        return $result ?: null;
    }

    /**
     * Count records in a table
     * 
     * @param string $table Table name
     * @param array $conditions Optional where conditions
     * @return int
     */
    protected function countRecords(string $table, array $conditions = []): int
    {
        if (empty($conditions)) {
            return $this->db->count($table);
        }
        
        return $this->db->count($table, implode(' AND ', array_map(
            fn($key) => "{$key} = ?",
            array_keys($conditions)
        )), array_values($conditions));
    }
}