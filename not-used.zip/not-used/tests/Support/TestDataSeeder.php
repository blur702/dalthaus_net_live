<?php

declare(strict_types=1);

namespace Tests\Support;

use CMS\Utils\Database;
use Tests\Fixtures\UserFixture;
use Tests\Fixtures\ContentFixture;

/**
 * Test Data Seeder
 * 
 * Seeds database with test data for consistent testing scenarios.
 * Provides methods to seed specific datasets and clean up data.
 */
class TestDataSeeder
{
    private Database $db;
    private UserFixture $userFixture;
    private ContentFixture $contentFixture;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->userFixture = new UserFixture();
        $this->contentFixture = new ContentFixture();
    }

    /**
     * Seed complete test dataset
     * 
     * @return array Seeded data references
     */
    public function seedAll(): array
    {
        $data = [];
        
        $data['users'] = $this->seedUsers();
        $data['content'] = $this->seedContent($data['users']);
        $data['settings'] = $this->seedSettings();
        
        return $data;
    }

    /**
     * Seed basic user data
     * 
     * @return array User IDs and data
     */
    public function seedUsers(): array
    {
        $users = [];
        
        // Admin user
        $adminData = $this->userFixture->getAdminUser();
        $adminId = $this->db->insert('users', $adminData);
        $adminData['user_id'] = (int) $adminId;
        $users['admin'] = $adminData;
        
        // Editor user
        $editorData = $this->userFixture->getEditorUser();
        $editorId = $this->db->insert('users', $editorData);
        $editorData['user_id'] = (int) $editorId;
        $users['editor'] = $editorData;
        
        // Regular user
        $regularData = $this->userFixture->getRegularUser();
        $regularId = $this->db->insert('users', $regularData);
        $regularData['user_id'] = (int) $regularId;
        $users['regular'] = $regularData;
        
        return $users;
    }

    /**
     * Seed content data
     * 
     * @param array $users User data for content association
     * @return array Content IDs and data
     */
    public function seedContent(array $users = []): array
    {
        $content = [];
        
        // If no users provided, create default associations
        if (empty($users)) {
            $users = ['admin' => ['user_id' => 1]];
        }
        
        $adminUserId = $users['admin']['user_id'];
        
        // Default article
        $articleData = $this->contentFixture->getDefaultArticle();
        $articleData['user_id'] = $adminUserId;
        $articleId = $this->db->insert('content', $articleData);
        $articleData['content_id'] = (int) $articleId;
        $content['default_article'] = $articleData;
        
        // Default photobook
        $photobookData = $this->contentFixture->getDefaultPhotobook();
        $photobookData['user_id'] = $adminUserId;
        $photobookId = $this->db->insert('content', $photobookData);
        $photobookData['content_id'] = (int) $photobookId;
        $content['default_photobook'] = $photobookData;
        
        // Workflow content (different statuses)
        foreach ($this->contentFixture->getWorkflowContent() as $key => $workflowData) {
            $workflowData['teaser'] = 'Test teaser for ' . $workflowData['title'];
            $workflowData['body'] = '<p>Test body content for ' . $workflowData['title'] . '</p>';
            $workflowData['user_id'] = $adminUserId;
            $workflowData['created_at'] = date('Y-m-d H:i:s');
            $workflowData['updated_at'] = date('Y-m-d H:i:s');
            
            $id = $this->db->insert('content', $workflowData);
            $workflowData['content_id'] = (int) $id;
            $content[$key] = $workflowData;
        }
        
        // Search content
        foreach ($this->contentFixture->getSearchContent() as $index => $searchData) {
            $searchData['user_id'] = $adminUserId;
            $searchData['created_at'] = date('Y-m-d H:i:s');
            $searchData['updated_at'] = date('Y-m-d H:i:s');
            
            $id = $this->db->insert('content', $searchData);
            $searchData['content_id'] = (int) $id;
            $content['search_' . $index] = $searchData;
        }
        
        return $content;
    }

    /**
     * Seed settings data
     * 
     * @return array Settings data
     */
    public function seedSettings(): array
    {
        $settings = [
            [
                'setting_key' => 'site_name',
                'setting_value' => 'Test CMS Site',
                'setting_type' => 'string',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'setting_key' => 'site_description',
                'setting_value' => 'A comprehensive content management system for testing',
                'setting_type' => 'string',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'setting_key' => 'items_per_page',
                'setting_value' => '10',
                'setting_type' => 'integer',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'setting_key' => 'maintenance_mode',
                'setting_value' => '0',
                'setting_type' => 'boolean',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'setting_key' => 'upload_max_size',
                'setting_value' => '5242880',
                'setting_type' => 'integer',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'setting_key' => 'allowed_file_types',
                'setting_value' => 'jpg,jpeg,png,gif,webp',
                'setting_type' => 'string',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ];
        
        $seededSettings = [];
        foreach ($settings as $setting) {
            $id = $this->db->insert('settings', $setting);
            $setting['setting_id'] = (int) $id;
            $seededSettings[$setting['setting_key']] = $setting;
        }
        
        return $seededSettings;
    }

    /**
     * Seed bulk data for performance testing
     * 
     * @param int $userCount Number of users to create
     * @param int $contentCount Number of content items to create
     * @return array Bulk data references
     */
    public function seedBulkData(int $userCount = 100, int $contentCount = 500): array
    {
        $bulkUsers = $this->userFixture->getBulkUsers($userCount);
        $bulkContent = $this->contentFixture->getBulkContent($contentCount);
        
        $data = [
            'users' => [],
            'content' => []
        ];
        
        // Insert bulk users
        foreach ($bulkUsers as $userData) {
            $userId = $this->db->insert('users', $userData);
            $userData['user_id'] = (int) $userId;
            $data['users'][] = $userData;
        }
        
        // Insert bulk content
        $userIds = array_column($data['users'], 'user_id');
        foreach ($bulkContent as $contentData) {
            // Assign random user
            $contentData['user_id'] = $userIds[array_rand($userIds)];
            
            $contentId = $this->db->insert('content', $contentData);
            $contentData['content_id'] = (int) $contentId;
            $data['content'][] = $contentData;
        }
        
        return $data;
    }

    /**
     * Seed specific test scenario data
     * 
     * @param string $scenario Scenario name
     * @return array Scenario data
     */
    public function seedScenario(string $scenario): array
    {
        switch ($scenario) {
            case 'authentication_tests':
                return $this->seedAuthenticationTestData();
                
            case 'content_workflow':
                return $this->seedContentWorkflowData();
                
            case 'security_tests':
                return $this->seedSecurityTestData();
                
            case 'performance_tests':
                return $this->seedBulkData(50, 200);
                
            case 'search_tests':
                return $this->seedSearchTestData();
                
            default:
                throw new \InvalidArgumentException("Unknown scenario: {$scenario}");
        }
    }

    /**
     * Seed authentication-specific test data
     * 
     * @return array Authentication test data
     */
    private function seedAuthenticationTestData(): array
    {
        $data = ['users' => []];
        
        // Add auth-specific users
        foreach ($this->userFixture->getAuthTestUsers() as $key => $userData) {
            $userData['created_at'] = date('Y-m-d H:i:s');
            $userData['updated_at'] = date('Y-m-d H:i:s');
            
            $userId = $this->db->insert('users', $userData);
            $userData['user_id'] = (int) $userId;
            $data['users'][$key] = $userData;
        }
        
        return $data;
    }

    /**
     * Seed content workflow test data
     * 
     * @return array Workflow test data
     */
    private function seedContentWorkflowData(): array
    {
        $users = $this->seedUsers();
        $data = ['users' => $users, 'content' => []];
        
        // Create content in different states for workflow testing
        $workflowStates = [
            'new_draft' => ['status' => 'draft', 'published_at' => null],
            'ready_for_review' => ['status' => 'draft', 'published_at' => null],
            'published' => ['status' => 'published', 'published_at' => date('Y-m-d H:i:s')],
            'archived' => ['status' => 'draft', 'published_at' => null]
        ];
        
        foreach ($workflowStates as $state => $stateData) {
            $contentData = array_merge(
                $this->contentFixture->generateArticle(),
                $stateData,
                [
                    'title' => ucfirst(str_replace('_', ' ', $state)) . ' Article',
                    'url_alias' => $state . '-article',
                    'user_id' => $users['editor']['user_id']
                ]
            );
            
            $contentId = $this->db->insert('content', $contentData);
            $contentData['content_id'] = (int) $contentId;
            $data['content'][$state] = $contentData;
        }
        
        return $data;
    }

    /**
     * Seed security test data
     * 
     * @return array Security test data
     */
    private function seedSecurityTestData(): array
    {
        $data = ['users' => [], 'content' => []];
        
        // Create users with security test cases
        foreach ($this->userFixture->getSecurityTestCases() as $key => $userData) {
            $userData['password_hash'] = password_hash($userData['password'], PASSWORD_DEFAULT);
            unset($userData['password']);
            $userData['created_at'] = date('Y-m-d H:i:s');
            $userData['updated_at'] = date('Y-m-d H:i:s');
            
            try {
                $userId = $this->db->insert('users', $userData);
                $userData['user_id'] = (int) $userId;
                $data['users'][$key] = $userData;
            } catch (\Exception $e) {
                // Some security test cases are expected to fail
                $data['users'][$key] = ['error' => $e->getMessage()];
            }
        }
        
        // Create content with HTML security test cases
        $htmlTestCases = $this->contentFixture->getHtmlTestCases();
        foreach ($htmlTestCases as $key => $testCase) {
            $contentData = [
                'title' => 'Security Test: ' . ucfirst(str_replace('_', ' ', $key)),
                'teaser' => 'Security test content',
                'body' => $testCase['body'],
                'content_type' => 'article',
                'status' => 'draft',
                'url_alias' => 'security-test-' . $key,
                'user_id' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $contentId = $this->db->insert('content', $contentData);
            $contentData['content_id'] = (int) $contentId;
            $data['content'][$key] = $contentData;
        }
        
        return $data;
    }

    /**
     * Seed search test data
     * 
     * @return array Search test data
     */
    private function seedSearchTestData(): array
    {
        $users = $this->seedUsers();
        $data = ['users' => $users, 'content' => []];
        
        // Add search-optimized content
        $searchContent = $this->contentFixture->getSearchContent();
        foreach ($searchContent as $index => $contentData) {
            $contentData['user_id'] = $users['admin']['user_id'];
            $contentData['created_at'] = date('Y-m-d H:i:s');
            $contentData['updated_at'] = date('Y-m-d H:i:s');
            
            $contentId = $this->db->insert('content', $contentData);
            $contentData['content_id'] = (int) $contentId;
            $data['content']['search_' . $index] = $contentData;
        }
        
        return $data;
    }

    /**
     * Clean all seeded data
     * 
     * @return void
     */
    public function cleanAll(): void
    {
        $tables = ['content', 'users', 'settings', 'pages', 'menus', 'menu_items'];
        
        foreach ($tables as $table) {
            try {
                $this->db->query("DELETE FROM {$table}");
                // Reset auto-increment
                $this->db->query("DELETE FROM sqlite_sequence WHERE name = '{$table}'");
            } catch (\Exception $e) {
                // Ignore errors during cleanup
            }
        }
    }

    /**
     * Clean specific table data
     * 
     * @param string $table Table name
     * @param array $conditions WHERE conditions
     * @return void
     */
    public function cleanTable(string $table, array $conditions = []): void
    {
        if (empty($conditions)) {
            $this->db->query("DELETE FROM {$table}");
        } else {
            $whereParts = [];
            $params = [];
            
            foreach ($conditions as $column => $value) {
                $whereParts[] = "{$column} = ?";
                $params[] = $value;
            }
            
            $whereClause = implode(' AND ', $whereParts);
            $this->db->query("DELETE FROM {$table} WHERE {$whereClause}", $params);
        }
    }

    /**
     * Get seeded data summary
     * 
     * @return array Data counts by table
     */
    public function getDataSummary(): array
    {
        $summary = [];
        $tables = ['users', 'content', 'settings', 'pages', 'menus', 'menu_items'];
        
        foreach ($tables as $table) {
            try {
                $count = $this->db->fetchColumn("SELECT COUNT(*) FROM {$table}");
                $summary[$table] = (int) $count;
            } catch (\Exception $e) {
                $summary[$table] = 0;
            }
        }
        
        return $summary;
    }

    /**
     * Verify data integrity
     * 
     * @return array Integrity check results
     */
    public function verifyIntegrity(): array
    {
        $results = [];
        
        // Check user-content relationships
        $orphanedContent = $this->db->fetchColumn(
            "SELECT COUNT(*) FROM content WHERE user_id NOT IN (SELECT user_id FROM users)"
        );
        $results['orphaned_content'] = (int) $orphanedContent;
        
        // Check for duplicate usernames
        $duplicateUsernames = $this->db->fetchColumn(
            "SELECT COUNT(*) - COUNT(DISTINCT username) FROM users"
        );
        $results['duplicate_usernames'] = (int) $duplicateUsernames;
        
        // Check for duplicate emails
        $duplicateEmails = $this->db->fetchColumn(
            "SELECT COUNT(*) - COUNT(DISTINCT email) FROM users"
        );
        $results['duplicate_emails'] = (int) $duplicateEmails;
        
        // Check for duplicate URL aliases
        $duplicateAliases = $this->db->fetchColumn(
            "SELECT COUNT(*) - COUNT(DISTINCT url_alias) FROM content WHERE url_alias IS NOT NULL"
        );
        $results['duplicate_aliases'] = (int) $duplicateAliases;
        
        return $results;
    }

    /**
     * Create snapshot of current data
     * 
     * @return array Data snapshot
     */
    public function createSnapshot(): array
    {
        $snapshot = [];
        $tables = ['users', 'content', 'settings'];
        
        foreach ($tables as $table) {
            $snapshot[$table] = $this->db->fetchAll("SELECT * FROM {$table}");
        }
        
        return $snapshot;
    }

    /**
     * Restore data from snapshot
     * 
     * @param array $snapshot Data snapshot
     * @return void
     */
    public function restoreSnapshot(array $snapshot): void
    {
        foreach ($snapshot as $table => $rows) {
            // Clear table
            $this->db->query("DELETE FROM {$table}");
            
            // Restore data
            foreach ($rows as $row) {
                $this->db->insert($table, $row);
            }
        }
    }
}