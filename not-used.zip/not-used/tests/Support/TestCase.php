<?php

declare(strict_types=1);

namespace Tests\Support;

use PHPUnit\Framework\TestCase as BaseTestCase;
use Faker\Factory as FakerFactory;
use Faker\Generator;
use ReflectionClass;
use ReflectionMethod;
use ReflectionProperty;

/**
 * Base Test Case
 * 
 * Provides common functionality and utilities for all test classes.
 * Includes helper methods for assertions, mocking, and test data generation.
 */
abstract class TestCase extends BaseTestCase
{
    /**
     * Faker instance for generating test data
     */
    protected Generator $faker;

    /**
     * Test configuration
     */
    protected array $testConfig;

    /**
     * Set up test case
     */
    protected function setUp(): void
    {
        parent::setUp();
        
        // Initialize Faker
        $this->faker = FakerFactory::create();
        
        // Load test configuration
        $this->testConfig = require TEST_ROOT . '/config/test_config.php';
        
        // Clean session state
        $this->cleanSession();
        
        // Set up test environment
        $this->setUpTestEnvironment();
    }

    /**
     * Clean up after test
     */
    protected function tearDown(): void
    {
        // Clean session
        $this->cleanSession();
        
        // Clean up test files
        $this->cleanupTestFiles();
        
        parent::tearDown();
    }

    /**
     * Set up test environment
     */
    protected function setUpTestEnvironment(): void
    {
        // Set timezone
        date_default_timezone_set($this->testConfig['app']['timezone']);
        
        // Create test upload directory if it doesn't exist
        $uploadDir = $this->testConfig['app']['upload_path'];
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
    }

    /**
     * Clean session state
     */
    protected function cleanSession(): void
    {
        $_SESSION = [];
        $_COOKIE = [];
        $_POST = [];
        $_GET = [];
        $_REQUEST = [];
        $_FILES = [];
    }

    /**
     * Clean up test files
     */
    protected function cleanupTestFiles(): void
    {
        $uploadDir = $this->testConfig['app']['upload_path'];
        if (is_dir($uploadDir)) {
            $files = glob($uploadDir . '/*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
    }

    /**
     * Generate fake user data
     * 
     * @param array $overrides Override specific fields
     * @return array
     */
    protected function fakeUserData(array $overrides = []): array
    {
        return array_merge([
            'username' => $this->faker->userName(),
            'email' => $this->faker->email(),
            'password' => $this->faker->password(8),
            'created_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s')
        ], $overrides);
    }

    /**
     * Generate fake content data
     * 
     * @param array $overrides Override specific fields
     * @return array
     */
    protected function fakeContentData(array $overrides = []): array
    {
        return array_merge([
            'title' => $this->faker->sentence(),
            'teaser' => $this->faker->paragraph(),
            'body' => $this->faker->text(2000),
            'content_type' => $this->faker->randomElement(['article', 'photobook']),
            'status' => $this->faker->randomElement(['draft', 'published']),
            'url_alias' => $this->faker->slug(),
            'sort_order' => $this->faker->numberBetween(1, 100),
            'user_id' => 1,
            'created_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s'),
            'updated_at' => $this->faker->dateTimeThisYear()->format('Y-m-d H:i:s')
        ], $overrides);
    }

    /**
     * Create a fake uploaded file for testing
     * 
     * @param string $filename Original filename
     * @param string $content File content
     * @param string $mimeType MIME type
     * @param int $error Upload error code
     * @return array $_FILES array structure
     */
    protected function createFakeUploadedFile(
        string $filename = 'test.jpg',
        string $content = 'fake image content',
        string $mimeType = 'image/jpeg',
        int $error = UPLOAD_ERR_OK
    ): array {
        $tmpName = tempnam(sys_get_temp_dir(), 'test_upload_');
        file_put_contents($tmpName, $content);
        
        return [
            'name' => $filename,
            'type' => $mimeType,
            'tmp_name' => $tmpName,
            'error' => $error,
            'size' => strlen($content)
        ];
    }

    /**
     * Assert that an array contains specific keys
     * 
     * @param array $expectedKeys Expected keys
     * @param array $array Array to check
     */
    protected function assertArrayHasKeys(array $expectedKeys, array $array): void
    {
        foreach ($expectedKeys as $key) {
            $this->assertArrayHasKey($key, $array, "Array missing expected key: {$key}");
        }
    }

    /**
     * Assert that an exception is thrown with specific message
     * 
     * @param string $expectedClass Exception class
     * @param string $expectedMessage Expected message
     * @param callable $callback Callback that should throw
     */
    protected function assertExceptionThrown(
        string $expectedClass,
        string $expectedMessage,
        callable $callback
    ): void {
        try {
            $callback();
            $this->fail("Expected exception {$expectedClass} was not thrown");
        } catch (\Exception $e) {
            $this->assertInstanceOf($expectedClass, $e);
            $this->assertStringContainsString($expectedMessage, $e->getMessage());
        }
    }

    /**
     * Make a protected/private method accessible for testing
     * 
     * @param object $object Object instance
     * @param string $methodName Method name
     * @return ReflectionMethod
     */
    protected function makeMethodAccessible(object $object, string $methodName): ReflectionMethod
    {
        $reflection = new ReflectionClass($object);
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);
        
        return $method;
    }

    /**
     * Make a protected/private property accessible for testing
     * 
     * @param object $object Object instance
     * @param string $propertyName Property name
     * @return ReflectionProperty
     */
    protected function makePropertyAccessible(object $object, string $propertyName): ReflectionProperty
    {
        $reflection = new ReflectionClass($object);
        $property = $reflection->getProperty($propertyName);
        $property->setAccessible(true);
        
        return $property;
    }

    /**
     * Get protected/private property value
     * 
     * @param object $object Object instance
     * @param string $propertyName Property name
     * @return mixed
     */
    protected function getProtectedProperty(object $object, string $propertyName): mixed
    {
        $property = $this->makePropertyAccessible($object, $propertyName);
        return $property->getValue($object);
    }

    /**
     * Set protected/private property value
     * 
     * @param object $object Object instance
     * @param string $propertyName Property name
     * @param mixed $value New value
     */
    protected function setProtectedProperty(object $object, string $propertyName, mixed $value): void
    {
        $property = $this->makePropertyAccessible($object, $propertyName);
        $property->setValue($object, $value);
    }

    /**
     * Call a protected/private method
     * 
     * @param object $object Object instance
     * @param string $methodName Method name
     * @param array $args Method arguments
     * @return mixed
     */
    protected function callProtectedMethod(object $object, string $methodName, array $args = []): mixed
    {
        $method = $this->makeMethodAccessible($object, $methodName);
        return $method->invokeArgs($object, $args);
    }

    /**
     * Mock $_SESSION superglobal
     * 
     * @param array $sessionData Session data
     */
    protected function mockSession(array $sessionData = []): void
    {
        $_SESSION = $sessionData;
    }

    /**
     * Mock $_POST superglobal
     * 
     * @param array $postData POST data
     */
    protected function mockPost(array $postData = []): void
    {
        $_POST = $postData;
    }

    /**
     * Mock $_GET superglobal
     * 
     * @param array $getData GET data
     */
    protected function mockGet(array $getData = []): void
    {
        $_GET = $getData;
    }

    /**
     * Mock $_FILES superglobal
     * 
     * @param array $filesData FILES data
     */
    protected function mockFiles(array $filesData = []): void
    {
        $_FILES = $filesData;
    }

    /**
     * Assert that a string contains HTML
     * 
     * @param string $html HTML content
     */
    protected function assertIsValidHtml(string $html): void
    {
        // Basic HTML validation - check for proper opening/closing tags
        $this->assertMatchesRegularExpression('/<[^>]+>/', $html, 'String does not contain valid HTML tags');
    }

    /**
     * Assert that a string is a valid email
     * 
     * @param string $email Email to validate
     */
    protected function assertIsValidEmail(string $email): void
    {
        $this->assertTrue(
            filter_var($email, FILTER_VALIDATE_EMAIL) !== false,
            "'{$email}' is not a valid email address"
        );
    }

    /**
     * Assert that a string is a valid URL
     * 
     * @param string $url URL to validate
     */
    protected function assertIsValidUrl(string $url): void
    {
        $this->assertTrue(
            filter_var($url, FILTER_VALIDATE_URL) !== false,
            "'{$url}' is not a valid URL"
        );
    }

    /**
     * Assert that a timestamp is recent (within last few seconds)
     * 
     * @param string $timestamp Timestamp to check
     * @param int $maxAgeSeconds Maximum age in seconds
     */
    protected function assertIsRecentTimestamp(string $timestamp, int $maxAgeSeconds = 10): void
    {
        $timestampTime = strtotime($timestamp);
        $now = time();
        $age = $now - $timestampTime;
        
        $this->assertLessThanOrEqual(
            $maxAgeSeconds,
            $age,
            "Timestamp '{$timestamp}' is not recent enough (age: {$age} seconds)"
        );
    }
}