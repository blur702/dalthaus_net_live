<?php

declare(strict_types=1);

/**
 * PHPUnit Bootstrap File
 * 
 * This file is executed before running tests and sets up the testing environment.
 * It includes autoloading, configuration, and test utilities initialization.
 */

// Define test environment
define('TESTING', true);
define('TEST_ROOT', __DIR__);
define('PROJECT_ROOT', dirname(__DIR__));

// Autoload classes
require_once PROJECT_ROOT . '/vendor/autoload.php';

// Set timezone
date_default_timezone_set('UTC');

// Set error reporting for tests
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Start session for tests that require it
if (!session_id()) {
    session_start();
}

// Load test configuration
require_once __DIR__ . '/config/test_config.php';

// Initialize test database
require_once __DIR__ . '/Support/DatabaseTestCase.php';

// Load test utilities
require_once __DIR__ . '/Support/TestCase.php';

// Set up in-memory SQLite database for testing
$testDbConfig = [
    'host' => ':memory:',
    'dbname' => ':memory:',
    'username' => '',
    'password' => '',
    'charset' => 'utf8',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]
];

// Store test database config in global variable for tests to use
$GLOBALS['test_db_config'] = $testDbConfig;

// Clean up any existing sessions
$_SESSION = [];
$_COOKIE = [];
$_POST = [];
$_GET = [];
$_REQUEST = [];
$_FILES = [];

// Create test upload directory
$testUploadsDir = TEST_ROOT . '/uploads';
if (!is_dir($testUploadsDir)) {
    mkdir($testUploadsDir, 0755, true);
}

// Register shutdown function to clean up test files
register_shutdown_function(function () {
    $testUploadsDir = TEST_ROOT . '/uploads';
    if (is_dir($testUploadsDir)) {
        array_map('unlink', glob("$testUploadsDir/*.*"));
    }
});