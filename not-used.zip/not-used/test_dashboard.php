<?php

// Test admin dashboard after login
echo "Testing admin dashboard access...\n";

// Access dashboard using session cookie
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/dashboard');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);

curl_close($ch);

echo "Dashboard HTTP Status: $httpCode\n";
echo "Final URL: $finalUrl\n";

if ($httpCode === 200) {
    echo "✅ Dashboard loads successfully\n";
    
    // Check for dashboard elements
    if (strpos($response, 'Dashboard') !== false) {
        echo "✅ Dashboard content found\n";
    }
    
    if (strpos($response, 'Welcome') !== false || strpos($response, 'kevin') !== false) {
        echo "✅ Welcome message or user name found\n";
    }
    
    if (strpos($response, 'Content') !== false) {
        echo "✅ Content management links found\n";
    }
    
} else {
    echo "❌ Dashboard failed to load\n";
    if (strpos($finalUrl, '/admin/login') !== false) {
        echo "❌ Redirected to login - session may have expired\n";
    }
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

echo "\nDashboard test complete!\n";