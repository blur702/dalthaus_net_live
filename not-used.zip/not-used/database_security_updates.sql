-- ============================================================================
-- Security Database Updates
-- Created: 2025-09-06
-- Description: Additional security tables for audit logging and login tracking
-- ============================================================================

-- Create login attempts table for better security tracking
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `attempt_id` int(11) NOT NULL AUTO_INCREMENT,
    `identifier` varchar(100) NOT NULL COMMENT 'Username or email used',
    `ip_address` varchar(45) NOT NULL COMMENT 'IPv4 or IPv6 address',
    `user_agent` varchar(255) DEFAULT NULL,
    `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `success` tinyint(1) DEFAULT 0 COMMENT '1 for successful login, 0 for failed',
    `failure_reason` varchar(100) DEFAULT NULL COMMENT 'Reason for failure if applicable',
    PRIMARY KEY (`attempt_id`),
    INDEX `idx_identifier` (`identifier`),
    INDEX `idx_ip_address` (`ip_address`),
    INDEX `idx_attempted_at` (`attempted_at`),
    INDEX `idx_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create audit logs table for security event tracking
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `log_id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) DEFAULT NULL,
    `action` varchar(100) NOT NULL COMMENT 'Action performed (login, logout, create, update, delete, etc.)',
    `object_type` varchar(50) DEFAULT NULL COMMENT 'Type of object affected (user, content, page, etc.)',
    `object_id` int(11) DEFAULT NULL COMMENT 'ID of affected object',
    `details` text DEFAULT NULL COMMENT 'JSON or text details of the action',
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` varchar(255) DEFAULT NULL,
    `request_method` varchar(10) DEFAULT NULL,
    `request_uri` varchar(500) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`log_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
    INDEX `idx_action` (`action`),
    INDEX `idx_object_type` (`object_type`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create blocked IPs table
CREATE TABLE IF NOT EXISTS `blocked_ips` (
    `block_id` int(11) NOT NULL AUTO_INCREMENT,
    `ip_address` varchar(45) NOT NULL,
    `reason` varchar(255) NOT NULL COMMENT 'Reason for blocking',
    `blocked_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `blocked_until` timestamp NULL DEFAULT NULL COMMENT 'NULL for permanent block',
    `blocked_by` int(11) DEFAULT NULL COMMENT 'User who blocked the IP',
    `auto_blocked` tinyint(1) DEFAULT 0 COMMENT '1 if blocked by system, 0 if manual',
    PRIMARY KEY (`block_id`),
    UNIQUE KEY `idx_ip_address` (`ip_address`),
    FOREIGN KEY (`blocked_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
    INDEX `idx_blocked_until` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create password reset tokens table
CREATE TABLE IF NOT EXISTS `password_resets` (
    `reset_id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `token` varchar(255) NOT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `expires_at` timestamp NOT NULL,
    `used_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`reset_id`),
    UNIQUE KEY `idx_token` (`token`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    INDEX `idx_expires_at` (`expires_at`),
    INDEX `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create two-factor authentication table (for future implementation)
CREATE TABLE IF NOT EXISTS `two_factor_auth` (
    `2fa_id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `secret` varchar(255) NOT NULL,
    `enabled` tinyint(1) DEFAULT 0,
    `backup_codes` text DEFAULT NULL COMMENT 'JSON array of backup codes',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_used_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`2fa_id`),
    UNIQUE KEY `idx_user_id` (`user_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create API keys table for secure API access
CREATE TABLE IF NOT EXISTS `api_keys` (
    `key_id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `key_name` varchar(100) NOT NULL,
    `api_key` varchar(255) NOT NULL,
    `permissions` text DEFAULT NULL COMMENT 'JSON array of allowed permissions',
    `last_used_at` timestamp NULL DEFAULT NULL,
    `expires_at` timestamp NULL DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `is_active` tinyint(1) DEFAULT 1,
    PRIMARY KEY (`key_id`),
    UNIQUE KEY `idx_api_key` (`api_key`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add additional security fields to users table
ALTER TABLE `users` 
    ADD COLUMN IF NOT EXISTS `last_login_at` timestamp NULL DEFAULT NULL AFTER `created_at`,
    ADD COLUMN IF NOT EXISTS `last_login_ip` varchar(45) DEFAULT NULL AFTER `last_login_at`,
    ADD COLUMN IF NOT EXISTS `failed_login_count` int(11) DEFAULT 0 AFTER `last_login_ip`,
    ADD COLUMN IF NOT EXISTS `locked_until` timestamp NULL DEFAULT NULL AFTER `failed_login_count`,
    ADD COLUMN IF NOT EXISTS `must_change_password` tinyint(1) DEFAULT 0 AFTER `locked_until`,
    ADD COLUMN IF NOT EXISTS `password_changed_at` timestamp NULL DEFAULT NULL AFTER `must_change_password`,
    ADD COLUMN IF NOT EXISTS `is_active` tinyint(1) DEFAULT 1 AFTER `password_changed_at`,
    ADD COLUMN IF NOT EXISTS `email_verified_at` timestamp NULL DEFAULT NULL AFTER `is_active`,
    ADD COLUMN IF NOT EXISTS `verification_token` varchar(255) DEFAULT NULL AFTER `email_verified_at`;

-- Add indexes for new user fields
ALTER TABLE `users`
    ADD INDEX IF NOT EXISTS `idx_is_active` (`is_active`),
    ADD INDEX IF NOT EXISTS `idx_locked_until` (`locked_until`),
    ADD INDEX IF NOT EXISTS `idx_verification_token` (`verification_token`);

-- Create session storage table (for database-backed sessions)
CREATE TABLE IF NOT EXISTS `sessions` (
    `session_id` varchar(128) NOT NULL,
    `user_id` int(11) DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` varchar(255) DEFAULT NULL,
    `payload` text NOT NULL,
    `last_activity` int(11) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`session_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create table for storing file upload metadata
CREATE TABLE IF NOT EXISTS `file_uploads` (
    `upload_id` int(11) NOT NULL AUTO_INCREMENT,
    `filename` varchar(255) NOT NULL,
    `original_name` varchar(255) NOT NULL,
    `mime_type` varchar(100) NOT NULL,
    `size` int(11) NOT NULL,
    `hash` varchar(64) DEFAULT NULL COMMENT 'SHA256 hash of file',
    `uploaded_by` int(11) NOT NULL,
    `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `scan_status` enum('pending','clean','suspicious','infected') DEFAULT 'pending',
    `scan_result` text DEFAULT NULL,
    PRIMARY KEY (`upload_id`),
    FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    INDEX `idx_filename` (`filename`),
    INDEX `idx_uploaded_by` (`uploaded_by`),
    INDEX `idx_uploaded_at` (`uploaded_at`),
    INDEX `idx_scan_status` (`scan_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create security events table for monitoring
CREATE TABLE IF NOT EXISTS `security_events` (
    `event_id` int(11) NOT NULL AUTO_INCREMENT,
    `event_type` varchar(50) NOT NULL COMMENT 'Type of security event',
    `severity` enum('info','low','medium','high','critical') NOT NULL,
    `description` text NOT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` varchar(255) DEFAULT NULL,
    `request_data` text DEFAULT NULL COMMENT 'Sanitized request data',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `resolved` tinyint(1) DEFAULT 0,
    `resolved_at` timestamp NULL DEFAULT NULL,
    `resolved_by` int(11) DEFAULT NULL,
    PRIMARY KEY (`event_id`),
    FOREIGN KEY (`resolved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
    INDEX `idx_event_type` (`event_type`),
    INDEX `idx_severity` (`severity`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_resolved` (`resolved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Stored Procedures for Security Operations
-- ============================================================================

DELIMITER $$

-- Procedure to clean old login attempts
CREATE PROCEDURE IF NOT EXISTS `clean_old_login_attempts`(IN days_old INT)
BEGIN
    DELETE FROM `login_attempts` 
    WHERE `attempted_at` < DATE_SUB(NOW(), INTERVAL days_old DAY);
END$$

-- Procedure to clean old audit logs
CREATE PROCEDURE IF NOT EXISTS `clean_old_audit_logs`(IN days_old INT)
BEGIN
    DELETE FROM `audit_logs` 
    WHERE `created_at` < DATE_SUB(NOW(), INTERVAL days_old DAY);
END$$

-- Procedure to check if IP should be blocked
CREATE PROCEDURE IF NOT EXISTS `check_ip_for_blocking`(
    IN check_ip VARCHAR(45),
    IN max_attempts INT,
    IN time_window INT,
    OUT should_block BOOLEAN
)
BEGIN
    DECLARE failed_count INT;
    
    SELECT COUNT(*) INTO failed_count
    FROM `login_attempts`
    WHERE `ip_address` = check_ip
        AND `success` = 0
        AND `attempted_at` > DATE_SUB(NOW(), INTERVAL time_window MINUTE);
    
    SET should_block = (failed_count >= max_attempts);
    
    -- Auto-block IP if threshold exceeded
    IF should_block THEN
        INSERT IGNORE INTO `blocked_ips` (`ip_address`, `reason`, `auto_blocked`, `blocked_until`)
        VALUES (check_ip, CONCAT('Exceeded login attempts: ', failed_count), 1, DATE_ADD(NOW(), INTERVAL 24 HOUR));
    END IF;
END$$

DELIMITER ;

-- ============================================================================
-- Triggers for Automatic Security Actions
-- ============================================================================

DELIMITER $$

-- Trigger to log user creation
CREATE TRIGGER IF NOT EXISTS `after_user_insert`
AFTER INSERT ON `users`
FOR EACH ROW
BEGIN
    INSERT INTO `audit_logs` (`user_id`, `action`, `object_type`, `object_id`, `details`)
    VALUES (NEW.user_id, 'user_created', 'user', NEW.user_id, 
            JSON_OBJECT('username', NEW.username, 'email', NEW.email));
END$$

-- Trigger to log user updates
CREATE TRIGGER IF NOT EXISTS `after_user_update`
AFTER UPDATE ON `users`
FOR EACH ROW
BEGIN
    IF OLD.password_hash != NEW.password_hash THEN
        INSERT INTO `audit_logs` (`user_id`, `action`, `object_type`, `object_id`, `details`)
        VALUES (NEW.user_id, 'password_changed', 'user', NEW.user_id, 
                JSON_OBJECT('username', NEW.username));
    END IF;
END$$

DELIMITER ;

-- ============================================================================
-- Default Security Settings
-- ============================================================================

-- Insert default security settings if not exists
INSERT IGNORE INTO `settings` (`setting_name`, `setting_value`) VALUES 
('security_enable_2fa', '0'),
('security_password_min_length', '12'),
('security_password_expire_days', '90'),
('security_max_login_attempts', '5'),
('security_lockout_duration', '900'),
('security_session_timeout', '3600'),
('security_force_https', '1'),
('security_enable_audit_log', '1'),
('security_enable_ip_blocking', '1'),
('security_file_upload_scan', '1');

-- ============================================================================
-- Cleanup and Optimization
-- ============================================================================

-- Schedule regular cleanup (to be run via cron job)
-- Example cron: 0 2 * * * mysql -u username -p database < cleanup.sql

-- Optimize tables
OPTIMIZE TABLE `login_attempts`;
OPTIMIZE TABLE `audit_logs`;
OPTIMIZE TABLE `sessions`;
OPTIMIZE TABLE `security_events`;

-- ============================================================================
-- End of Security Updates
-- ============================================================================