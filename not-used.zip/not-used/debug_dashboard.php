<?php

class DashboardDebugger
{
    private array $cookies = [];
    private string $baseUrl = 'http://localhost';

    public function debug(): void
    {
        echo "DASHBOARD ACCESS DEBUG\n";
        echo str_repeat("=", 40) . "\n\n";

        // Step 1: Login
        echo "STEP 1: Performing login\n";
        $loginSuccess = $this->performLogin();
        echo "Login successful: " . ($loginSuccess ? 'YES' : 'NO') . "\n";
        echo "Cookies after login: " . count($this->cookies) . "\n";
        foreach ($this->cookies as $cookie) {
            echo "  - $cookie\n";
        }
        echo "\n";

        if (!$loginSuccess) {
            echo "❌ Login failed, cannot proceed with dashboard test\n";
            return;
        }

        // Step 2: Access dashboard
        echo "STEP 2: Accessing dashboard\n";
        $response = $this->makeRequest('GET', '/admin/dashboard');
        echo "Dashboard status: {$response['http_code']}\n";
        echo "Response length: " . strlen($response['body']) . "\n";

        if ($response['http_code'] === 302) {
            if (preg_match('/Location:\s*(.+)/i', $response['headers'], $matches)) {
                $redirectUrl = trim($matches[1]);
                echo "Redirect to: $redirectUrl\n";
            }
        }

        echo "Response preview (first 500 chars):\n";
        echo substr($response['body'], 0, 500) . "\n";
        echo "\n";

        // Step 3: Check session info
        echo "STEP 3: Session debugging\n";
        $sessionResponse = $this->makeRequest('GET', '/admin/dashboard');
        echo "Session check response: {$sessionResponse['http_code']}\n";

        // Step 4: Try alternative admin pages
        echo "\nSTEP 4: Testing other admin pages\n";
        $pages = ['/admin', '/admin/content', '/admin/users', '/admin/settings'];
        
        foreach ($pages as $page) {
            $testResponse = $this->makeRequest('GET', $page);
            echo "{$page}: {$testResponse['http_code']}\n";
        }
    }

    private function performLogin(): bool
    {
        // Get login form
        $formResponse = $this->makeRequest('GET', '/admin/login');
        if ($formResponse['http_code'] !== 200) {
            return false;
        }

        // Extract CSRF token
        preg_match('/name="_token"\s+value="([^"]+)"/', $formResponse['body'], $matches);
        $csrfToken = $matches[1] ?? '';
        
        if (empty($csrfToken)) {
            echo "❌ No CSRF token found\n";
            return false;
        }

        // Perform login
        $loginResponse = $this->makeRequest('POST', '/admin/login', [
            'username' => 'kevin',
            'password' => '(130Bpm)',
            '_token' => $csrfToken
        ]);

        return $loginResponse['http_code'] === 302 &&
               strpos($loginResponse['headers'], 'Location: /admin/dashboard') !== false;
    }

    private function makeRequest(string $method, string $path, array $data = []): array
    {
        $url = $this->baseUrl . $path;
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Dashboard-Debugger/1.0',
            CURLOPT_HEADER => true,
        ]);

        if (!empty($this->cookies)) {
            curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $this->cookies));
        }

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if (!empty($data)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
            }
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

        curl_close($ch);

        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        // Extract cookies
        if (preg_match_all('/^Set-Cookie:\s*([^;\r\n]+)/mi', $headers, $matches)) {
            foreach ($matches[1] as $cookie) {
                $cookieName = explode('=', $cookie)[0];
                $this->cookies = array_filter($this->cookies, function($c) use ($cookieName) {
                    return !str_starts_with($c, $cookieName . '=');
                });
                $this->cookies[] = $cookie;
            }
        }

        return [
            'http_code' => $httpCode,
            'headers' => $headers,
            'body' => $body
        ];
    }
}

$debugger = new DashboardDebugger();
$debugger->debug();