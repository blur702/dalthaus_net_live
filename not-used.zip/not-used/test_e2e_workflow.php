<?php

// Test end-to-end workflow: Login → Create Content → View Frontend
echo "Testing end-to-end workflow...\n";
echo "=======================================\n";

// Step 1: Login (we already have cookies from previous tests)
echo "Step 1: Verify admin session...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/dashboard');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    echo "✅ Admin session is active\n";
} else {
    echo "❌ Admin session expired, please run login test first\n";
    exit(1);
}

// Step 2: Get the content creation form to extract CSRF token
echo "\nStep 2: Getting content creation form...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content/create?type=article');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    echo "❌ Failed to get content creation form\n";
    exit(1);
}

// Extract CSRF token
preg_match('/name="_token" value="([^"]+)"/', $response, $matches);
if (!isset($matches[1])) {
    echo "❌ Could not extract CSRF token from creation form\n";
    exit(1);
}

$csrf_token = $matches[1];
echo "✅ Content creation form loaded, CSRF token extracted\n";

// Step 3: Create a test article
echo "\nStep 3: Creating test article...\n";

$testTitle = 'Test Article ' . date('Y-m-d H:i:s');
$testAlias = 'test-article-' . time();
$testTeaser = 'This is a test article teaser created during end-to-end testing.';
$testBody = 'This is the body content of the test article. It contains some sample text to verify the content creation and display functionality.';

$postData = [
    'title' => $testTitle,
    'url_alias' => $testAlias,
    'content_type' => 'article',
    'teaser' => $testTeaser,
    'body' => $testBody,
    'status' => 'published',
    'sort_order' => '1',
    '_token' => $csrf_token
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content/create');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$redirectLocation = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
curl_close($ch);

echo "Content creation HTTP Status: $httpCode\n";
echo "Redirect location: $redirectLocation\n";

if ($httpCode === 302 && strpos($redirectLocation, '/admin/content') !== false) {
    echo "✅ Test article created successfully\n";
} else {
    echo "❌ Failed to create test article\n";
    echo "Response: " . substr($response, 0, 1000) . "...\n";
    // Continue anyway to test what we can
}

// Step 4: Verify content appears in admin content list
echo "\nStep 4: Verifying article appears in admin content list...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    if (strpos($response, $testTitle) !== false) {
        echo "✅ Test article found in admin content list\n";
    } else {
        echo "⚠️  Test article not found in admin content list (may be pagination issue)\n";
    }
} else {
    echo "❌ Failed to load admin content list\n";
}

// Step 5: Check if article appears on frontend articles page
echo "\nStep 5: Checking if article appears on frontend...\n";

// Give it a moment for any caching to clear
sleep(1);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/articles');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    if (strpos($response, $testTitle) !== false) {
        echo "✅ Test article found on frontend articles page\n";
    } else {
        echo "⚠️  Test article not found on frontend articles page\n";
    }
} else {
    echo "❌ Failed to load frontend articles page\n";
}

// Step 6: Try to access the individual article page
echo "\nStep 6: Attempting to access individual article page...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://localhost:8080/article/$testAlias");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    if (strpos($response, $testTitle) !== false && strpos($response, $testBody) !== false) {
        echo "✅ Individual article page loads with correct content\n";
    } else {
        echo "⚠️  Individual article page loads but content may be missing\n";
    }
} else {
    echo "❌ Individual article page failed to load (HTTP $httpCode)\n";
}

echo "\n=======================================\n";
echo "End-to-end workflow test completed!\n";
echo "=======================================\n";