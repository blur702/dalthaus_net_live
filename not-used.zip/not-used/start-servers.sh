#!/bin/bash

# Start PHP server on port 80 (HTTP)
echo "Starting HTTP server on port 80..."
sudo php -S 0.0.0.0:80 -t /Users/kevin/PhpstormProjects/dalthaus_net_live &
HTTP_PID=$!

# For HTTPS, we need a more complex setup
# PHP's built-in server doesn't support SSL
# You can use Apache, Nginx, or a tool like Caddy for HTTPS

echo "HTTP Server running on: http://localhost"
echo "For HTTPS, consider using:"
echo "  1. Apache with mod_ssl"
echo "  2. Nginx with SSL"  
echo "  3. Caddy server (automatic HTTPS)"
echo ""
echo "Press Ctrl+C to stop the server"

# Keep script running
wait $HTTP_PID