# Testing Guide

This document provides comprehensive information about testing the PHP/MySQL CMS, including setup, running tests, and contributing new tests.

## Table of Contents

- [Overview](#overview)
- [Setup](#setup)
- [Running Tests](#running-tests)
- [Test Structure](#test-structure)
- [Writing Tests](#writing-tests)
- [Test Coverage](#test-coverage)
- [CI/CD Integration](#cicd-integration)
- [Troubleshooting](#troubleshooting)

## Overview

The CMS includes a comprehensive PHPUnit test suite with:

- **Unit Tests**: Test individual components in isolation
- **Integration Tests**: Test component interactions and workflows
- **Feature Tests**: Test complete application features
- **Security Tests**: Test security measures and vulnerability prevention

### Test Statistics

- 15+ test classes covering all major components
- 100+ individual test methods
- Comprehensive fixtures and data seeders
- Full CI/CD integration with GitHub Actions

## Setup

### Requirements

- PHP 8.1+ with required extensions (PDO, SQLite, mbstring, json, fileinfo)
- Composer for dependency management
- SQLite for test database (in-memory)

### Installation

1. Install dependencies:
```bash
composer install
```

2. Set up test environment:
```bash
make setup
# or manually:
mkdir -p tests/{coverage,results,.cache,uploads}
chmod -R 775 tests/
```

3. Verify installation:
```bash
composer run-script test
```

## Running Tests

### Basic Commands

```bash
# Run all tests
composer test

# Run specific test suites
composer test-unit
composer test-integration
composer test-coverage

# Using Make
make test
make test-unit
make test-integration
make test-coverage
```

### Advanced Usage

```bash
# Run specific test class
./vendor/bin/phpunit tests/Unit/Models/UserTest.php

# Run tests with specific group
./vendor/bin/phpunit --group security

# Run tests with verbose output
./vendor/bin/phpunit --verbose

# Run tests matching pattern
./vendor/bin/phpunit --filter testUserCreation

# Generate coverage report
composer test-coverage
# Report available at tests/coverage/html/index.html
```

### Makefile Commands

```bash
make help           # Show all available commands
make test           # Run all tests
make test-unit      # Run unit tests only
make test-integration # Run integration tests only
make test-coverage  # Generate coverage report
make test-watch     # Run tests in watch mode
make quality        # Run all quality checks
```

## Test Structure

```
tests/
├── bootstrap.php           # Test bootstrap and setup
├── config/
│   └── test_config.php    # Test-specific configuration
├── Support/
│   ├── TestCase.php       # Base test class with utilities
│   ├── DatabaseTestCase.php # Database test base class
│   └── TestDataSeeder.php # Test data seeding utilities
├── Fixtures/
│   ├── UserFixture.php    # User test data
│   └── ContentFixture.php # Content test data
├── Unit/
│   ├── Models/            # Model unit tests
│   └── Utils/             # Utility class tests
├── Integration/           # Integration and workflow tests
├── Feature/              # Feature and end-to-end tests
├── coverage/             # Coverage reports (generated)
├── results/              # Test results (generated)
└── uploads/              # Test file uploads (temporary)
```

### Test Categories

#### Unit Tests (`tests/Unit/`)

Test individual components in isolation:

- **Models**: `UserTest.php`, `ContentTest.php`
- **Utilities**: `DatabaseTest.php`, `AuthTest.php`, `SecurityTest.php`

#### Integration Tests (`tests/Integration/`)

Test component interactions and complete workflows:

- **AdminAuthenticationFlowTest**: Complete admin authentication workflow
- **ContentManagementWorkflowTest**: Content CRUD operations and workflows
- **FileUploadSecurityTest**: File upload security and validation

## Writing Tests

### Test Naming Conventions

- Test files: `ClassNameTest.php`
- Test methods: `testMethodName()` or `testFeatureDescription()`
- Test data: Use descriptive variable names
- Assertions: Use specific assertion methods

### Example Unit Test

```php
<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use Tests\Support\DatabaseTestCase;
use CMS\Models\User;

class UserTest extends DatabaseTestCase
{
    public function testUserCreation(): void
    {
        $userData = [
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => 'securepassword'
        ];

        $user = User::createUser($userData);
        
        $this->assertInstanceOf(User::class, $user);
        $this->assertEquals('testuser', $user->getAttribute('username'));
        $this->assertTrue($user->verifyPassword('securepassword'));
    }
}
```

### Example Integration Test

```php
<?php

declare(strict_types=1);

namespace Tests\Integration;

use Tests\Support\DatabaseTestCase;
use CMS\Utils\Auth;

class AuthenticationFlowTest extends DatabaseTestCase
{
    public function testCompleteLoginWorkflow(): void
    {
        // Step 1: Create user
        $user = $this->createTestUser([
            'username' => 'testuser',
            'password_hash' => password_hash('password', PASSWORD_DEFAULT)
        ]);

        // Step 2: Attempt login
        $auth = new Auth($this->db, []);
        $result = $auth->attempt('testuser', 'password');
        
        // Step 3: Verify session
        $this->assertTrue($result);
        $this->assertTrue($auth->check());
        $this->assertEquals($user['user_id'], $auth->id());
    }
}
```

### Using Test Fixtures

```php
use Tests\Fixtures\UserFixture;
use Tests\Fixtures\ContentFixture;

class MyTest extends DatabaseTestCase
{
    public function testWithFixtures(): void
    {
        $userFixture = new UserFixture();
        $contentFixture = new ContentFixture();
        
        // Generate test data
        $userData = $userFixture->generateUser(['username' => 'testuser']);
        $contentData = $contentFixture->generateArticle(['user_id' => 1]);
        
        // Use in tests...
    }
}
```

### Database Testing

```php
class DatabaseTest extends DatabaseTestCase
{
    public function testDatabaseOperation(): void
    {
        // Create test data
        $user = $this->createTestUser(['username' => 'dbtest']);
        
        // Test database assertions
        $this->assertDatabaseHas('users', ['username' => 'dbtest']);
        
        // Delete and verify
        User::find($user['user_id'])->delete();
        $this->assertDatabaseMissing('users', ['user_id' => $user['user_id']]);
    }
}
```

### Testing Security

```php
public function testXssProtection(): void
{
    $maliciousInput = '<script>alert("xss")</script>';
    $sanitized = Security::sanitize($maliciousInput);
    
    $this->assertStringNotContainsString('<script>', $sanitized);
    $this->assertStringContainsString('&lt;script&gt;', $sanitized);
}
```

### Best Practices

1. **Test Independence**: Each test should be able to run independently
2. **Clear Assertions**: Use specific assertion methods with descriptive messages
3. **Test Data**: Use fixtures and factories for consistent test data
4. **Edge Cases**: Test boundary conditions and error scenarios
5. **Security**: Include security-focused tests for all user inputs
6. **Performance**: Group performance tests with `@group performance`

## Test Coverage

### Generating Reports

```bash
# Generate HTML coverage report
composer test-coverage

# View report
open tests/coverage/html/index.html
```

### Coverage Targets

- **Overall Coverage**: >90%
- **Models**: >95%
- **Controllers**: >85%
- **Utilities**: >95%
- **Critical Security Functions**: 100%

### Excluding Files

Coverage exclusions are configured in `phpunit.xml`:

```xml
<coverage>
    <exclude>
        <directory>src/Views</directory>
        <file>src/Models/BaseModel.php</file>
    </exclude>
</coverage>
```

## CI/CD Integration

### GitHub Actions

The project includes comprehensive CI/CD with GitHub Actions:

- **Multi-PHP Testing**: Tests against PHP 8.1, 8.2, 8.3
- **Code Quality**: PHPStan, Psalm, PHP_CodeSniffer
- **Security**: Security checker and vulnerability scanning
- **Coverage**: Automatic coverage reporting to Codecov
- **Deployment**: Staging and production deployment workflows

### Pipeline Stages

1. **Code Quality**: Linting, static analysis, security checks
2. **Testing**: Unit, integration, and feature tests
3. **Coverage**: Generate and upload coverage reports
4. **Deployment**: Automatic deployment on successful builds

### Local CI Simulation

```bash
# Run complete CI pipeline locally
make ci

# Individual stages
make cs-check
make analyse
make security
make test
```

## Troubleshooting

### Common Issues

#### Permission Errors
```bash
# Fix test directory permissions
chmod -R 775 tests/
```

#### Memory Issues
```bash
# Increase memory limit
php -d memory_limit=512M vendor/bin/phpunit
```

#### Database Issues
```bash
# Reset test database
make db-reset
```

#### Coverage Not Generated
```bash
# Ensure Xdebug is installed
php -m | grep xdebug

# Or install Xdebug
# For Ubuntu/Debian:
sudo apt-get install php-xdebug
# For macOS with Homebrew:
brew install php-xdebug
```

### Environment Issues

#### SQLite Not Found
```bash
# Install SQLite extension
# Ubuntu/Debian:
sudo apt-get install php-sqlite3
# macOS:
brew install php-sqlite
```

#### Composer Issues
```bash
# Clear Composer cache
composer clear-cache

# Reinstall dependencies
rm -rf vendor/
composer install
```

### Test-Specific Issues

#### Failing Authentication Tests
- Check session configuration in test config
- Verify password hashing is consistent
- Ensure session data is properly cleaned between tests

#### File Upload Test Failures
- Check upload directory permissions
- Verify test upload directory exists and is writable
- Ensure temporary files are properly cleaned up

#### Database Test Failures
- Verify SQLite extension is installed
- Check test database setup in bootstrap
- Ensure transactions are properly handled

### Debug Mode

Enable verbose test output:

```bash
# Run tests with debug output
./vendor/bin/phpunit --debug --verbose

# Show test progress
./vendor/bin/phpunit --verbose --testdox
```

### Performance Testing

```bash
# Run performance benchmarks
make benchmark

# Profile specific tests
./vendor/bin/phpunit --group performance --verbose
```

## Contributing Tests

### Adding New Tests

1. Follow existing test structure and naming conventions
2. Include both positive and negative test cases
3. Add appropriate fixtures for test data
4. Update this documentation if adding new test categories
5. Ensure all tests pass before submitting PR

### Test Review Checklist

- [ ] Tests are properly categorized (Unit/Integration/Feature)
- [ ] Test methods have descriptive names
- [ ] Edge cases and error conditions are tested
- [ ] Security implications are considered
- [ ] Test data uses fixtures when appropriate
- [ ] Tests are independent and can run in any order
- [ ] Coverage target is maintained or improved

---

For more information about specific testing patterns or help with writing tests, please refer to the existing test files as examples or open an issue for discussion.