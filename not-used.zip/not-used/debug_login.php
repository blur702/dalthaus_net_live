<?php

/**
 * Debug Login Process
 * 
 * This script helps debug the admin login process step by step
 */

class LoginDebugger
{
    private string $baseUrl;
    private string $adminUser;
    private string $adminPassword;
    private array $cookies = [];

    public function __construct(string $baseUrl = 'http://localhost', string $adminUser = 'kevin', string $adminPassword = 'admin123')
    {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->adminUser = $adminUser;
        $this->adminPassword = $adminPassword;
    }

    public function debugLoginProcess(): void
    {
        echo "LOGIN DEBUG PROCESS\n";
        echo str_repeat("=", 50) . "\n\n";

        // Step 1: Check database user
        $this->checkDatabaseUser();

        // Step 2: Get login form
        echo "STEP 2: Getting login form\n";
        echo str_repeat("-", 30) . "\n";
        
        $loginFormResponse = $this->makeRequest('GET', '/admin/login');
        echo "Status: {$loginFormResponse['http_code']}\n";
        echo "Cookies received: " . count($this->cookies) . "\n";
        foreach ($this->cookies as $cookie) {
            echo "  - $cookie\n";
        }

        // Extract CSRF token
        $csrfToken = '';
        if (preg_match('/name="_token"\s+value="([^"]+)"/', $loginFormResponse['body'], $matches)) {
            $csrfToken = $matches[1];
            echo "CSRF Token found: $csrfToken\n";
        } else {
            echo "❌ No CSRF token found in form!\n";
            echo "Form HTML preview:\n";
            echo substr($loginFormResponse['body'], 0, 1000) . "\n";
        }

        echo "\n";

        // Step 3: Attempt login
        echo "STEP 3: Attempting login\n";
        echo str_repeat("-", 30) . "\n";
        echo "Username: {$this->adminUser}\n";
        echo "Password: [hidden]\n";
        echo "CSRF Token: $csrfToken\n";

        $loginData = [
            'username' => $this->adminUser,
            'password' => $this->adminPassword,
            '_token' => $csrfToken
        ];

        $loginResponse = $this->makeRequest('POST', '/admin/login', $loginData);
        echo "Login POST status: {$loginResponse['http_code']}\n";
        
        // Check redirect location
        if (preg_match('/Location:\s*(.+)/i', $loginResponse['headers'], $matches)) {
            $redirectUrl = trim($matches[1]);
            echo "Redirect URL: $redirectUrl\n";
        }

        echo "Response headers:\n";
        echo $loginResponse['headers'] . "\n";

        echo "Cookies after login: " . count($this->cookies) . "\n";
        foreach ($this->cookies as $cookie) {
            echo "  - $cookie\n";
        }

        // Step 4: Try to access dashboard
        echo "\nSTEP 4: Testing dashboard access\n";
        echo str_repeat("-", 30) . "\n";
        
        $dashboardResponse = $this->makeRequest('GET', '/admin/dashboard');
        echo "Dashboard status: {$dashboardResponse['http_code']}\n";
        echo "Response length: " . strlen($dashboardResponse['body']) . "\n";

        if ($dashboardResponse['http_code'] === 302) {
            if (preg_match('/Location:\s*(.+)/i', $dashboardResponse['headers'], $matches)) {
                $redirectUrl = trim($matches[1]);
                echo "Dashboard redirects to: $redirectUrl\n";
            }
        }

        if (strlen($dashboardResponse['body']) > 0) {
            echo "Response preview:\n";
            echo substr($dashboardResponse['body'], 0, 500) . "\n";
        }
    }

    private function checkDatabaseUser(): void
    {
        echo "STEP 1: Checking database user\n";
        echo str_repeat("-", 30) . "\n";
        
        $result = shell_exec("mysql -h localhost -u root cms_db -e \"SELECT user_id, username, email, password_hash FROM users WHERE username = 'kevin';\" 2>/dev/null");
        
        if ($result) {
            echo "Database user found:\n";
            echo $result;
            
            // Check password hash
            $passwordCheck = shell_exec("mysql -h localhost -u root cms_db -e \"SELECT username, SUBSTRING(password_hash, 1, 20) as hash_preview FROM users WHERE username = 'kevin';\" 2>/dev/null");
            echo "\nPassword hash preview:\n";
            echo $passwordCheck;
        } else {
            echo "❌ Could not query database or user not found\n";
        }
        echo "\n";
    }

    private function makeRequest(string $method, string $path, array $data = []): array
    {
        $url = $this->baseUrl . $path;
        
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Login-Debugger/1.0',
            CURLOPT_HEADER => true,
        ]);
        
        if (!empty($this->cookies)) {
            curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $this->cookies));
        }
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if (!empty($data)) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/x-www-form-urlencoded'
                ]);
            }
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($response === false) {
            return [
                'http_code' => 0,
                'headers' => '',
                'body' => 'cURL Error: ' . $error
            ];
        }
        
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);
        
        // Extract cookies
        if (preg_match_all('/^Set-Cookie:\s*([^;\r\n]+)/mi', $headers, $matches)) {
            foreach ($matches[1] as $cookie) {
                $cookieName = explode('=', $cookie)[0];
                $this->cookies = array_filter($this->cookies, function($c) use ($cookieName) {
                    return !str_starts_with($c, $cookieName . '=');
                });
                $this->cookies[] = $cookie;
            }
        }
        
        return [
            'http_code' => $httpCode,
            'headers' => $headers,
            'body' => $body
        ];
    }
}

$debugger = new LoginDebugger('http://localhost', 'kevin', 'admin123');
$debugger->debugLoginProcess();