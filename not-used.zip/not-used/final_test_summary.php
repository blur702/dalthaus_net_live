<?php
// Final Test Summary Report
$tests = [];
$passed = 0;
$failed = 0;

// Test 1: Public pages
$publicPages = [
    '/' => 'Homepage',
    '/articles' => 'Articles',
    '/photobooks' => 'Photobooks'
];

foreach ($publicPages as $url => $name) {
    $ch = curl_init("http://localhost:8000$url");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 5
    ]);
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($code === 200) {
        $tests[] = "✅ $name: PASS";
        $passed++;
    } else {
        $tests[] = "❌ $name: FAIL (HTTP $code)";
        $failed++;
    }
}

// Test 2: Admin authentication
$ch = curl_init("http://localhost:8000/admin/login");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 5
]);
$response = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($code === 200) {
    $tests[] = "✅ Admin login page: PASS";
    $passed++;
} else {
    $tests[] = "❌ Admin login page: FAIL (HTTP $code)";
    $failed++;
}

// Test 3: Static analysis
exec('php -l src/Controllers/Admin/Dashboard.php 2>&1', $output, $returnCode);
if ($returnCode === 0) {
    $tests[] = "✅ Dashboard syntax: PASS";
    $passed++;
} else {
    $tests[] = "❌ Dashboard syntax: FAIL";
    $failed++;
}

exec('php -l src/Controllers/Admin/Pages.php 2>&1', $output, $returnCode);
if ($returnCode === 0) {
    $tests[] = "✅ Pages controller syntax: PASS";
    $passed++;
} else {
    $tests[] = "❌ Pages controller syntax: FAIL";
    $failed++;
}

// Test 4: Database connection
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config/config.php';
try {
    $db = \CMS\Utils\Database::getInstance();
    $tests[] = "✅ Database connection: PASS";
    $passed++;
} catch (Exception $e) {
    $tests[] = "❌ Database connection: FAIL";
    $failed++;
}

// Print results
echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 FINAL TEST SUMMARY REPORT\n";
echo str_repeat("=", 50) . "\n\n";

foreach ($tests as $test) {
    echo "$test\n";
}

echo "\n" . str_repeat("-", 50) . "\n";
$total = $passed + $failed;
$percentage = $total > 0 ? round(($passed / $total) * 100, 2) : 0;
echo "✅ Tests Passed: $passed\n";
echo "❌ Tests Failed: $failed\n";
echo "📈 Success Rate: {$percentage}%\n";
echo str_repeat("=", 50) . "\n";

if ($percentage >= 85) {
    echo "🎉 OVERALL STATUS: PRODUCTION READY\n";
} elseif ($percentage >= 70) {
    echo "⚠️ OVERALL STATUS: MOSTLY FUNCTIONAL\n";
} else {
    echo "🚨 OVERALL STATUS: NEEDS FIXES\n";
}
echo str_repeat("=", 50) . "\n";
