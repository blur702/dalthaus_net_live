<?php

// Test admin login functionality
$url = 'http://localhost:8080/admin/login';

echo "Testing admin login page...\n";

// Test 1: Check if login page loads
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo "CURL Error: $error\n";
    exit(1);
}

echo "HTTP Status Code: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Login page loads successfully\n";
    
    // Check if login form elements are present
    if (strpos($response, 'name="username"') !== false) {
        echo "✅ Username field found\n";
    } else {
        echo "❌ Username field not found\n";
    }
    
    if (strpos($response, 'name="password"') !== false) {
        echo "✅ Password field found\n";
    } else {
        echo "❌ Password field not found\n";
    }
    
    if (strpos($response, 'name="_token"') !== false) {
        echo "✅ CSRF token field found\n";
    } else {
        echo "❌ CSRF token field not found\n";
    }
    
} else {
    echo "❌ Login page failed to load\n";
    echo "Response: " . substr($response, 0, 500) . "...\n";
}

echo "\nTesting complete!\n";