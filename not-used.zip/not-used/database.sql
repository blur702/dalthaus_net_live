-- ============================================================================
-- CMS Database Schema
-- Created: 2025-09-06
-- Description: Complete database schema for PHP/MySQL CMS
-- ============================================================================

-- Drop tables if they exist (for clean reinstall)
DROP TABLE IF EXISTS `menu_items`;
DROP TABLE IF EXISTS `menus`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `pages`;
DROP TABLE IF EXISTS `content`;
DROP TABLE IF EXISTS `users`;

-- Create users table
CREATE TABLE `users` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL UNIQUE,
    `email` varchar(100) NOT NULL UNIQUE,
    `password_hash` varchar(255) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    INDEX `idx_username` (`username`),
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create content table (for articles and photobooks)
CREATE TABLE `content` (
    `content_id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `content_type` enum('article','photobook') NOT NULL,
    `status` enum('published','draft') NOT NULL DEFAULT 'draft',
    `title` varchar(255) NOT NULL,
    `url_alias` varchar(255) NOT NULL UNIQUE,
    `teaser` text,
    `body` longtext,
    `featured_image` varchar(255) DEFAULT NULL,
    `teaser_image` varchar(255) DEFAULT NULL,
    `process_document` varchar(255) DEFAULT NULL,
    `meta_keywords` varchar(500) DEFAULT NULL,
    `meta_description` varchar(500) DEFAULT NULL,
    `sort_order` int(11) NOT NULL DEFAULT 0,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `published_at` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`content_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
    UNIQUE KEY `idx_url_alias` (`url_alias`),
    INDEX `idx_content_type` (`content_type`),
    INDEX `idx_status` (`status`),
    INDEX `idx_sort_order` (`sort_order`),
    INDEX `idx_published_at` (`published_at`),
    INDEX `idx_content_type_status` (`content_type`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create pages table (for static pages)
CREATE TABLE `pages` (
    `page_id` int(11) NOT NULL AUTO_INCREMENT,
    `title` varchar(255) NOT NULL,
    `url_alias` varchar(255) NOT NULL UNIQUE,
    `body` longtext,
    `meta_keywords` varchar(500) DEFAULT NULL,
    `meta_description` varchar(500) DEFAULT NULL,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`page_id`),
    UNIQUE KEY `idx_url_alias` (`url_alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create settings table (key-value store)
CREATE TABLE `settings` (
    `setting_id` int(11) NOT NULL AUTO_INCREMENT,
    `setting_name` varchar(100) NOT NULL UNIQUE,
    `setting_value` text,
    PRIMARY KEY (`setting_id`),
    UNIQUE KEY `idx_setting_name` (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create menus table (navigation groups)
CREATE TABLE `menus` (
    `menu_id` int(11) NOT NULL AUTO_INCREMENT,
    `menu_name` varchar(100) NOT NULL UNIQUE,
    PRIMARY KEY (`menu_id`),
    UNIQUE KEY `idx_menu_name` (`menu_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create menu_items table (individual links within menus)
CREATE TABLE `menu_items` (
    `item_id` int(11) NOT NULL AUTO_INCREMENT,
    `menu_id` int(11) NOT NULL,
    `label` varchar(100) NOT NULL,
    `link` varchar(255) NOT NULL,
    `parent_id` int(11) DEFAULT NULL,
    `sort_order` int(11) NOT NULL DEFAULT 0,
    PRIMARY KEY (`item_id`),
    FOREIGN KEY (`menu_id`) REFERENCES `menus` (`menu_id`) ON DELETE CASCADE,
    FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`item_id`) ON DELETE CASCADE,
    INDEX `idx_menu_id` (`menu_id`),
    INDEX `idx_parent_id` (`parent_id`),
    INDEX `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Insert default data
-- ============================================================================

-- Insert default admin user (username: kevin, password: (130Bpm))
INSERT INTO `users` (`username`, `email`, `password_hash`) VALUES 
('kevin', 'kevin@example.com', '$2y$12$DQhd8QJK7M8wFSKvMbKIqOGZqUbK9sJPcZ7VxFqLWMn5mTcUeX/Ey');

-- Insert default site settings
INSERT INTO `settings` (`setting_name`, `setting_value`) VALUES 
('site_title', 'My CMS'),
('site_motto', 'A Simple Content Management System'),
('site_logo', ''),
('favicon', ''),
('admin_email', 'kevin@example.com'),
('timezone', 'America/New_York'),
('date_format', 'Y-m-d'),
('items_per_page', '10');

-- Insert default main menu
INSERT INTO `menus` (`menu_name`) VALUES ('main');

-- Insert default menu items
INSERT INTO `menu_items` (`menu_id`, `label`, `link`, `sort_order`) VALUES 
(1, 'Home', '/', 1),
(1, 'Articles', '/articles', 2),
(1, 'Photobooks', '/photobooks', 3);

-- ============================================================================
-- Create indexes for better performance
-- ============================================================================

-- Additional composite indexes for common queries
CREATE INDEX `idx_content_type_status_sort` ON `content` (`content_type`, `status`, `sort_order`);
CREATE INDEX `idx_content_published_sort` ON `content` (`status`, `published_at`, `sort_order`);

-- ============================================================================
-- End of Schema
-- ============================================================================