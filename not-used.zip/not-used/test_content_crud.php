<?php

// Test admin content CRUD operations
echo "Testing admin content CRUD operations...\n";

// Test content listing page
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Content listing HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Content listing page loads successfully\n";
    
    // Check for content management elements
    if (strpos($response, 'Create') !== false || strpos($response, 'Add') !== false) {
        echo "✅ Create content button found\n";
    }
    
    if (strpos($response, 'Article') !== false || strpos($response, 'Content') !== false) {
        echo "✅ Content type references found\n";
    }
    
} else {
    echo "❌ Content listing failed to load\n";
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

// Test content creation page
echo "\nTesting content creation page...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/content/create');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Content creation HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Content creation page loads successfully\n";
    
    // Check for form elements
    if (strpos($response, 'name="title"') !== false) {
        echo "✅ Title field found\n";
    } else {
        echo "❌ Title field not found\n";
    }
    
    if (strpos($response, 'name="content_type"') !== false) {
        echo "✅ Content type field found\n";
    } else {
        echo "❌ Content type field not found\n";
    }
    
    if (strpos($response, 'name="body"') !== false) {
        echo "✅ Body field found\n";
    } else {
        echo "❌ Body field not found\n";
    }
    
} else {
    echo "❌ Content creation page failed to load\n";
    echo "Response preview: " . substr($response, 0, 500) . "...\n";
}

// Test pages listing
echo "\nTesting pages management...\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/pages');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Pages listing HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    echo "✅ Pages listing page loads successfully\n";
} else {
    echo "❌ Pages listing failed to load\n";
}

echo "\nCRUD operations test complete!\n";