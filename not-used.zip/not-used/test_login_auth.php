<?php

// Test admin login authentication
echo "Testing admin login authentication...\n";

// First get the login page to extract CSRF token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');

$response = curl_exec($ch);
curl_close($ch);

// Extract CSRF token
preg_match('/name="_token" value="([^"]+)"/', $response, $matches);
if (!isset($matches[1])) {
    echo "❌ Could not extract CSRF token\n";
    exit(1);
}

$csrf_token = $matches[1];
echo "✅ CSRF token extracted: " . substr($csrf_token, 0, 16) . "...\n";

// Now attempt login
$postData = [
    'username' => 'kevin',
    'password' => '(130Bpm)',
    '_token' => $csrf_token
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$redirectLocation = curl_getinfo($ch, CURLINFO_REDIRECT_URL);

curl_close($ch);

echo "Login attempt HTTP Status: $httpCode\n";

if ($httpCode === 302) {
    echo "✅ Login redirect occurred\n";
    echo "Redirect location: $redirectLocation\n";
    
    if (strpos($redirectLocation, '/admin/dashboard') !== false) {
        echo "✅ Redirected to dashboard - login successful!\n";
    } else if (strpos($redirectLocation, '/admin/login') !== false) {
        echo "❌ Redirected back to login - login failed\n";
        
        // Get login page again to see error message
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://localhost:8080/admin/login');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
        
        $errorResponse = curl_exec($ch);
        curl_close($ch);
        
        // Look for error messages
        if (preg_match('/bg-red-50[^>]*>([^<]+)/', $errorResponse, $errorMatches)) {
            echo "Error message: " . trim($errorMatches[1]) . "\n";
        }
    }
} else {
    echo "❌ Unexpected response code: $httpCode\n";
    echo "Response: " . substr($response, 0, 500) . "...\n";
}

echo "\nAuthentication test complete!\n";