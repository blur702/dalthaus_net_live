# Security Implementation Guide

## Quick Start - Immediate Security Fixes

### 1. Apply Critical Security Patches

```bash
# Apply database security updates
mysql -u cms_user -p cms_db < database_security_updates.sql

# Set proper file permissions
chmod 644 .htaccess
chmod 644 uploads/.htaccess
chmod 755 uploads/
chmod 600 config/config.php

# Create required directories
mkdir -p logs
mkdir -p cache/views
mkdir -p quarantine
chmod 755 logs cache quarantine
```

### 2. Update Configuration for Production

```bash
# Backup current config
cp config/config.php config/config.backup.php

# Use production config
cp config/config.production.php config/config.php

# Edit config/config.php and update:
# - Database credentials
# - Set debug to false
# - Enable secure_cookies for HTTPS
# - Update base_url to your domain
```

### 3. Environment Variables Setup

Create a `.env` file in the root directory (outside web root in production):

```bash
# Database
DB_HOST=localhost
DB_NAME=cms_db
DB_USER=cms_user
DB_PASSWORD=your_secure_password

# Email
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=email@example.com
SMTP_PASSWORD=email_password
SMTP_ENCRYPTION=tls
FROM_EMAIL=noreply@example.com
ADMIN_EMAIL=admin@example.com

# API Keys
TINYMCE_API_KEY=your_tinymce_key

# Security
BACKUP_ENCRYPTION_KEY=your_32_character_key
ERROR_EMAIL=security@example.com
```

## Implementation Checklist

### Phase 1: Immediate (Critical Security)

- [x] **File Upload Security**
  - Created secure .htaccess in uploads directory
  - Implemented FileUpload.php with comprehensive validation
  - Added MIME type checking and image reprocessing

- [x] **Security Headers**
  - Updated .htaccess with CSP headers
  - Added X-Frame-Options, X-Content-Type-Options
  - Configured Referrer-Policy and Permissions-Policy

- [x] **Database Security Tables**
  - Created login_attempts table
  - Created audit_logs table
  - Added security fields to users table

### Phase 2: Short-term (Within 1 Week)

- [ ] **Session Security**
  ```php
  // Update config/config.php for production
  'secure_cookies' => true, // Enable for HTTPS
  ```

- [ ] **Implement Audit Logging**
  ```php
  // Add to all admin controllers
  $this->auditLog('content_created', 'content', $contentId, $details);
  ```

- [ ] **Password Policy Enhancement**
  ```php
  // Update minimum password length in config
  'password_min_length' => 12,
  ```

- [ ] **Rate Limiting Database Storage**
  - Migrate from session-based to database-based tracking
  - Implement IP blocking for repeated failures

### Phase 3: Medium-term (Within 1 Month)

- [ ] **Two-Factor Authentication**
  - Implement TOTP-based 2FA
  - Add backup codes
  - Update login flow

- [ ] **Password Reset Feature**
  - Implement secure token generation
  - Add email verification
  - Set token expiration

- [ ] **Enhanced Input Validation**
  - Create validation middleware
  - Implement request filtering
  - Add OWASP input validation

### Phase 4: Long-term (Within 3 Months)

- [ ] **Security Monitoring Dashboard**
  - Real-time threat detection
  - Failed login tracking
  - Suspicious activity alerts

- [ ] **Automated Security Testing**
  - Implement PHPUnit security tests
  - Add OWASP ZAP scanning
  - Regular dependency scanning

## File Upload Security Implementation

### Using the New Secure Upload Handler

Replace existing upload code with:

```php
use CMS\Utils\FileUpload;

// Initialize uploader
$uploader = new FileUpload([
    'upload_path' => '/path/to/uploads/',
    'reprocess_images' => true,
    'strip_metadata' => true
]);

// Handle upload
$result = $uploader->upload($_FILES['image']);

if ($result['success']) {
    $filename = $result['filename'];
    // Save to database
} else {
    $error = $result['error'];
    // Handle error
}
```

## Authentication Security Implementation

### Login with Enhanced Security

```php
use CMS\Utils\Auth;

// In your login controller
$auth = new Auth($db, $config['security']);

// Check for IP blocking
$ip = $_SERVER['REMOTE_ADDR'];
$stmt = $db->prepare("SELECT * FROM blocked_ips WHERE ip_address = ? AND (blocked_until IS NULL OR blocked_until > NOW())");
$stmt->execute([$ip]);
if ($stmt->fetch()) {
    die('Your IP has been blocked.');
}

// Attempt login
if ($auth->attempt($username, $password)) {
    // Log successful login
    $db->insert('login_attempts', [
        'identifier' => $username,
        'ip_address' => $ip,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'success' => 1
    ]);
    
    // Audit log
    $db->insert('audit_logs', [
        'user_id' => $auth->id(),
        'action' => 'login',
        'ip_address' => $ip
    ]);
} else {
    // Log failed attempt
    $db->insert('login_attempts', [
        'identifier' => $username,
        'ip_address' => $ip,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'success' => 0
    ]);
}
```

## Security Testing Checklist

### Manual Testing

1. **SQL Injection Testing**
   - Test all input fields with: `' OR '1'='1`
   - Verify prepared statements are working

2. **XSS Testing**
   - Test with: `<script>alert('XSS')</script>`
   - Verify output encoding

3. **File Upload Testing**
   - Try uploading PHP files with image extensions
   - Test double extensions (file.php.jpg)
   - Verify MIME type validation

4. **Authentication Testing**
   - Test brute force protection
   - Verify session timeout
   - Check CSRF token validation

### Automated Testing Tools

```bash
# Install security testing tools
composer require --dev phpstan/phpstan
composer require --dev vimeo/psalm

# Run static analysis
vendor/bin/phpstan analyse src/
vendor/bin/psalm

# OWASP Dependency Check
# Download from: https://owasp.org/www-project-dependency-check/
dependency-check --project "CMS" --scan .
```

## Monitoring and Maintenance

### Daily Tasks

1. Review audit logs for suspicious activity
2. Check failed login attempts
3. Monitor disk space in uploads directory

### Weekly Tasks

1. Review security event logs
2. Update blocked IP list
3. Run security scans

### Monthly Tasks

1. Update dependencies
2. Review and rotate logs
3. Test backup restoration
4. Security audit review

## Emergency Response Procedures

### If You Detect a Breach

1. **Immediate Actions**
   ```bash
   # Enable maintenance mode
   touch maintenance.flag
   
   # Block all admin access except your IP
   echo "your.ip.address" > allowed_ips.txt
   ```

2. **Preserve Evidence**
   ```bash
   # Backup logs
   tar -czf logs_backup_$(date +%Y%m%d).tar.gz logs/
   
   # Capture current state
   mysqldump cms_db > db_backup_$(date +%Y%m%d).sql
   ```

3. **Investigate**
   - Review audit_logs table
   - Check login_attempts for patterns
   - Analyze access logs

4. **Remediate**
   - Change all passwords
   - Regenerate API keys
   - Review and patch vulnerability
   - Update security configurations

## Security Contacts

- **Security Issues**: security@yourdomain.com
- **CERT/CSIRT**: Contact your local CERT
- **Legal**: Your legal counsel
- **Hosting Provider**: Your hosting support

## Additional Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [PHP Security Guide](https://phpsecurity.readthedocs.io/)
- [CWE/SANS Top 25](https://cwe.mitre.org/top25/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)

## Regular Security Audit Schedule

- **Weekly**: Review logs and failed logins
- **Monthly**: Dependency updates and security patches
- **Quarterly**: Full security audit
- **Annually**: Penetration testing

Remember: Security is an ongoing process, not a one-time implementation. Stay vigilant and keep your system updated.