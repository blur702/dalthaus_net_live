<?php
/**
 * Modular E2E Test Runner - Tests components individually for better debugging
 */

class ModularE2ETest {
    private $baseUrl = 'http://localhost:8000';
    private $cookieFile;
    private $results = [];
    
    public function __construct() {
        $this->cookieFile = tempnam(sys_get_temp_dir(), 'test_cookies');
    }
    
    public function __destruct() {
        if (file_exists($this->cookieFile)) {
            unlink($this->cookieFile);
        }
    }
    
    private function request($url, $method = 'GET', $data = null) {
        $ch = curl_init();
        $fullUrl = strpos($url, 'http') === 0 ? $url : $this->baseUrl . $url;
        
        curl_setopt($ch, CURLOPT_URL, $fullUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookieFile);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5); // 5 second timeout per request
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        
        if ($method === 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        return ['code' => $code, 'body' => $body, 'error' => $error];
    }
    
    private function extractCsrfToken($html) {
        if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']+)["\']/', $html, $matches)) {
            return $matches[1];
        }
        return null;
    }
    
    public function testPublicPages() {
        echo "\n=== TESTING PUBLIC PAGES ===\n";
        $results = [];
        
        // Test homepage
        $response = $this->request('/');
        $results['homepage'] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Homepage: " . $results['homepage'] . "\n";
        
        // Test articles
        $response = $this->request('/articles');
        $results['articles'] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Articles: " . $results['articles'] . "\n";
        
        // Test photobooks
        $response = $this->request('/photobooks');
        $results['photobooks'] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Photobooks: " . $results['photobooks'] . "\n";
        
        // Test 404
        $response = $this->request('/nonexistent');
        $results['404'] = $response['code'] === 404 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "404 Page: " . $results['404'] . "\n";
        
        $this->results['public'] = $results;
        return $results;
    }
    
    public function testAuthentication() {
        echo "\n=== TESTING AUTHENTICATION ===\n";
        $results = [];
        
        // Login page
        $response = $this->request('/admin/login');
        $results['login_page'] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Login Page: " . $results['login_page'] . "\n";
        
        // Get CSRF token
        $token = $this->extractCsrfToken($response['body']);
        if (!$token) {
            $results['csrf_token'] = 'FAIL (No token found)';
            echo "CSRF Token: " . $results['csrf_token'] . "\n";
            return $results;
        }
        $results['csrf_token'] = 'PASS';
        echo "CSRF Token: PASS\n";
        
        // Try login
        $response = $this->request('/admin/login', 'POST', http_build_query([
            'username' => 'kevin',
            'password' => '(130Bpm)',
            '_token' => $token
        ]));
        
        $results['login'] = ($response['code'] === 302 || $response['code'] === 200) ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Login: " . $results['login'] . "\n";
        
        // Check dashboard access
        $response = $this->request('/admin/dashboard');
        $results['dashboard_access'] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
        echo "Dashboard Access: " . $results['dashboard_access'] . "\n";
        
        $this->results['auth'] = $results;
        return $results;
    }
    
    public function testAdminPages() {
        echo "\n=== TESTING ADMIN PAGES ===\n";
        $results = [];
        
        // Ensure we're logged in
        $this->login();
        
        $pages = [
            '/admin/dashboard' => 'Dashboard',
            '/admin/content' => 'Content List',
            '/admin/content/create' => 'Content Create',
            '/admin/pages' => 'Pages List',
            '/admin/pages/create' => 'Pages Create',
            '/admin/users' => 'Users List',
            '/admin/users/create' => 'Users Create',
            '/admin/menus' => 'Menus List',
            '/admin/settings' => 'Settings'
        ];
        
        foreach ($pages as $url => $name) {
            $response = $this->request($url);
            $results[$name] = $response['code'] === 200 ? 'PASS' : "FAIL (Code: {$response['code']})";
            echo "{$name}: " . $results[$name] . "\n";
        }
        
        $this->results['admin_pages'] = $results;
        return $results;
    }
    
    public function testCRUDOperations() {
        echo "\n=== TESTING CRUD OPERATIONS ===\n";
        $results = [];
        
        // Ensure we're logged in
        $this->login();
        
        // Test content creation
        $response = $this->request('/admin/content/create');
        $token = $this->extractCsrfToken($response['body']);
        
        if ($token) {
            $response = $this->request('/admin/content/store', 'POST', http_build_query([
                'title' => 'Test Article ' . time(),
                'content' => 'Test content',
                'type' => 'article',
                'status' => 'published',
                '_token' => $token
            ]));
            
            $results['content_create'] = ($response['code'] === 302 || $response['code'] === 200) ? 'PASS' : "FAIL (Code: {$response['code']})";
        } else {
            $results['content_create'] = 'FAIL (No CSRF token)';
        }
        echo "Content Create: " . $results['content_create'] . "\n";
        
        // Test page creation
        $response = $this->request('/admin/pages/create');
        $token = $this->extractCsrfToken($response['body']);
        
        if ($token) {
            $response = $this->request('/admin/pages/store', 'POST', http_build_query([
                'title' => 'Test Page ' . time(),
                'content' => 'Test page content',
                'status' => 'published',
                '_token' => $token
            ]));
            
            $results['page_create'] = ($response['code'] === 302 || $response['code'] === 200) ? 'PASS' : "FAIL (Code: {$response['code']})";
        } else {
            $results['page_create'] = 'FAIL (No CSRF token)';
        }
        echo "Page Create: " . $results['page_create'] . "\n";
        
        // Test user creation
        $response = $this->request('/admin/users/create');
        $token = $this->extractCsrfToken($response['body']);
        
        if ($token) {
            $response = $this->request('/admin/users/store', 'POST', http_build_query([
                'username' => 'testuser_' . time(),
                'email' => 'test' . time() . '@example.com',
                'password' => 'TestPass123!',
                'is_admin' => '0',
                '_token' => $token
            ]));
            
            $results['user_create'] = ($response['code'] === 302 || $response['code'] === 200) ? 'PASS' : "FAIL (Code: {$response['code']})";
        } else {
            $results['user_create'] = 'FAIL (No CSRF token)';
        }
        echo "User Create: " . $results['user_create'] . "\n";
        
        $this->results['crud'] = $results;
        return $results;
    }
    
    public function testSecurity() {
        echo "\n=== TESTING SECURITY ===\n";
        $results = [];
        
        // Test CSRF protection
        $response = $this->request('/admin/content/store', 'POST', http_build_query([
            'title' => 'No CSRF Test',
            'content' => 'Should fail'
        ]));
        $results['csrf_protection'] = ($response['code'] !== 200 || strpos($response['body'], 'success') === false) ? 'PASS' : 'FAIL (Accepted without token)';
        echo "CSRF Protection: " . $results['csrf_protection'] . "\n";
        
        // Test authentication requirement
        file_put_contents($this->cookieFile, ''); // Clear cookies
        $response = $this->request('/admin/dashboard');
        $results['auth_required'] = ($response['code'] !== 200 || strpos($response['body'], 'Dashboard') === false) ? 'PASS' : 'FAIL (Accessible without auth)';
        echo "Auth Required: " . $results['auth_required'] . "\n";
        
        // Test XSS protection (login and check)
        $this->login();
        $response = $this->request('/admin/content/create');
        $token = $this->extractCsrfToken($response['body']);
        
        if ($token) {
            $xssPayload = '<script>alert("XSS")</script>';
            $this->request('/admin/content/store', 'POST', http_build_query([
                'title' => 'XSS Test ' . time(),
                'content' => $xssPayload,
                'type' => 'article',
                'status' => 'published',
                '_token' => $token
            ]));
            
            $response = $this->request('/admin/content');
            $results['xss_protection'] = strpos($response['body'], '<script>alert') === false ? 'PASS' : 'FAIL (XSS not escaped)';
        } else {
            $results['xss_protection'] = 'SKIP (Could not test)';
        }
        echo "XSS Protection: " . $results['xss_protection'] . "\n";
        
        $this->results['security'] = $results;
        return $results;
    }
    
    private function login() {
        $response = $this->request('/admin/login');
        $token = $this->extractCsrfToken($response['body']);
        if ($token) {
            $this->request('/admin/login', 'POST', http_build_query([
                'username' => 'kevin',
                'password' => '(130Bpm)',
                '_token' => $token
            ]));
        }
    }
    
    public function generateReport() {
        echo "\n" . str_repeat('=', 60) . "\n";
        echo "TEST SUMMARY REPORT\n";
        echo str_repeat('=', 60) . "\n\n";
        
        $totalTests = 0;
        $passedTests = 0;
        
        foreach ($this->results as $category => $tests) {
            echo strtoupper($category) . ":\n";
            foreach ($tests as $test => $result) {
                $totalTests++;
                if (strpos($result, 'PASS') === 0) {
                    $passedTests++;
                    echo "  ✓ {$test}: {$result}\n";
                } else {
                    echo "  ✗ {$test}: {$result}\n";
                }
            }
            echo "\n";
        }
        
        $passRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 2) : 0;
        echo "Overall: {$passedTests}/{$totalTests} tests passed ({$passRate}%)\n";
        echo str_repeat('=', 60) . "\n";
        
        return ['total' => $totalTests, 'passed' => $passedTests, 'rate' => $passRate];
    }
    
    public function runAll() {
        echo "\nSTARTING MODULAR E2E TESTS\n";
        echo "Environment: {$this->baseUrl}\n";
        echo "Time: " . date('Y-m-d H:i:s') . "\n";
        
        $this->testPublicPages();
        $this->testAuthentication();
        $this->testAdminPages();
        $this->testCRUDOperations();
        $this->testSecurity();
        
        return $this->generateReport();
    }
}

// Run the tests
$tester = new ModularE2ETest();
$summary = $tester->runAll();

// Return appropriate exit code
exit($summary['passed'] === $summary['total'] ? 0 : 1);