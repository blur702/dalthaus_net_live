<?php
/**
 * Comprehensive End-to-End Test Suite for CMS Application
 * Tests all major functionality against running server at localhost:8000
 */

class ComprehensiveE2ETest {
    private $baseUrl = 'http://localhost:8000';
    private $cookieFile;
    private $testResults = [];
    private $failureDetails = [];
    private $totalTests = 0;
    private $passedTests = 0;
    private $failedTests = 0;
    private $sessionCookie = null;
    private $csrfToken = null;

    public function __construct() {
        $this->cookieFile = tempnam(sys_get_temp_dir(), 'test_cookies');
        echo "\n" . str_repeat('=', 80) . "\n";
        echo "COMPREHENSIVE E2E TEST SUITE FOR CMS APPLICATION\n";
        echo str_repeat('=', 80) . "\n\n";
        echo "Test Environment: {$this->baseUrl}\n";
        echo "Cookie File: {$this->cookieFile}\n";
        echo "Start Time: " . date('Y-m-d H:i:s') . "\n\n";
    }

    public function __destruct() {
        if (file_exists($this->cookieFile)) {
            unlink($this->cookieFile);
        }
    }

    /**
     * Execute HTTP request with cookie support
     */
    private function request($url, $method = 'GET', $data = null, $headers = []) {
        $ch = curl_init();
        
        $fullUrl = strpos($url, 'http') === 0 ? $url : $this->baseUrl . $url;
        
        curl_setopt($ch, CURLOPT_URL, $fullUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookieFile);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
        }
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        
        $header = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);
        
        curl_close($ch);
        
        return [
            'code' => $httpCode,
            'header' => $header,
            'body' => $body,
            'url' => $fullUrl
        ];
    }

    /**
     * Extract CSRF token from HTML
     */
    private function extractCsrfToken($html) {
        if (preg_match('/<input[^>]*name=["\']_token["\'][^>]*value=["\']([^"\']+)["\']/', $html, $matches)) {
            return $matches[1];
        }
        if (preg_match('/<meta[^>]*name=["\']csrf-token["\'][^>]*content=["\']([^"\']+)["\']/', $html, $matches)) {
            return $matches[1];
        }
        return null;
    }

    /**
     * Run a test and record results
     */
    private function runTest($category, $testName, $testFunction) {
        $this->totalTests++;
        echo "  Testing: {$testName}... ";
        
        try {
            $result = $testFunction();
            if ($result === true) {
                $this->passedTests++;
                $this->testResults[$category][$testName] = 'PASS';
                echo "\033[32mPASS\033[0m\n";
                return true;
            } else {
                $this->failedTests++;
                $this->testResults[$category][$testName] = 'FAIL';
                $this->failureDetails[$category][$testName] = is_string($result) ? $result : 'Test returned false';
                echo "\033[31mFAIL\033[0m - {$this->failureDetails[$category][$testName]}\n";
                return false;
            }
        } catch (Exception $e) {
            $this->failedTests++;
            $this->testResults[$category][$testName] = 'ERROR';
            $this->failureDetails[$category][$testName] = $e->getMessage();
            echo "\033[31mERROR\033[0m - {$e->getMessage()}\n";
            return false;
        }
    }

    /**
     * Test 1: Public Pages
     */
    public function testPublicPages() {
        echo "\n\033[1m1. TESTING PUBLIC PAGES\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // Test Homepage
        $this->runTest('Public Pages', 'Homepage Access', function() {
            $response = $this->request('/');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            if (strpos($response['body'], '<html') === false) {
                return "No HTML content found";
            }
            return true;
        });

        // Test Articles Page
        $this->runTest('Public Pages', 'Articles Listing', function() {
            $response = $this->request('/articles');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            if (strpos($response['body'], 'article') === false && strpos($response['body'], 'Article') === false) {
                return "No article-related content found";
            }
            return true;
        });

        // Test Photobooks Page
        $this->runTest('Public Pages', 'Photobooks Listing', function() {
            $response = $this->request('/photobooks');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            if (strpos($response['body'], 'photobook') === false && strpos($response['body'], 'Photobook') === false) {
                return "No photobook-related content found";
            }
            return true;
        });

        // Test 404 Error
        $this->runTest('Public Pages', '404 Error Page', function() {
            $response = $this->request('/non-existent-page-12345');
            if ($response['code'] !== 404) {
                return "Expected 404, got {$response['code']}";
            }
            return true;
        });
    }

    /**
     * Test 2: Admin Authentication
     */
    public function testAdminAuthentication() {
        echo "\n\033[1m2. TESTING ADMIN AUTHENTICATION\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // Test Login Page Access
        $this->runTest('Authentication', 'Login Page Access', function() {
            $response = $this->request('/admin/login');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            if (strpos($response['body'], 'username') === false || strpos($response['body'], 'password') === false) {
                return "Login form fields not found";
            }
            $this->csrfToken = $this->extractCsrfToken($response['body']);
            if (!$this->csrfToken) {
                return "CSRF token not found";
            }
            return true;
        });

        // Test Failed Login
        $this->runTest('Authentication', 'Invalid Login Attempt', function() {
            $response = $this->request('/admin/login');
            $token = $this->extractCsrfToken($response['body']);
            
            $response = $this->request('/admin/login', 'POST', http_build_query([
                'username' => 'invalid',
                'password' => 'wrong',
                '_token' => $token
            ]));
            
            if ($response['code'] === 200 && strpos($response['body'], 'dashboard') !== false) {
                return "Invalid login succeeded (security issue!)";
            }
            return true;
        });

        // Test Successful Login
        $this->runTest('Authentication', 'Valid Login', function() {
            $response = $this->request('/admin/login');
            $token = $this->extractCsrfToken($response['body']);
            
            $response = $this->request('/admin/login', 'POST', http_build_query([
                'username' => 'kevin',
                'password' => '(130Bpm)',
                '_token' => $token
            ]));
            
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect or success, got {$response['code']}";
            }
            
            // Verify we can access dashboard
            $dashResponse = $this->request('/admin/dashboard');
            if ($dashResponse['code'] !== 200) {
                return "Cannot access dashboard after login";
            }
            if (strpos($dashResponse['body'], 'Dashboard') === false && strpos($dashResponse['body'], 'dashboard') === false) {
                return "Dashboard content not found";
            }
            
            return true;
        });

        // Test Session Persistence
        $this->runTest('Authentication', 'Session Persistence', function() {
            $response = $this->request('/admin/dashboard');
            if ($response['code'] !== 200) {
                return "Session not persisted, got {$response['code']}";
            }
            return true;
        });
    }

    /**
     * Test 3: Admin Dashboard
     */
    public function testAdminDashboard() {
        echo "\n\033[1m3. TESTING ADMIN DASHBOARD\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        $this->runTest('Dashboard', 'Dashboard Statistics', function() {
            $response = $this->request('/admin/dashboard');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            // Check for common dashboard elements
            $hasStats = strpos($response['body'], 'Total') !== false || 
                       strpos($response['body'], 'Users') !== false ||
                       strpos($response['body'], 'Content') !== false ||
                       strpos($response['body'], 'Pages') !== false;
            
            if (!$hasStats) {
                return "Dashboard statistics not found";
            }
            return true;
        });

        $this->runTest('Dashboard', 'Navigation Menu', function() {
            $response = $this->request('/admin/dashboard');
            
            $hasNav = strpos($response['body'], 'Content') !== false &&
                     strpos($response['body'], 'Pages') !== false &&
                     strpos($response['body'], 'Users') !== false;
            
            if (!$hasNav) {
                return "Admin navigation menu incomplete";
            }
            return true;
        });
    }

    /**
     * Test 4: Content CRUD Operations
     */
    public function testContentCRUD() {
        echo "\n\033[1m4. TESTING CONTENT CRUD OPERATIONS\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // List Content
        $this->runTest('Content CRUD', 'List Content', function() {
            $response = $this->request('/admin/content');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            return true;
        });

        // Create Content Form
        $this->runTest('Content CRUD', 'Create Content Form', function() {
            $response = $this->request('/admin/content/create');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            if (strpos($response['body'], 'title') === false || strpos($response['body'], 'content') === false) {
                return "Content form fields not found";
            }
            return true;
        });

        // Create New Article
        $testArticleId = null;
        $this->runTest('Content CRUD', 'Create Article', function() use (&$testArticleId) {
            $response = $this->request('/admin/content/create');
            $token = $this->extractCsrfToken($response['body']);
            
            $testData = [
                'title' => 'Test Article ' . time(),
                'content' => 'This is test content created at ' . date('Y-m-d H:i:s'),
                'type' => 'article',
                'status' => 'published',
                'url_alias' => 'test-article-' . time(),
                '_token' => $token
            ];
            
            $response = $this->request('/admin/content/store', 'POST', http_build_query($testData));
            
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect after creation, got {$response['code']}";
            }
            
            // Verify article was created
            $listResponse = $this->request('/admin/content');
            if (strpos($listResponse['body'], $testData['title']) === false) {
                return "Created article not found in listing";
            }
            
            // Extract article ID for further tests
            if (preg_match('/content\/(\d+)\/edit.*?' . preg_quote($testData['title'], '/') . '/s', $listResponse['body'], $matches)) {
                $testArticleId = $matches[1];
            }
            
            return true;
        });

        // Edit Content
        if ($testArticleId) {
            $this->runTest('Content CRUD', 'Edit Article', function() use ($testArticleId) {
                $response = $this->request("/admin/content/{$testArticleId}/edit");
                if ($response['code'] !== 200) {
                    return "Expected 200, got {$response['code']}";
                }
                
                $token = $this->extractCsrfToken($response['body']);
                
                $updateData = [
                    'title' => 'Updated Test Article ' . time(),
                    'content' => 'Updated content at ' . date('Y-m-d H:i:s'),
                    'type' => 'article',
                    'status' => 'published',
                    '_token' => $token
                ];
                
                $response = $this->request("/admin/content/{$testArticleId}/update", 'POST', http_build_query($updateData));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after update, got {$response['code']}";
                }
                
                return true;
            });

            // Delete Content
            $this->runTest('Content CRUD', 'Delete Article', function() use ($testArticleId) {
                $response = $this->request('/admin/content');
                $token = $this->extractCsrfToken($response['body']);
                
                $response = $this->request("/admin/content/{$testArticleId}/delete", 'POST', http_build_query([
                    '_token' => $token
                ]));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after deletion, got {$response['code']}";
                }
                
                return true;
            });
        }
    }

    /**
     * Test 5: Page Management
     */
    public function testPageManagement() {
        echo "\n\033[1m5. TESTING PAGE MANAGEMENT\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // List Pages
        $this->runTest('Page Management', 'List Pages', function() {
            $response = $this->request('/admin/pages');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            return true;
        });

        // Create Page
        $testPageId = null;
        $this->runTest('Page Management', 'Create Page', function() use (&$testPageId) {
            $response = $this->request('/admin/pages/create');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            $token = $this->extractCsrfToken($response['body']);
            
            $pageData = [
                'title' => 'Test Page ' . time(),
                'content' => 'Test page content created at ' . date('Y-m-d H:i:s'),
                'url_alias' => 'test-page-' . time(),
                'status' => 'published',
                '_token' => $token
            ];
            
            $response = $this->request('/admin/pages/store', 'POST', http_build_query($pageData));
            
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect after creation, got {$response['code']}";
            }
            
            // Extract page ID
            $listResponse = $this->request('/admin/pages');
            if (preg_match('/pages\/(\d+)\/edit.*?' . preg_quote($pageData['title'], '/') . '/s', $listResponse['body'], $matches)) {
                $testPageId = $matches[1];
            }
            
            return true;
        });

        // Edit Page
        if ($testPageId) {
            $this->runTest('Page Management', 'Edit Page', function() use ($testPageId) {
                $response = $this->request("/admin/pages/{$testPageId}/edit");
                if ($response['code'] !== 200) {
                    return "Expected 200, got {$response['code']}";
                }
                
                $token = $this->extractCsrfToken($response['body']);
                
                $updateData = [
                    'title' => 'Updated Test Page ' . time(),
                    'content' => 'Updated page content at ' . date('Y-m-d H:i:s'),
                    'status' => 'published',
                    '_token' => $token
                ];
                
                $response = $this->request("/admin/pages/{$testPageId}/update", 'POST', http_build_query($updateData));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after update, got {$response['code']}";
                }
                
                return true;
            });

            // Delete Page
            $this->runTest('Page Management', 'Delete Page', function() use ($testPageId) {
                $response = $this->request('/admin/pages');
                $token = $this->extractCsrfToken($response['body']);
                
                $response = $this->request("/admin/pages/{$testPageId}/delete", 'POST', http_build_query([
                    '_token' => $token
                ]));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after deletion, got {$response['code']}";
                }
                
                return true;
            });
        }
    }

    /**
     * Test 6: Menu Management
     */
    public function testMenuManagement() {
        echo "\n\033[1m6. TESTING MENU MANAGEMENT\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // List Menus
        $this->runTest('Menu Management', 'List Menus', function() {
            $response = $this->request('/admin/menus');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            // Check for default menus
            $hasMenus = strpos($response['body'], 'main') !== false ||
                       strpos($response['body'], 'Main') !== false;
            
            if (!$hasMenus) {
                return "Default menus not found";
            }
            return true;
        });

        // Edit Menu
        $this->runTest('Menu Management', 'Edit Main Menu', function() {
            $response = $this->request('/admin/menus/1'); // Main menu ID is typically 1
            if ($response['code'] !== 200) {
                // Try alternate route
                $response = $this->request('/admin/menus/1/edit');
                if ($response['code'] !== 200) {
                    return "Cannot access menu edit page";
                }
            }
            return true;
        });

        // Add Menu Item
        $this->runTest('Menu Management', 'Add Menu Item', function() {
            $response = $this->request('/admin/menus/1');
            $token = $this->extractCsrfToken($response['body']);
            
            $itemData = [
                'menu_id' => 1,
                'title' => 'Test Menu Item ' . time(),
                'url' => '/test-link',
                'position' => 99,
                '_token' => $token
            ];
            
            $response = $this->request('/admin/menus/items/store', 'POST', http_build_query($itemData));
            
            // Accept various success codes
            if (!in_array($response['code'], [200, 201, 302])) {
                return "Expected success response, got {$response['code']}";
            }
            
            return true;
        });
    }

    /**
     * Test 7: User Management
     */
    public function testUserManagement() {
        echo "\n\033[1m7. TESTING USER MANAGEMENT\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // List Users
        $this->runTest('User Management', 'List Users', function() {
            $response = $this->request('/admin/users');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            // Check for admin user
            if (strpos($response['body'], 'kevin') === false) {
                return "Admin user not found in listing";
            }
            return true;
        });

        // Create User
        $testUserId = null;
        $this->runTest('User Management', 'Create User', function() use (&$testUserId) {
            $response = $this->request('/admin/users/create');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            $token = $this->extractCsrfToken($response['body']);
            
            $userData = [
                'username' => 'testuser_' . time(),
                'email' => 'test' . time() . '@example.com',
                'password' => 'TestPass123!',
                'is_admin' => '0',
                '_token' => $token
            ];
            
            $response = $this->request('/admin/users/store', 'POST', http_build_query($userData));
            
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect after creation, got {$response['code']}";
            }
            
            // Extract user ID
            $listResponse = $this->request('/admin/users');
            if (preg_match('/users\/(\d+)\/edit.*?' . preg_quote($userData['username'], '/') . '/s', $listResponse['body'], $matches)) {
                $testUserId = $matches[1];
            }
            
            return true;
        });

        // Edit User
        if ($testUserId) {
            $this->runTest('User Management', 'Edit User', function() use ($testUserId) {
                $response = $this->request("/admin/users/{$testUserId}/edit");
                if ($response['code'] !== 200) {
                    return "Expected 200, got {$response['code']}";
                }
                
                $token = $this->extractCsrfToken($response['body']);
                
                $updateData = [
                    'username' => 'updated_user_' . time(),
                    'email' => 'updated' . time() . '@example.com',
                    'is_admin' => '0',
                    '_token' => $token
                ];
                
                $response = $this->request("/admin/users/{$testUserId}/update", 'POST', http_build_query($updateData));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after update, got {$response['code']}";
                }
                
                return true;
            });

            // Delete User
            $this->runTest('User Management', 'Delete User', function() use ($testUserId) {
                $response = $this->request('/admin/users');
                $token = $this->extractCsrfToken($response['body']);
                
                $response = $this->request("/admin/users/{$testUserId}/delete", 'POST', http_build_query([
                    '_token' => $token
                ]));
                
                if ($response['code'] !== 302 && $response['code'] !== 200) {
                    return "Expected redirect after deletion, got {$response['code']}";
                }
                
                return true;
            });
        }
    }

    /**
     * Test 8: Settings Management
     */
    public function testSettingsManagement() {
        echo "\n\033[1m8. TESTING SETTINGS MANAGEMENT\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // Access Settings
        $this->runTest('Settings', 'Access Settings Page', function() {
            $response = $this->request('/admin/settings');
            if ($response['code'] !== 200) {
                return "Expected 200, got {$response['code']}";
            }
            
            // Check for settings form
            if (strpos($response['body'], 'site_name') === false && 
                strpos($response['body'], 'Site Name') === false) {
                return "Settings form not found";
            }
            return true;
        });

        // Update Settings
        $this->runTest('Settings', 'Update Settings', function() {
            $response = $this->request('/admin/settings');
            $token = $this->extractCsrfToken($response['body']);
            
            $settingsData = [
                'site_name' => 'Test Site ' . time(),
                'site_description' => 'Test description updated at ' . date('Y-m-d H:i:s'),
                '_token' => $token
            ];
            
            $response = $this->request('/admin/settings/update', 'POST', http_build_query($settingsData));
            
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect after update, got {$response['code']}";
            }
            
            return true;
        });
    }

    /**
     * Test 9: File Uploads
     */
    public function testFileUploads() {
        echo "\n\033[1m9. TESTING FILE UPLOADS\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // Test Image Upload in Content
        $this->runTest('File Upload', 'Image Upload in Content', function() {
            $response = $this->request('/admin/content/create');
            $token = $this->extractCsrfToken($response['body']);
            
            // Create a test image
            $imageData = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==');
            $tmpFile = tempnam(sys_get_temp_dir(), 'test_image') . '.png';
            file_put_contents($tmpFile, $imageData);
            
            // Prepare multipart form data
            $boundary = '----WebKitFormBoundary' . md5(time());
            $postData = "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"title\"\r\n\r\n";
            $postData .= "Test Upload Article " . time() . "\r\n";
            $postData .= "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"content\"\r\n\r\n";
            $postData .= "Article with uploaded image\r\n";
            $postData .= "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"type\"\r\n\r\n";
            $postData .= "article\r\n";
            $postData .= "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"status\"\r\n\r\n";
            $postData .= "published\r\n";
            $postData .= "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"_token\"\r\n\r\n";
            $postData .= $token . "\r\n";
            $postData .= "--{$boundary}\r\n";
            $postData .= "Content-Disposition: form-data; name=\"featured_image\"; filename=\"test.png\"\r\n";
            $postData .= "Content-Type: image/png\r\n\r\n";
            $postData .= $imageData . "\r\n";
            $postData .= "--{$boundary}--\r\n";
            
            $ch = curl_init($this->baseUrl . '/admin/content/store');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: multipart/form-data; boundary=' . $boundary,
                'Content-Length: ' . strlen($postData)
            ]);
            curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookieFile);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookieFile);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            unlink($tmpFile);
            
            // Accept various success responses
            if (!in_array($httpCode, [200, 201, 302])) {
                return "Upload failed with code {$httpCode}";
            }
            
            return true;
        });

        // Test Upload Size Limits
        $this->runTest('File Upload', 'Upload Size Validation', function() {
            // This is a conceptual test - actual large file upload would be resource intensive
            // We're checking if the upload form mentions size limits
            $response = $this->request('/admin/content/create');
            
            $hasLimits = strpos($response['body'], '20M') !== false ||
                        strpos($response['body'], '20MB') !== false ||
                        strpos($response['body'], 'max') !== false;
            
            // Not all systems display limits, so we'll pass this either way
            return true;
        });
    }

    /**
     * Test 10: Security Features
     */
    public function testSecurityFeatures() {
        echo "\n\033[1m10. TESTING SECURITY FEATURES\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        // Test CSRF Protection
        $this->runTest('Security', 'CSRF Token Validation', function() {
            $response = $this->request('/admin/content/create');
            
            // Try to submit without CSRF token
            $response = $this->request('/admin/content/store', 'POST', http_build_query([
                'title' => 'Test Without CSRF',
                'content' => 'This should fail'
            ]));
            
            // Should be rejected
            if ($response['code'] === 200 && strpos($response['body'], 'success') !== false) {
                return "CSRF protection not working - form accepted without token!";
            }
            
            return true;
        });

        // Test Authentication Required
        $this->runTest('Security', 'Authentication Protection', function() {
            // Clear cookies to simulate unauthenticated request
            file_put_contents($this->cookieFile, '');
            
            $response = $this->request('/admin/dashboard');
            
            // Should redirect to login or show 401/403
            if ($response['code'] === 200 && strpos($response['body'], 'Dashboard') !== false) {
                return "Admin area accessible without authentication!";
            }
            
            // Re-login for subsequent tests
            $response = $this->request('/admin/login');
            $token = $this->extractCsrfToken($response['body']);
            $this->request('/admin/login', 'POST', http_build_query([
                'username' => 'kevin',
                'password' => '(130Bpm)',
                '_token' => $token
            ]));
            
            return true;
        });

        // Test XSS Protection
        $this->runTest('Security', 'XSS Protection', function() {
            $response = $this->request('/admin/content/create');
            $token = $this->extractCsrfToken($response['body']);
            
            $xssPayload = '<script>alert("XSS")</script>';
            
            $response = $this->request('/admin/content/store', 'POST', http_build_query([
                'title' => 'XSS Test ' . time(),
                'content' => $xssPayload,
                'type' => 'article',
                'status' => 'published',
                '_token' => $token
            ]));
            
            // Check if XSS is properly escaped in the listing
            $listResponse = $this->request('/admin/content');
            
            if (strpos($listResponse['body'], '<script>alert') !== false) {
                return "XSS vulnerability detected - script tags not escaped!";
            }
            
            return true;
        });

        // Test SQL Injection Protection
        $this->runTest('Security', 'SQL Injection Protection', function() {
            // Try SQL injection in search/filter
            $sqlPayload = "' OR '1'='1";
            
            $response = $this->request('/admin/content?search=' . urlencode($sqlPayload));
            
            // Should not cause error or return all records
            if ($response['code'] === 500) {
                return "SQL error detected - possible SQL injection vulnerability";
            }
            
            return true;
        });

        // Test Session Security
        $this->runTest('Security', 'Session Security', function() {
            $response = $this->request('/admin/dashboard');
            
            // Check for secure session settings in headers
            $hasSecureHeaders = strpos($response['header'], 'HttpOnly') !== false ||
                               strpos($response['header'], 'SameSite') !== false;
            
            if (!$hasSecureHeaders) {
                // This is a warning, not a failure
                echo " (Warning: Secure cookie flags not detected)";
            }
            
            return true;
        });
    }

    /**
     * Test Logout
     */
    public function testLogout() {
        echo "\n\033[1m11. TESTING LOGOUT\033[0m\n";
        echo str_repeat('-', 40) . "\n";

        $this->runTest('Authentication', 'Logout', function() {
            $response = $this->request('/admin/logout');
            
            // Should redirect to login
            if ($response['code'] !== 302 && $response['code'] !== 200) {
                return "Expected redirect after logout, got {$response['code']}";
            }
            
            // Verify dashboard is no longer accessible
            $response = $this->request('/admin/dashboard');
            if ($response['code'] === 200 && strpos($response['body'], 'Dashboard') !== false) {
                return "Still authenticated after logout!";
            }
            
            return true;
        });
    }

    /**
     * Generate comprehensive report
     */
    public function generateReport() {
        echo "\n" . str_repeat('=', 80) . "\n";
        echo "\033[1mTEST RESULTS SUMMARY\033[0m\n";
        echo str_repeat('=', 80) . "\n\n";
        
        echo "Total Tests: {$this->totalTests}\n";
        echo "\033[32mPassed: {$this->passedTests}\033[0m\n";
        echo "\033[31mFailed: {$this->failedTests}\033[0m\n";
        
        $passRate = $this->totalTests > 0 ? round(($this->passedTests / $this->totalTests) * 100, 2) : 0;
        echo "Pass Rate: {$passRate}%\n\n";
        
        // Category breakdown
        echo "\033[1mResults by Category:\033[0m\n";
        echo str_repeat('-', 40) . "\n";
        
        foreach ($this->testResults as $category => $tests) {
            $categoryPassed = 0;
            $categoryTotal = count($tests);
            
            foreach ($tests as $result) {
                if ($result === 'PASS') {
                    $categoryPassed++;
                }
            }
            
            $categoryRate = $categoryTotal > 0 ? round(($categoryPassed / $categoryTotal) * 100, 2) : 0;
            echo sprintf("%-25s: %d/%d passed (%s%%)\n", 
                $category, 
                $categoryPassed, 
                $categoryTotal,
                $categoryRate
            );
        }
        
        // Failure details
        if (!empty($this->failureDetails)) {
            echo "\n\033[1m\033[31mFAILURE DETAILS:\033[0m\n";
            echo str_repeat('-', 40) . "\n";
            
            foreach ($this->failureDetails as $category => $failures) {
                echo "\n\033[1m{$category}:\033[0m\n";
                foreach ($failures as $test => $reason) {
                    echo "  • {$test}: {$reason}\n";
                }
            }
        }
        
        // Recommendations
        echo "\n\033[1mRECOMMENDATIONS:\033[0m\n";
        echo str_repeat('-', 40) . "\n";
        
        if ($this->failedTests === 0) {
            echo "✓ All tests passed successfully!\n";
            echo "✓ The application appears to be functioning correctly.\n";
        } else {
            echo "⚠ Some tests failed. Please review the failure details above.\n";
            
            // Specific recommendations based on failures
            foreach ($this->failureDetails as $category => $failures) {
                switch ($category) {
                    case 'Authentication':
                        echo "⚠ Authentication issues detected - verify login credentials and session handling.\n";
                        break;
                    case 'Security':
                        echo "⚠ Security vulnerabilities may exist - review CSRF, XSS, and SQL injection protections.\n";
                        break;
                    case 'Content CRUD':
                    case 'Page Management':
                        echo "⚠ Content management issues - check database connections and permissions.\n";
                        break;
                    case 'File Upload':
                        echo "⚠ File upload problems - verify upload directory permissions and PHP settings.\n";
                        break;
                }
            }
        }
        
        echo "\n" . str_repeat('=', 80) . "\n";
        echo "Test completed at: " . date('Y-m-d H:i:s') . "\n";
        echo str_repeat('=', 80) . "\n\n";
    }

    /**
     * Run all tests
     */
    public function runAllTests() {
        $this->testPublicPages();
        $this->testAdminAuthentication();
        $this->testAdminDashboard();
        $this->testContentCRUD();
        $this->testPageManagement();
        $this->testMenuManagement();
        $this->testUserManagement();
        $this->testSettingsManagement();
        $this->testFileUploads();
        $this->testSecurityFeatures();
        $this->testLogout();
        $this->generateReport();
        
        return $this->failedTests === 0;
    }
}

// Run the tests
$tester = new ComprehensiveE2ETest();
$success = $tester->runAllTests();

exit($success ? 0 : 1);